import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// In-memory & disk cache for generated audio
interface CachedAudio {
  buffer: Buffer;
  mimeType: string;
}
const audioCache = new Map<string, CachedAudio>();
const CACHE_DIR = path.resolve('/tmp/openai_tts_cache');
try {
  if (!fs.existsSync(CACHE_DIR)) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
  }
} catch {
  // Ignored
}

function getCacheKey(text: string, voice: string, speed: number): string {
  return crypto.createHash('sha256').update(`${voice}_${speed}_${text}`).digest('hex');
}

// Supported Voice mapping
export const OPENAI_VOICES = ['onyx', 'echo', 'fable', 'alloy'] as const;

// Gemini voice mapping fallback
const GEMINI_VOICE_MAP: Record<string, string> = {
  onyx: 'Fenrir',   // Deep resonant male
  echo: 'Charon',   // Calm, solemn male
  fable: 'Puck',    // Storyteller, narrative
  alloy: 'Zephyr'   // Balanced, articulate
};

// Automatic circuit breaker for OpenAI credit exhaustion
let isOpenAiCreditExhausted = true; // Auto-bypass enabled for seamless playback
let lastCreditCheckTime = Date.now();

// Status endpoint
app.get('/api/tts/status', (req: Request, res: Response) => {
  const hasOpenAI = Boolean(process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim().length > 5);
  const hasGemini = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 5);
  res.json({
    hasOpenAI,
    hasGemini,
    bypassCreditError: isOpenAiCreditExhausted,
    activeMode: isOpenAiCreditExhausted ? 'instant_human_voice' : 'openai_tts',
    voices: [
      { id: 'onyx', name: 'أونيكس (Onyx)', type: 'رخيم ووقور', gender: 'male', desc: 'صوت بشري جهوري عميق مناسب لجلال الحديث النبوي' },
      { id: 'echo', name: 'إيكو (Echo)', type: 'هادئ ومطمئن', gender: 'male', desc: 'صوت بشري رقيق ينساب بسكينة وطمأنينة تخاطب القلب' },
      { id: 'fable', name: 'فيبل (Fable)', type: 'خاشع وسردي', gender: 'male', desc: 'نبرة حكائية وسردية معبرة لمواقف وقصص الصحابة' },
      { id: 'alloy', name: 'ألوي (Alloy)', type: 'متزن وفصيح', gender: 'neutral', desc: 'نبرة فصيحة متزنة ونقية بمخارج حروف واضحة' }
    ]
  });
});

// Toggle bypass endpoint
app.post('/api/tts/toggle-bypass', (req: Request, res: Response) => {
  const { bypass } = req.body;
  if (typeof bypass === 'boolean') {
    isOpenAiCreditExhausted = bypass;
  } else {
    isOpenAiCreditExhausted = !isOpenAiCreditExhausted;
  }
  res.json({ bypassCreditError: isOpenAiCreditExhausted });
});

// Human Voice Text-to-Speech proxy endpoint
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voice = 'onyx', speed = 1.0, forceOpenAI = false } = req.body;

    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      res.status(400).json({ error: 'Text is required for speech synthesis' });
      return;
    }

    const selectedVoice = OPENAI_VOICES.includes(voice) ? voice : 'onyx';
    const clampedSpeed = Math.max(0.5, Math.min(2.0, parseFloat(speed) || 1.0));
    const cleanText = text.trim().slice(0, 1500);
    const cacheKey = getCacheKey(cleanText, selectedVoice, clampedSpeed);

    // 1. Check in-memory cache
    if (audioCache.has(cacheKey)) {
      const cached = audioCache.get(cacheKey)!;
      res.setHeader('Content-Type', cached.mimeType);
      res.setHeader('Content-Length', cached.buffer.length);
      res.setHeader('X-Cache-Status', 'MEM_HIT');
      res.end(cached.buffer);
      return;
    }

    // 2. Check disk cache
    const cacheMetaPath = path.join(CACHE_DIR, `${cacheKey}.json`);
    const cacheAudioPath = path.join(CACHE_DIR, `${cacheKey}.bin`);
    if (fs.existsSync(cacheAudioPath) && fs.existsSync(cacheMetaPath)) {
      try {
        const meta = JSON.parse(fs.readFileSync(cacheMetaPath, 'utf8'));
        const fileBuffer = fs.readFileSync(cacheAudioPath);
        audioCache.set(cacheKey, { buffer: fileBuffer, mimeType: meta.mimeType });
        res.setHeader('Content-Type', meta.mimeType);
        res.setHeader('Content-Length', fileBuffer.length);
        res.setHeader('X-Cache-Status', 'DISK_HIT');
        res.end(fileBuffer);
        return;
      } catch {
        // Fallback to fresh generation
      }
    }

    const openAiApiKey = process.env.OPENAI_API_KEY?.trim();

    // Try OpenAI ONLY if key is present AND not bypassed due to credit balance
    if (openAiApiKey && openAiApiKey.length > 5 && (!isOpenAiCreditExhausted || forceOpenAI)) {
      try {
        const openAiResponse = await fetch('https://api.openai.com/v1/audio/speech', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${openAiApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'tts-1',
            input: cleanText,
            voice: selectedVoice,
            speed: clampedSpeed,
            response_format: 'mp3'
          }),
        });

        if (openAiResponse.ok) {
          const arrayBuffer = await openAiResponse.arrayBuffer();
          const buffer = Buffer.from(arrayBuffer);
          const mimeType = 'audio/mpeg';

          audioCache.set(cacheKey, { buffer, mimeType });
          try {
            fs.writeFileSync(cacheAudioPath, buffer);
            fs.writeFileSync(cacheMetaPath, JSON.stringify({ mimeType }));
          } catch {
            // Ignored
          }

          res.setHeader('Content-Type', mimeType);
          res.setHeader('Content-Length', buffer.length);
          res.setHeader('X-Audio-Provider', 'openai');
          res.end(buffer);
          return;
        } else {
          const errStatus = openAiResponse.status;
          const errText = await openAiResponse.text();
          if (errStatus === 429 || errText.includes('insufficient_quota') || errText.includes('credit_balance_exhausted')) {
            console.warn('[OpenAI Bypass] Credit balance exhausted, activating instant human voice mode');
            isOpenAiCreditExhausted = true;
            lastCreditCheckTime = Date.now();
          }
        }
      } catch (err) {
        console.warn('OpenAI request error, bypassing to instant human voice engine:', err);
      }
    }

    // High-Fidelity Human Voice Engine (`gemini-3.8-flash-lite-tts`)
    // Instant, zero-cost, human recitation matching the selected voice
    if (process.env.GEMINI_API_KEY) {
      try {
        const ai = new GoogleGenAI();
        const geminiVoice = GEMINI_VOICE_MAP[selectedVoice] || 'Fenrir';

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: cleanText,
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: geminiVoice
                }
              }
            }
          }
        });

        const part = response.candidates?.[0]?.content?.parts?.[0];
        const base64Data = part?.inlineData?.data;
        const mimeType = part?.inlineData?.mimeType || 'audio/wav';

        if (base64Data) {
          const buffer = Buffer.from(base64Data, 'base64');

          audioCache.set(cacheKey, { buffer, mimeType });
          try {
            fs.writeFileSync(cacheAudioPath, buffer);
            fs.writeFileSync(cacheMetaPath, JSON.stringify({ mimeType }));
          } catch {
            // Ignored
          }

          res.setHeader('Content-Type', mimeType);
          res.setHeader('Content-Length', buffer.length);
          res.setHeader('X-Audio-Provider', 'human-voice-instant');
          res.end(buffer);
          return;
        }
      } catch (geminiErr: unknown) {
        console.error('Human voice generation error:', geminiErr);
      }
    }

    res.status(503).json({
      error: 'TTS_UNAVAILABLE',
      message: 'خدمة القراءة الصوتية غير متوفرة حالياً.'
    });

  } catch (err: unknown) {
    console.error('TTS endpoint exception:', err);
    res.status(500).json({
      error: 'TTS_GENERATION_FAILED',
      message: err instanceof Error ? err.message : 'Unknown server error'
    });
  }
});

// Setup server with Vite (dev) or Static (production)
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve('dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Leh Qalha server running on port ${port} (mode: ${isProd ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
