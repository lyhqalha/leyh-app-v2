import React, { useState, useEffect, useCallback, useRef } from 'react';
import { HadithItem, ActiveTab } from './types/hadith';
import { HADITHS_DATABASE } from './data/hadiths';
import { getDailyHadith } from './utils/dailyHadith';
import { HomeView } from './components/HomeView';
import { SavedView } from './components/SavedView';
import { SearchView } from './components/SearchView';
import { DailyHadithView } from './components/DailyHadithView';
import { CategoriesView } from './components/CategoriesView';
import { StoryView } from './components/StoryView';
import { HadithDetail } from './components/HadithDetail';
import { BottomNav } from './components/BottomNav';
import { ShareCardModal } from './components/ShareCardModal';
import { AudioPlayerModal } from './components/AudioPlayerModal';
import { SettingsModal } from './components/SettingsModal';
import { UserStatsModal } from './components/UserStatsModal';
import { AboutAppModal } from './components/AboutAppModal';
import { getInitialStats, recordHadithRead, recordStoryListened, ReadingStats } from './utils/readingTracker';
import { Smartphone, Monitor, Bell, X, Sparkles, BookOpen } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [activeView, setActiveView] = useState<'tab' | 'story' | 'detail'>('tab');
  const [selectedHadith, setSelectedHadith] = useState<HadithItem>(() => getDailyHadith(HADITHS_DATABASE, new Date()));
  
  // Reading statistics & streak tracking
  const [readingStats, setReadingStats] = useState<ReadingStats>(getInitialStats);

  // Bookmarks persistence
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('leh_qalha_bookmarks');
      return saved ? JSON.parse(saved) : ['hadith-6018', 'hadith-1', 'hadith-15'];
    } catch {
      return ['hadith-6018', 'hadith-1', 'hadith-15'];
    }
  });

  // Modal states
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isStatsModalOpen, setIsStatsModalOpen] = useState(false);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);

  // Appearance & Display
  const [isDeviceFrame, setIsDeviceFrame] = useState(true);
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>('md');

  // Theme Modes: 'default' (الافتراضي الداكن) | 'light' (وضع النهار) | 'ultra-dark' (مظلم فائق)
  const [themeMode, setThemeMode] = useState<'default' | 'light' | 'ultra-dark'>(() => {
    try {
      const saved = localStorage.getItem('leh_qalha_theme_mode');
      if (saved === 'light' || saved === 'ultra-dark' || saved === 'default') {
        return saved;
      }
      if (localStorage.getItem('leh_qalha_ultra_dark') === 'true') {
        return 'ultra-dark';
      }
      return 'default';
    } catch {
      return 'default';
    }
  });

  // Daily Reading Reminder (تذكير القراءة اليومي)
  const [isReminderEnabled, setIsReminderEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('leh_qalha_reminder_enabled') === 'true';
    } catch {
      return false;
    }
  });

  const [reminderTime, setReminderTime] = useState<string>(() => {
    try {
      return localStorage.getItem('leh_qalha_reminder_time') || '09:00';
    } catch {
      return '09:00';
    }
  });

  // In-app interactive reminder notification banner
  const [activeReminderBanner, setActiveReminderBanner] = useState<{
    title: string;
    message: string;
  } | null>(null);

  // Save Bookmarks
  useEffect(() => {
    try {
      localStorage.setItem('leh_qalha_bookmarks', JSON.stringify(bookmarkedIds));
    } catch {
      // Ignored
    }
  }, [bookmarkedIds]);

  // Sync Theme preference with DOM root
  useEffect(() => {
    try {
      localStorage.setItem('leh_qalha_theme_mode', themeMode);
      localStorage.setItem('leh_qalha_ultra_dark', (themeMode === 'ultra-dark').toString());

      document.documentElement.classList.remove('ultra-dark', 'light-mode');
      document.body.classList.remove('ultra-dark', 'light-mode');

      if (themeMode === 'ultra-dark') {
        document.documentElement.classList.add('ultra-dark');
        document.body.classList.add('ultra-dark');
      } else if (themeMode === 'light') {
        document.documentElement.classList.add('light-mode');
        document.body.classList.add('light-mode');
      }
    } catch {
      // Ignored
    }
  }, [themeMode]);

  // Save Reminder settings & request Notification permissions if enabled
  const handleToggleReminder = (enabled: boolean) => {
    setIsReminderEnabled(enabled);
    try {
      localStorage.setItem('leh_qalha_reminder_enabled', enabled.toString());
      if (enabled && typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission === 'default') {
          Notification.requestPermission();
        }
      }
    } catch {
      // Ignored
    }
  };

  const handleChangeReminderTime = (time: string) => {
    setReminderTime(time);
    try {
      localStorage.setItem('leh_qalha_reminder_time', time);
    } catch {
      // Ignored
    }
  };

  // Trigger test notification immediately for user confirmation
  const handleTestReminder = () => {
    // 1. Browser system notification
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification('تذكير القراءة اليومي - «ليه قالها؟»', {
          body: 'حان موعد تدبر حديث اليوم وقراءة قصة وروده النبوي الشريف 📖✨',
          icon: '/favicon.ico',
        });
      } catch {
        // Ignored
      }
    }

    // 2. In-app interactive floating banner
    setActiveReminderBanner({
      title: 'تذكير القراءة اليومي - حديث اليوم',
      message: 'حان موعد تدبر حديث اليوم الشريف وقراءة قصة وروده النبوية!',
    });
  };

  // Background timer checking for daily reminder time match
  const lastRemindedDateRef = useRef<string | null>(null);
  useEffect(() => {
    if (!isReminderEnabled) return;

    const checkReminder = () => {
      const now = new Date();
      const currentHours = now.getHours().toString().padStart(2, '0');
      const currentMinutes = now.getMinutes().toString().padStart(2, '0');
      const currentTimeStr = `${currentHours}:${currentMinutes}`;

      const todayDateStr = now.toISOString().split('T')[0];
      const lastRemindedDate = localStorage.getItem('leh_qalha_last_reminded_date') || lastRemindedDateRef.current;

      if (currentTimeStr === reminderTime && lastRemindedDate !== todayDateStr) {
        lastRemindedDateRef.current = todayDateStr;
        // Mark as reminded for today
        try {
          localStorage.setItem('leh_qalha_last_reminded_date', todayDateStr);
        } catch {
          // Ignored
        }

        // Send browser notification if permitted
        if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
          try {
            new Notification('تذكير القراءة اليومي - «ليه قالها؟»', {
              body: 'حان موعد تدبر حديث اليوم وقراءة قصة وروده النبوي الشريف 📖✨',
              icon: '/favicon.ico',
            });
          } catch {
            // Ignored
          }
        }

        // Show in-app banner
        setActiveReminderBanner({
          title: 'تذكير القراءة اليومي - حديث اليوم',
          message: 'حان موعد تدبر حديث اليوم الشريف وقراءة قصة وروده النبوية!',
        });
      }
    };

    // Initial check and regular interval every 30 seconds
    checkReminder();
    const interval = setInterval(checkReminder, 30000);
    return () => clearInterval(interval);
  }, [isReminderEnabled, reminderTime]);

  const handleToggleBookmark = useCallback((id: string) => {
    setBookmarkedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  }, []);

  const handleRecordRead = useCallback((hadithId: string) => {
    setReadingStats(prev => {
      const updated = recordHadithRead(hadithId);
      if (
        prev.readHadithIds.length === updated.readHadithIds.length &&
        prev.currentStreak === updated.currentStreak &&
        prev.bestStreak === updated.bestStreak &&
        prev.lastReadDate === updated.lastReadDate &&
        prev.activeDates.length === updated.activeDates.length &&
        prev.listenedCount === updated.listenedCount
      ) {
        return prev;
      }
      return updated;
    });
  }, []);

  const handleRecordAudioListened = useCallback((hadithId: string) => {
    setReadingStats(() => recordStoryListened(hadithId));
  }, []);

  const handleOpenStory = useCallback((hadith: HadithItem) => {
    setSelectedHadith(hadith);
    setActiveView('story');
    handleRecordRead(hadith.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [handleRecordRead]);

  const handleSelectHadithDetail = useCallback((hadith: HadithItem) => {
    setSelectedHadith(hadith);
    setActiveView('detail');
    handleRecordRead(hadith.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [handleRecordRead]);

  const handleBackToTabs = useCallback(() => {
    setActiveView('tab');
  }, []);

  const handleOpenDailyHadithFromBanner = () => {
    setActiveReminderBanner(null);
    setActiveTab('daily');
    setActiveView('tab');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Render the current view
  const renderCurrentView = () => {
    if (activeView === 'story') {
      return (
        <StoryView
          hadith={selectedHadith}
          onBack={handleBackToTabs}
          onOpenHadithDetail={() => setActiveView('detail')}
          onRecordRead={handleRecordRead}
          onRecordAudioListened={handleRecordAudioListened}
        />
      );
    }

    if (activeView === 'detail') {
      return (
        <HadithDetail
          hadith={selectedHadith}
          isBookmarked={bookmarkedIds.includes(selectedHadith.id)}
          onToggleBookmark={handleToggleBookmark}
          onBack={handleBackToTabs}
          onOpenStory={() => setActiveView('story')}
          onOpenShareCard={() => setIsShareModalOpen(true)}
          onOpenAudioPlayer={() => setIsAudioModalOpen(true)}
        />
      );
    }

    switch (activeTab) {
      case 'home':
        return (
          <HomeView
            hadiths={HADITHS_DATABASE}
            stats={readingStats}
            onOpenStory={handleOpenStory}
            onSelectHadith={handleSelectHadithDetail}
            onChangeTab={setActiveTab}
            onOpenSettings={() => setIsSettingsModalOpen(true)}
            onOpenStats={() => setIsStatsModalOpen(true)}
            onOpenAbout={() => setIsAboutModalOpen(true)}
            themeMode={themeMode}
            onToggleTheme={() => setThemeMode(prev => prev === 'light' ? 'default' : 'light')}
          />
        );
      case 'saved':
        return (
          <SavedView
            hadiths={HADITHS_DATABASE}
            bookmarkedIds={bookmarkedIds}
            onToggleBookmark={handleToggleBookmark}
            onSelectHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      case 'search':
        return (
          <SearchView
            hadiths={HADITHS_DATABASE}
            onSelectHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      case 'daily':
        return (
          <DailyHadithView
            hadiths={HADITHS_DATABASE}
            onOpenStory={handleOpenStory}
            onOpenDetail={handleSelectHadithDetail}
          />
        );
      case 'categories':
        return (
          <CategoriesView
            hadiths={HADITHS_DATABASE}
            onSelectCategoryHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-300 flex flex-col items-center justify-start sm:p-4 select-none ${
        themeMode === 'ultra-dark'
          ? 'bg-[#000000] text-slate-300 ultra-dark'
          : themeMode === 'light'
          ? 'bg-[#F8FAFC] text-slate-900 light-mode'
          : 'bg-[#080B12] text-slate-100'
      }`}
    >
      
      {/* Floating Device Toggle Bar (Desktop & Tablet) */}
      <div className="hidden md:flex items-center gap-3 mb-4 px-4 py-2 rounded-full bg-[#131B2E] border border-slate-800 text-xs shadow-lg">
        <span className="text-slate-400 font-medium">طريقة العرض:</span>
        <button
          onClick={() => setIsDeviceFrame(true)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full font-bold transition-all ${
            isDeviceFrame
              ? 'bg-[#E2B773] text-[#0D131F]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>إطار الهاتف (كما في التصميم)</span>
        </button>
        <button
          onClick={() => setIsDeviceFrame(false)}
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full font-bold transition-all ${
            !isDeviceFrame
              ? 'bg-[#E2B773] text-[#0D131F]'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Monitor className="w-3.5 h-3.5" />
          <span>شاشة عريضة</span>
        </button>
      </div>

      {/* Main Application Container */}
      <div
        className={`w-full transition-all duration-300 ${
          isDeviceFrame
            ? `max-w-[430px] rounded-[44px] border-[10px] ${
                themeMode === 'ultra-dark'
                  ? 'border-[#0F0F0F] bg-[#000000]'
                  : themeMode === 'light'
                  ? 'border-[#CBD5E1] bg-[#F8FAFC] shadow-[0_20px_50px_rgba(0,0,0,0.1)]'
                  : 'border-[#1A2333] bg-[#0D131F]'
              } shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] overflow-hidden relative min-h-[850px]`
            : `max-w-2xl min-h-screen ${
                themeMode === 'ultra-dark'
                  ? 'bg-[#000000]'
                  : themeMode === 'light'
                  ? 'bg-[#F8FAFC] border-slate-200'
                  : 'bg-[#0D131F] border-slate-800'
              } rounded-none sm:rounded-3xl border shadow-2xl overflow-hidden relative`
        }`}
      >
        {/* Mobile Status Bar (Simulated when in Device Frame) */}
        {isDeviceFrame && (
          <div className={`w-full ${
            themeMode === 'ultra-dark'
              ? 'bg-[#000000] text-slate-500'
              : themeMode === 'light'
              ? 'bg-[#F8FAFC] text-slate-600'
              : 'bg-[#0D131F] text-slate-400'
          } pt-2 px-6 pb-1 flex items-center justify-between text-xs z-30 select-none`}>
            <span className="font-semibold text-[11px] tracking-tight">9:41</span>
            {/* Dynamic Island / Speaker Pill */}
            <div className="w-24 h-4 bg-black rounded-full mx-auto" />
            <div className="flex items-center gap-1.5 text-[11px]">
              <svg className="w-3 h-3 fill-current" viewBox="0 0 24 24"><path d="M12 3C7.5 3 3.5 5 1 8L12 21L23 8C20.5 5 16.5 3 12 3Z"/></svg>
              <div className="w-4 h-2 border border-slate-400 rounded-[2px] p-0.5 flex items-center">
                <div className="w-full h-full bg-slate-400 rounded-[1px]" />
              </div>
            </div>
          </div>
        )}

        {/* In-App Daily Reminder Toast / Banner */}
        {activeReminderBanner && (
          <div className="sticky top-0 z-40 w-full p-2.5 bg-gradient-to-r from-[#172238] via-[#1F2C47] to-[#172238] border-b border-[#E2B773]/40 shadow-xl animate-fadeIn">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773] shrink-0 mt-0.5">
                  <Bell className="w-4 h-4 animate-bounce" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#E2B773] leading-tight">
                    {activeReminderBanner.title}
                  </h4>
                  <p className="text-[11px] text-slate-200 mt-0.5 leading-snug">
                    {activeReminderBanner.message}
                  </p>
                  <div className="mt-1.5 flex items-center gap-2">
                    <button
                      onClick={handleOpenDailyHadithFromBanner}
                      className="px-3 py-1 rounded-lg bg-[#E2B773] text-[#0D131F] text-[10px] font-bold flex items-center gap-1 hover:bg-[#d4a861] active:scale-95 transition-all"
                    >
                      <BookOpen className="w-3 h-3" />
                      <span>اقرأ حديث اليوم الآن</span>
                    </button>
                    <button
                      onClick={() => setActiveReminderBanner(null)}
                      className="text-[10px] text-slate-400 hover:text-white px-2 py-1"
                    >
                      تجاهل
                    </button>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setActiveReminderBanner(null)}
                className="w-6 h-6 rounded-full bg-black/40 text-slate-400 hover:text-white flex items-center justify-center shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* View Content */}
        <div className="relative w-full">
          {renderCurrentView()}
        </div>

        {/* Bottom Tab Bar (shown when not in full-screen story mode) */}
        {activeView === 'tab' && (
          <BottomNav activeTab={activeTab} onChangeTab={setActiveTab} />
        )}
      </div>

      {/* Modals */}
      {isShareModalOpen && (
        <ShareCardModal
          hadith={selectedHadith}
          onClose={() => setIsShareModalOpen(false)}
        />
      )}

      {isAudioModalOpen && (
        <AudioPlayerModal
          hadith={selectedHadith}
          onClose={() => setIsAudioModalOpen(false)}
        />
      )}

      {isSettingsModalOpen && (
        <SettingsModal
          onClose={() => setIsSettingsModalOpen(false)}
          isDeviceFrame={isDeviceFrame}
          onToggleDeviceFrame={() => setIsDeviceFrame(!isDeviceFrame)}
          fontSize={fontSize}
          onChangeFontSize={setFontSize}
          themeMode={themeMode}
          onChangeThemeMode={setThemeMode}
          isUltraDarkMode={themeMode === 'ultra-dark'}
          onToggleUltraDarkMode={(enabled) => setThemeMode(enabled ? 'ultra-dark' : 'default')}
          isReminderEnabled={isReminderEnabled}
          onToggleReminder={handleToggleReminder}
          reminderTime={reminderTime}
          onChangeReminderTime={handleChangeReminderTime}
          onTestReminder={handleTestReminder}
          onOpenStats={() => setIsStatsModalOpen(true)}
          onOpenAbout={() => setIsAboutModalOpen(true)}
        />
      )}

      {isStatsModalOpen && (
        <UserStatsModal
          stats={readingStats}
          totalHadithsCount={HADITHS_DATABASE.length}
          onClose={() => setIsStatsModalOpen(false)}
          onOpenAbout={() => setIsAboutModalOpen(true)}
        />
      )}

      {isAboutModalOpen && (
        <AboutAppModal
          onClose={() => setIsAboutModalOpen(false)}
        />
      )}
    </div>
  );
}
