export interface StoryScene {
  sceneNumber: 1 | 2 | 3 | 4 | 5;
  sceneName?: string; // e.g. "المشهد الأول: ماذا حدث؟"
  badge: string; // "المشهد الأول"
  title: string; // "ماذا حدث؟"
  subtitle?: string; // سياق الموقف
  content: string; // نص المشهد القصصي
  reflectionPrompt?: string; // فكر لحظة: ...
  hadithTextExcerpt?: string; // إذا كان المشهد يحتوي على نص الحديث
  audioText?: string; // النص المخصص للإلقاء الصوتي
}

export interface HadithItem {
  id: string;
  hadith_text: string;
  hadith?: string; // أصل متن الحديث الشريف
  sanad?: string; // السند وسلسلة الرواية والتخريج
  story?: string; // القصة التاريخية وسبب ورود الحديث
  benefit?: string; // الفائدة المستنبطة والدروس العملية
  narrator: string;
  source: string;
  book: string;
  hadith_number: number | string;
  authenticity_grade: 'صحيح' | 'حسن' | 'متفق عليه';
  topic: string;
  topicIconName?: string;
  context: string; // سبب الورود
  context_source: string; // مصدر القصة التاريخي
  explanation: string; // شرح الحديث
  practical_lesson: string[]; // الدروس المستفادة
  keywords: string[];
  scenes: StoryScene[];
  audioDurationSeconds?: number;
}

export interface BatchImportReport {
  totalProcessed: number;
  successfulCount: number;
  failedCount: number;
  hasStoryCount: number;
  hasSanadCount: number;
  hasHadithCount: number;
  hasBenefitCount: number;
  errors: { index: number; id?: string; errors: string[] }[];
  importedAt: string;
}

export type ActiveTab = 'home' | 'saved' | 'search' | 'daily' | 'categories';
