/**
 * Professional Podcast Audio Engine for "ليه قالها؟"
 * 
 * Delivers human-like studio podcast narration for Hadiths and historical stories.
 * 
 * Features:
 * 1. Hybrid 3-tier playback:
 *    - Tier 1: Instant Offline Cache (plays local blob if downloaded, 100% offline without internet).
 *    - Tier 2: Neural Human Podcast Voice via /api/tts (ultra-realistic human Arabic broadcaster voice).
 *    - Tier 3: Zero-failure Web Speech fallback with calibrated acoustic pitch and rate.
 * 2. Real-time progress, duration, word boundaries, and seek controls.
 * 3. Offline downloads integration.
 */

import {
  getDownloadedAudioUrl,
  isAudioDownloaded,
  downloadAudioForOffline
} from './offlineAudioService';

export interface VoiceProfile {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  pitch: number;
  rate: number;
  serverVoice: string; // Onyx, Echo, Fable, etc.
}

export const PODCAST_VOICES: Record<string, VoiceProfile> = {
  onyx: {
    id: 'onyx',
    name: 'الصوت البشري الموحد',
    subtitle: 'صوت واحد للأحاديث والقصص',
    description: 'صوت بشري واحد ثابت يُستخدم في جميع الأحاديث والقصص',
    pitch: 0.82,
    rate: 0.92,
    serverVoice: 'onyx'
  }
};

// Default chosen voice
export const SOLEMN_VOICE: VoiceProfile = PODCAST_VOICES.onyx;

/**
 * Prepares the written text for speech synthesis, ensuring only the exact written words are spoken.
 */
export function cleanStoryContentForSpeech(text: string): string {
  if (!text) return '';
  let cleaned = text.trim();

  // Strip legacy scene badge prefix if present (e.g., "المشهد الأول:")
  cleaned = cleaned.replace(/^المشهد\s+[\u0600-\u06FF\w\d]+\s*[:：\-–—\.]\s*/i, '');

  return cleaned.trim();
}

export interface AudioPlayOptions {
  speed?: number;
  pitch?: number;
  voice?: string;
  hadithId?: string;
  type?: 'hadith' | 'story';
  /** Exact text to use if streamed audio playback itself fails. */
  textForFallback?: string;
  onProgress?: (progressPercent: number, currentTimeSec: number, durationSec: number) => void;
  onWord?: (wordIndex: number, word: string) => void;
  onEnd?: () => void;
  onError?: (errorMessage: string) => void;
  onSourceChange?: (source: 'offline_cache' | 'human_podcast' | 'device_fallback') => void;
}

class PodcastAudioEngine {
  private audioElement: HTMLAudioElement | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private currentVoiceId = 'onyx';
  private isCurrentlyPlaying = false;
  private currentSource: 'offline_cache' | 'human_podcast' | 'device_fallback' = 'human_podcast';
  private tickerInterval: any = null;
  private estimatedDuration = 30;
  private elapsedSeconds = 0;
  private abortController: AbortController | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('leh_qalha_podcast_voice');
        // Enforce one consistent human voice for all hadiths and stories.
        this.currentVoiceId = 'onyx';
        localStorage.setItem('leh_qalha_podcast_voice', 'onyx');
      } catch {
        // Ignored
      }
    }
  }

  public getSelectedVoice(): VoiceProfile {
    return PODCAST_VOICES[this.currentVoiceId] || PODCAST_VOICES.onyx;
  }

  public setSelectedVoice(_voiceId: string) {
    // The app intentionally supports exactly one voice.
    this.currentVoiceId = 'onyx';
    try {
      localStorage.setItem('leh_qalha_podcast_voice', 'onyx');
    } catch {
      // Ignored
    }
  }

  public getSourceType(): 'offline_cache' | 'human_podcast' | 'device_fallback' {
    return this.currentSource;
  }

  public isSpeaking(): boolean {
    if (this.audioElement) {
      return !this.audioElement.paused && !this.audioElement.ended;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      return window.speechSynthesis.speaking && !window.speechSynthesis.paused;
    }
    return this.isCurrentlyPlaying;
  }

  public pauseSpeaking() {
    this.isCurrentlyPlaying = false;
    if (this.audioElement) {
      this.audioElement.pause();
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.pause();
    }
    this.stopTicker();
  }

  public resumeSpeaking() {
    this.isCurrentlyPlaying = true;
    if (this.audioElement && this.audioElement.src) {
      this.audioElement.play().catch(() => {});
    } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.resume();
      this.startTicker();
    }
  }

  public stopSpeaking() {
    this.isCurrentlyPlaying = false;
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }
    if (this.audioElement) {
      this.audioElement.pause();
      this.audioElement.currentTime = 0;
      this.audioElement = null;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.currentUtterance = null;
    }
    this.stopTicker();
    this.elapsedSeconds = 0;
  }

  public seekPercent(percent: number) {
    if (this.audioElement && this.audioElement.duration) {
      this.audioElement.currentTime = (percent / 100) * this.audioElement.duration;
    } else {
      this.elapsedSeconds = Math.max(0, Math.min(this.estimatedDuration, (percent / 100) * this.estimatedDuration));
    }
  }

  private startTicker(onProgress?: (progress: number, current: number, total: number) => void) {
    this.stopTicker();
    this.tickerInterval = setInterval(() => {
      if (this.isCurrentlyPlaying) {
        this.elapsedSeconds += 1;
        if (this.elapsedSeconds > this.estimatedDuration) {
          this.estimatedDuration = this.elapsedSeconds + 5;
        }
        const pct = Math.min(99, Math.round((this.elapsedSeconds / this.estimatedDuration) * 100));
        if (onProgress) {
          onProgress(pct, this.elapsedSeconds, this.estimatedDuration);
        }
      }
    }, 1000);
  }

  private stopTicker() {
    if (this.tickerInterval) {
      clearInterval(this.tickerInterval);
      this.tickerInterval = null;
    }
  }

  /**
   * Recite Hadith text using the podcast voice pipeline.
   */
  public async reciteHadith(text: string, options: AudioPlayOptions = {}) {
    await this.playAudioContent(text, { ...options, textForFallback: cleanStoryContentForSpeech(text) }, options.hadithId, options.type || 'hadith');
  }

  /**
   * Narrate Story scene using the podcast voice pipeline.
   */
  public async narrateStoryScene(scene: { content: string }, options: AudioPlayOptions = {}) {
    await this.playAudioContent(scene.content, { ...options, textForFallback: cleanStoryContentForSpeech(scene.content) }, options.hadithId, 'story');
  }

  /**
   * Main audio playback router:
   * 1. Check Offline Cache (works without internet!)
   * 2. Request Human Podcast Voice via server (/api/tts)
   * 3. Fallback to Web Speech if network fails
   */
  public async playAudioContent(
    rawText: string,
    options: AudioPlayOptions = {},
    hadithId?: string,
    type: 'hadith' | 'story' = 'hadith'
  ) {
    this.stopSpeaking();

    const cleanText = cleanStoryContentForSpeech(rawText);
    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    const selectedVoice = PODCAST_VOICES[options.voice || this.currentVoiceId] || PODCAST_VOICES.onyx;

    // -----------------------------------------------------------------
    // Step 1: Check Offline Local Cache (0 internet, 0 latency)
    // -----------------------------------------------------------------
    if (hadithId) {
      try {
        const isOfflineReady = await isAudioDownloaded(hadithId, type, selectedVoice.serverVoice);
        if (isOfflineReady) {
          const offlineBlobUrl = await getDownloadedAudioUrl(hadithId, type, selectedVoice.serverVoice);
          if (offlineBlobUrl) {
            this.currentSource = 'offline_cache';
            options.onSourceChange?.('offline_cache');
            this.playWithHtmlAudio(offlineBlobUrl, options);
            return;
          }
        }
      } catch {
        // Fallback to online fetch
      }
    }

    // -----------------------------------------------------------------
    // Step 2: Request High-Fidelity Human Podcast Voice (/api/tts)
    // -----------------------------------------------------------------
    if (typeof window !== 'undefined' && navigator.onLine) {
      try {
        this.abortController = new AbortController();
        const response = await fetch('/api/tts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: cleanText,
            voice: selectedVoice.serverVoice,
            speed: options.speed ?? selectedVoice.rate
          }),
          signal: this.abortController.signal
        });

        if (response.ok) {
          const blob = await response.blob();
          const audioUrl = URL.createObjectURL(blob);
          this.currentSource = 'human_podcast';
          options.onSourceChange?.('human_podcast');
          this.playWithHtmlAudio(audioUrl, options);
          return;
        }
      } catch (err: any) {
        if (err.name === 'AbortError') return;
        // Fallback to Web Speech
      }
    }

    // -----------------------------------------------------------------
    // Step 3: Device WebSpeech Fallback (100% offline safety net)
    // -----------------------------------------------------------------
    this.currentSource = 'device_fallback';
    options.onSourceChange?.('device_fallback');
    this.playWithWebSpeech(cleanText, options, selectedVoice);
  }

  /**
   * HTML5 Audio player for high-quality audio streams & offline blobs
   */
  private playWithHtmlAudio(audioUrl: string, options: AudioPlayOptions) {
    const audio = new Audio(audioUrl);
    this.audioElement = audio;
    this.isCurrentlyPlaying = true;

    audio.onloadedmetadata = () => {
      this.estimatedDuration = Math.round(audio.duration || 30);
      options.onProgress?.(0, 0, this.estimatedDuration);
    };

    audio.ontimeupdate = () => {
      const cur = Math.round(audio.currentTime);
      const dur = Math.round(audio.duration || this.estimatedDuration);
      const pct = dur > 0 ? Math.min(100, Math.round((cur / dur) * 100)) : 0;
      options.onProgress?.(pct, cur, dur);
    };

    audio.onended = () => {
      this.isCurrentlyPlaying = false;
      this.audioElement = null;
      options.onProgress?.(100, this.estimatedDuration, this.estimatedDuration);
      options.onEnd?.();
    };

    audio.onerror = () => {
      this.isCurrentlyPlaying = false;
      this.audioElement = null;
      // Fallback to WebSpeech if blob play fails
      this.currentSource = 'device_fallback';
      options.onSourceChange?.('device_fallback');
      // Keep the exact content that was requested; never substitute a database ID for the spoken text.
      const fallbackText = options.textForFallback || '';
      this.playWithWebSpeech(fallbackText, options, PODCAST_VOICES[options.voice || this.currentVoiceId] || PODCAST_VOICES.onyx);
    };

    audio.play().catch((e) => {
      if (e.name !== 'AbortError') {
        options.onError?.('تعذر بدء تشغيل الصوت تلقائياً');
      }
    });
  }

  /**
   * WebSpeech synthesis fallback
   */
  private playWithWebSpeech(text: string, options: AudioPlayOptions, voiceProfile: VoiceProfile) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      options.onError?.('نظام الصوت غير مدعوم على هذا الجهاز.');
      return;
    }

    const wordsCount = text.split(/\s+/).filter(Boolean).length;
    this.estimatedDuration = Math.max(5, Math.round((wordsCount / (2.2 * voiceProfile.rate))));
    this.elapsedSeconds = 0;

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ar-SA';
    utterance.rate = options.speed ?? voiceProfile.rate;
    utterance.pitch = options.pitch ?? voiceProfile.pitch;

    // Pick best Arabic voice
    const voices = window.speechSynthesis.getVoices();
    const arabicVoice = voices.find(v => v.lang.toLowerCase().startsWith('ar'));
    if (arabicVoice) {
      utterance.voice = arabicVoice;
    }

    utterance.onstart = () => {
      this.isCurrentlyPlaying = true;
      this.startTicker(options.onProgress);
      options.onProgress?.(0, 0, this.estimatedDuration);
    };

    utterance.onend = () => {
      this.isCurrentlyPlaying = false;
      this.stopTicker();
      this.elapsedSeconds = 0;
      options.onProgress?.(100, this.estimatedDuration, this.estimatedDuration);
      options.onEnd?.();
    };

    utterance.onerror = (e) => {
      this.isCurrentlyPlaying = false;
      this.stopTicker();
      if (e.error !== 'interrupted' && e.error !== 'canceled') {
        options.onError?.(e.error || 'خطأ في تشغيل الصوت');
      }
    };

    this.currentUtterance = utterance;
    this.isCurrentlyPlaying = true;
    window.speechSynthesis.speak(utterance);
  }

  /**
   * Test sample of selected voice
   */
  public testSample(voiceId?: string, onFinish?: () => void) {
    const voice = PODCAST_VOICES[voiceId || this.currentVoiceId] || PODCAST_VOICES.onyx;
    const sampleText = 'قال رسول الله صلى الله عليه وسلم: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.';
    this.playAudioContent(sampleText, {
      voice: voice.id,
      onEnd: onFinish,
      onError: onFinish
    });
  }
}

export const audioEngine = new PodcastAudioEngine();
