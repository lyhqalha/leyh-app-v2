export interface ReadingStats {
  readHadithIds: string[];
  currentStreak: number;
  bestStreak: number;
  lastReadDate: string; // YYYY-MM-DD
  activeDates: string[]; // List of YYYY-MM-DD dates where user read at least 1 hadith
  listenedCount: number;
}

const STORAGE_KEY = 'leh_qalha_reading_stats';
let memoryCache: ReadingStats | null = null;

function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getYesterdayDateString(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function getInitialStats(): ReadingStats {
  if (memoryCache) {
    return { ...memoryCache };
  }

  try {
    const raw = typeof window !== 'undefined' ? window.localStorage.getItem(STORAGE_KEY) : null;
    if (raw) {
      const parsed = JSON.parse(raw);
      // Validate streak freshness: if lastReadDate is before yesterday, streak is broken
      const today = getTodayDateString();
      const yesterday = getYesterdayDateString();
      let currentStreak = parsed.currentStreak || 0;

      if (parsed.lastReadDate && parsed.lastReadDate !== today && parsed.lastReadDate !== yesterday) {
        currentStreak = 0; // Streak broken if gap is more than 1 day
      }

      const stats: ReadingStats = {
        readHadithIds: Array.isArray(parsed.readHadithIds) ? parsed.readHadithIds : [],
        currentStreak,
        bestStreak: parsed.bestStreak || currentStreak || 0,
        lastReadDate: parsed.lastReadDate || '',
        activeDates: Array.isArray(parsed.activeDates) ? parsed.activeDates : [],
        listenedCount: parsed.listenedCount || 0
      };
      memoryCache = stats;
      return stats;
    }
  } catch {
    // Fallback on storage errors
  }

  const fallback: ReadingStats = {
    readHadithIds: [],
    currentStreak: 0,
    bestStreak: 0,
    lastReadDate: '',
    activeDates: [],
    listenedCount: 0
  };
  memoryCache = fallback;
  return fallback;
}

export function saveStats(stats: ReadingStats): void {
  memoryCache = { ...stats };
  try {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(stats));
    }
  } catch {
    // Ignore storage quota errors
  }
}

/**
 * Records that the user read a specific hadith.
 * Updates streak, reading history, and total counts.
 */
export function recordHadithRead(hadithId: string): ReadingStats {
  const current = getInitialStats();
  const today = getTodayDateString();
  const yesterday = getYesterdayDateString();

  const isAlreadyRead = current.readHadithIds.includes(hadithId);
  const isAlreadyActiveToday = current.activeDates.includes(today) && current.lastReadDate === today;

  if (isAlreadyRead && isAlreadyActiveToday) {
    return current;
  }

  // Add hadith if not already in the read list
  const readHadithIds = isAlreadyRead
    ? current.readHadithIds
    : [...current.readHadithIds, hadithId];

  // Add date to active dates
  const activeDates = current.activeDates.includes(today)
    ? current.activeDates
    : [...current.activeDates, today];

  // Update streak
  let currentStreak = current.currentStreak;
  if (!current.lastReadDate) {
    // First time reading
    currentStreak = 1;
  } else if (current.lastReadDate === today) {
    // Already read today, streak remains unchanged
    currentStreak = Math.max(1, currentStreak);
  } else if (current.lastReadDate === yesterday) {
    // Read yesterday, streak continues!
    currentStreak += 1;
  } else {
    // More than 1 day gap, start new streak
    currentStreak = 1;
  }

  const bestStreak = Math.max(current.bestStreak, currentStreak);

  const updated: ReadingStats = {
    readHadithIds,
    currentStreak,
    bestStreak,
    lastReadDate: today,
    activeDates,
    listenedCount: current.listenedCount
  };

  saveStats(updated);
  return updated;
}

/**
 * Records that the user listened to a hadith story audio.
 */
export function recordStoryListened(hadithId: string): ReadingStats {
  const current = recordHadithRead(hadithId);
  const updated: ReadingStats = {
    ...current,
    listenedCount: current.listenedCount + 1
  };
  saveStats(updated);
  return updated;
}

export interface DayActivity {
  dayName: string;
  dateStr: string;
  isToday: boolean;
  isCompleted: boolean;
}

/**
 * Computes the 7 days of the current week (Saturday to Friday in Arabic culture)
 * and whether the user read a hadith on that day.
 */
export function getWeeklyActivity(activeDates: string[]): DayActivity[] {
  const daysArabic = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const todayStr = getTodayDateString();
  const today = new Date();

  // Find start of week (let's show last 7 days ending with today, or Sat-Fri)
  // Last 7 days is best for personal progress:
  const result: DayActivity[] = [];

  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(today.getDate() - i);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;

    result.push({
      dayName: daysArabic[d.getDay()],
      dateStr,
      isToday: dateStr === todayStr,
      isCompleted: activeDates.includes(dateStr)
    });
  }

  return result;
}

export interface BadgeItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  isUnlocked: boolean;
  progressText: string;
}

export function getBadges(stats: ReadingStats): BadgeItem[] {
  const total = stats.readHadithIds.length;
  const streak = stats.currentStreak;
  const listened = stats.listenedCount;

  return [
    {
      id: 'first_hadith',
      title: 'البداية المباركة',
      description: 'قراءة أو تدبر أول حديث نبوي شريف',
      icon: 'Sparkles',
      isUnlocked: total >= 1,
      progressText: total >= 1 ? 'مكتمل' : 'اقرأ أول حديث'
    },
    {
      id: 'streak_3',
      title: 'همة متواصلة',
      description: 'الالتزام بالقراءة لمدة 3 أيام متتالية',
      icon: 'Flame',
      isUnlocked: streak >= 3 || stats.bestStreak >= 3,
      progressText: `${Math.min(streak, 3)} / 3 أيام`
    },
    {
      id: 'read_10',
      title: 'زاد السالكين',
      description: 'قراءة 10 أحاديث من سنة المصطفى ﷺ',
      icon: 'BookOpen',
      isUnlocked: total >= 10,
      progressText: `${Math.min(total, 10)} / 10 أحاديث`
    },
    {
      id: 'streak_7',
      title: 'أسبوع النور',
      description: 'سلسلة 7 أيام متتالية دون انقطاع',
      icon: 'Award',
      isUnlocked: streak >= 7 || stats.bestStreak >= 7,
      progressText: `${Math.min(streak, 7)} / 7 أيام`
    },
    {
      id: 'listener_5',
      title: 'المستمع الحصيف',
      description: 'الاستماع إلى 5 قصص نبوية بصوت القارئ',
      icon: 'Volume2',
      isUnlocked: listened >= 5,
      progressText: `${Math.min(listened, 5)} / 5 قصص`
    },
    {
      id: 'read_50',
      title: 'طالب العلم',
      description: 'تدبر 50 حديثاً شريفاً من الصحيحين والسنن',
      icon: 'GraduationCap',
      isUnlocked: total >= 50,
      progressText: `${Math.min(total, 50)} / 50 حديثاً`
    }
  ];
}
