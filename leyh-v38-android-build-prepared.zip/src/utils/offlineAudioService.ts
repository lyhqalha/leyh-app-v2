/**
 * Offline Audio Service for "ليه قالها؟"
 * Enables downloading and persistently caching high-definition podcast audio files
 * using the standard browser CacheStorage API and Blob URLs.
 * 
 * Works 100% offline without internet once downloaded!
 */

const CACHE_NAME = 'leh_qalha_offline_audio_v1';
const INDEX_STORAGE_KEY = 'leh_qalha_offline_audio_index';

export interface OfflineAudioItem {
  id: string; // e.g. "hadith-1_hadith" or "hadith-1_story"
  hadithId: string;
  type: 'hadith' | 'story';
  title: string;
  sizeBytes: number;
  downloadedAt: string;
}

function getOfflineIndex(): Record<string, OfflineAudioItem> {
  try {
    const raw = typeof window !== 'undefined' ? localStorage.getItem(INDEX_STORAGE_KEY) : null;
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveOfflineIndex(index: Record<string, OfflineAudioItem>): void {
  try {
    if (typeof window !== 'undefined') {
      localStorage.setItem(INDEX_STORAGE_KEY, JSON.stringify(index));
    }
  } catch {
    // Ignore quota errors
  }
}

function normalizeVoice(_voice: string = 'onyx'): string {
  // Keep all offline cache lookups and downloads on the single app voice.
  return 'onyx';
}

function getAudioKey(hadithId: string, type: 'hadith' | 'story', voice: string = 'onyx'): string {
  return `${hadithId}_${type}_${normalizeVoice(voice)}`;
}

/**
 * Checks if a specific hadith or story audio is cached offline.
 */
export async function isAudioDownloaded(hadithId: string, type: 'hadith' | 'story' = 'hadith', voice: string = 'onyx'): Promise<boolean> {
  if (typeof window === 'undefined' || !('caches' in window)) {
    return false;
  }
  const key = getAudioKey(hadithId, type, voice);
  const index = getOfflineIndex();
  if (!index[key]) return false;

  try {
    const cache = await caches.open(CACHE_NAME);
    const match = await cache.match(new Request(`/offline-audio/${key}`));
    return Boolean(match);
  } catch {
    return false;
  }
}

/**
 * Retrieves the local offline Blob Object URL for playback without internet.
 */
export async function getDownloadedAudioUrl(hadithId: string, type: 'hadith' | 'story' = 'hadith', voice: string = 'onyx'): Promise<string | null> {
  if (typeof window === 'undefined' || !('caches' in window)) {
    return null;
  }
  const key = getAudioKey(hadithId, type, voice);

  try {
    const cache = await caches.open(CACHE_NAME);
    const match = await cache.match(new Request(`/offline-audio/${key}`));
    if (match) {
      const blob = await match.blob();
      return URL.createObjectURL(blob);
    }
  } catch {
    // Fallback
  }
  return null;
}

/**
 * Downloads audio from the professional podcast voice endpoint
 * and saves it into the offline cache for permanent offline access.
 */
export async function downloadAudioForOffline(
  hadithId: string,
  type: 'hadith' | 'story',
  text: string,
  title: string = '',
  voice: string = 'onyx',
  onProgress?: (percent: number) => void
): Promise<string> {
  if (typeof window === 'undefined') {
    throw new Error('Offline storage is only supported in browser');
  }

  const key = getAudioKey(hadithId, type, voice);
  onProgress?.(15);

  // Request high-fidelity human podcast speech
  const response = await fetch('/api/tts', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      text,
      voice,
      speed: 0.95
    })
  });

  if (!response.ok) {
    throw new Error(`تعذر تحميل الصوت: ${response.statusText}`);
  }

  onProgress?.(60);
  const blob = await response.blob();
  onProgress?.(85);

  // Store in CacheStorage
  if ('caches' in window) {
    const cache = await caches.open(CACHE_NAME);
    const cacheResponse = new Response(blob, {
      headers: {
        'Content-Type': blob.type || 'audio/wav',
        'Content-Length': blob.size.toString(),
        'X-Offline-Saved': new Date().toISOString()
      }
    });
    await cache.put(new Request(`/offline-audio/${key}`), cacheResponse);
  }

  // Update index
  const index = getOfflineIndex();
  index[key] = {
    id: key,
    hadithId,
    type,
    title: title || `حديث ${hadithId}`,
    sizeBytes: blob.size,
    downloadedAt: new Date().toISOString()
  };
  saveOfflineIndex(index);

  onProgress?.(100);
  return URL.createObjectURL(blob);
}

/**
 * Removes downloaded audio to free up device storage.
 */
export async function removeDownloadedAudio(hadithId: string, type: 'hadith' | 'story' = 'hadith'): Promise<void> {
  if (typeof window === 'undefined') return;
  try {
    const index = getOfflineIndex();
    if ('caches' in window) {
      const cache = await caches.open(CACHE_NAME);
      for (const item of Object.values(index)) {
        if (item.hadithId === hadithId && item.type === type) {
          await cache.delete(new Request(`/offline-audio/${item.id}`));
          delete index[item.id];
        }
      }
    }
    saveOfflineIndex(index);
  } catch {
    // Ignored
  }
}

/**
 * Returns list of all downloaded items.
 */
export function getAllDownloadedAudios(): OfflineAudioItem[] {
  const index = getOfflineIndex();
  return Object.values(index);
}

/**
 * Total disk space used by offline audios in Megabytes.
 */
export function getTotalOfflineSizeMB(): number {
  const items = getAllDownloadedAudios();
  const totalBytes = items.reduce((sum, item) => sum + (item.sizeBytes || 0), 0);
  return parseFloat((totalBytes / (1024 * 1024)).toFixed(2));
}

/**
 * Clears all cached offline audios.
 */
export async function clearAllOfflineAudios(): Promise<void> {
  if (typeof window === 'undefined') return;
  try {
    if ('caches' in window) {
      await caches.delete(CACHE_NAME);
    }
    localStorage.removeItem(INDEX_STORAGE_KEY);
  } catch {
    // Ignored
  }
}
