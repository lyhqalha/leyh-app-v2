import React from 'react';
import { ReadingStats, getWeeklyActivity, getBadges } from '../utils/readingTracker';
import {
  X,
  Flame,
  BookOpen,
  Award,
  Sparkles,
  Volume2,
  GraduationCap,
  CheckCircle2,
  Share2,
  Calendar,
  TrendingUp,
  Heart
} from 'lucide-react';

interface UserStatsModalProps {
  stats: ReadingStats;
  totalHadithsCount?: number;
  onClose: () => void;
  onOpenAbout?: () => void;
}

export const UserStatsModal: React.FC<UserStatsModalProps> = ({
  stats,
  totalHadithsCount = 2000,
  onClose,
  onOpenAbout
}) => {
  const weekly = getWeeklyActivity(stats.activeDates);
  const badges = getBadges(stats);
  const percentComplete = ((stats.readHadithIds.length / totalHadithsCount) * 100).toFixed(1);

  // Motivational quote based on streak
  const getStreakMessage = (streak: number) => {
    if (streak === 0) return 'ابدأ قراءة حديث اليوم لتشعل شعلة الالتزام بسنة النبي ﷺ!';
    if (streak === 1) return 'بداية مباركة! عُد غداً لتحافظ على استمرار السلسلة.';
    if (streak < 3) return 'ما شاء الله! خطوة رائعة نحو تعميق صلتك بسيرة المصطفى ﷺ.';
    if (streak < 7) return 'همة عالية! أحب الأعمال إلى الله أدومها وإن قل.';
    if (streak < 14) return 'أسبوع كامل من الهدى النبوي! تقبل الله منك وثبتك.';
    return 'ما شاء الله تبارك الله! ثبات واقتداء مبارك، هنيئاً لك هذا الأجر.';
  };

  const handleShareStreak = async () => {
    const text = `أنا ملتزم بقراءة أحاديث النبي ﷺ عبر تطبيق «ليه قالها؟» وسلسلة قراءتي وصلت إلى ${stats.currentStreak} أيام متتالية 🔥\nشاركوني هذه الرحلة الإيمانية المباركة!`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'إحصائيات رحلتي مع سنة النبي ﷺ',
          text
        });
      } catch {
        // User cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        alert('تم نسخ رسالة الإنجاز بنجاح للمشاركة!');
      } catch {
        // Fallback
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn select-none">
      <div className="relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-[#E2B773]">
              <Flame className="w-4 h-4 fill-current text-amber-500" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">رحلتك مع سنة النبي ﷺ</h2>
              <p className="text-[11px] text-slate-400">لوحة الإحصائيات وسلسلة الالتزام</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Main Streak Card */}
          <div className="relative rounded-2xl p-5 bg-gradient-to-br from-[#1E293B] via-[#162032] to-[#0D131F] border border-amber-500/30 overflow-hidden shadow-lg">
            <div className="absolute top-0 left-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center">
                  <Flame className="w-6 h-6 text-amber-500 fill-current animate-pulse" />
                </div>
                <div>
                  <span className="text-xs text-slate-400 block font-medium">سلسلة الأيام المتتالية</span>
                  <span className="text-2xl font-black text-white font-mono flex items-baseline gap-1">
                    {stats.currentStreak}
                    <span className="text-xs font-normal text-amber-400">يوم متتالٍ</span>
                  </span>
                </div>
              </div>

              {/* Best Streak Badge */}
              <div className="text-left bg-black/40 px-3 py-1.5 rounded-xl border border-white/5">
                <span className="text-[10px] text-slate-400 block">أعلى سلسلة</span>
                <span className="text-xs font-bold text-amber-300 font-mono">
                  {stats.bestStreak} يوم
                </span>
              </div>
            </div>

            {/* Motivational Banner */}
            <p className="text-xs text-slate-300 font-medium leading-relaxed bg-black/30 p-2.5 rounded-xl border border-white/5">
              {getStreakMessage(stats.currentStreak)}
            </p>

            {/* Weekly Activity Tracker Row (7 days) */}
            <div className="mt-4 pt-3 border-t border-slate-700/60">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-[#E2B773]" />
                  <span>نشاطك خلال آخر 7 أيام</span>
                </span>
                <span className="text-amber-400 font-medium">
                  {weekly.filter(w => w.isCompleted).length} / 7 أيام
                </span>
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {weekly.map((day, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col items-center justify-center py-2 rounded-xl text-center transition-all ${
                      day.isCompleted
                        ? 'bg-amber-500/20 border border-amber-500/50 text-amber-300 font-bold'
                        : day.isToday
                        ? 'bg-slate-800/80 border border-slate-600 text-slate-300'
                        : 'bg-black/30 border border-slate-800 text-slate-500'
                    }`}
                  >
                    <span className="text-[10px] leading-tight mb-1">{day.dayName.slice(0, 3)}</span>
                    {day.isCompleted ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
                    ) : (
                      <div className="w-2 h-2 rounded-full bg-slate-700" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Core Numbers 3-Column Grid */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="p-3 rounded-2xl bg-[#0D131F] border border-slate-800 text-center flex flex-col items-center">
              <BookOpen className="w-4 h-4 text-[#E2B773] mb-1" />
              <span className="text-lg font-black text-white font-mono">{stats.readHadithIds.length}</span>
              <span className="text-[10px] text-slate-400">حديث مقروء</span>
            </div>

            <div className="p-3 rounded-2xl bg-[#0D131F] border border-slate-800 text-center flex flex-col items-center">
              <Volume2 className="w-4 h-4 text-emerald-400 mb-1" />
              <span className="text-lg font-black text-white font-mono">{stats.listenedCount}</span>
              <span className="text-[10px] text-slate-400">قصة مستمعة</span>
            </div>

            <div className="p-3 rounded-2xl bg-[#0D131F] border border-slate-800 text-center flex flex-col items-center">
              <TrendingUp className="w-4 h-4 text-sky-400 mb-1" />
              <span className="text-lg font-black text-white font-mono">%{percentComplete}</span>
              <span className="text-[10px] text-slate-400">من الـ 2000</span>
            </div>
          </div>

          {/* Hadiths Reading Progress Bar */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#E2B773]" />
                <span>إجمالي الأحاديث المقروءة</span>
              </span>
              <span className="text-[#E2B773] font-mono font-bold">
                {stats.readHadithIds.length} / {totalHadithsCount}
              </span>
            </div>

            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full bg-gradient-to-r from-amber-600 via-[#E2B773] to-amber-300 rounded-full transition-all duration-700"
                style={{ width: `${Math.max(2, Math.min(100, (stats.readHadithIds.length / totalHadithsCount) * 100))}%` }}
              />
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed pt-0.5">
              كل قصة أو حديث تفتحه أو تستمع إليه يُضاف تلقائياً إلى رصيدك المعرفي والإيماني.
            </p>
          </div>

          {/* Achievement Badges Section */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-[#E2B773]" />
                <span>أوسمة الإنجاز والهمة</span>
              </h3>
              <span className="text-[11px] text-slate-400">
                {badges.filter(b => b.isUnlocked).length} / {badges.length} مكتمل
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {badges.map((b) => (
                <div
                  key={b.id}
                  className={`p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                    b.isUnlocked
                      ? 'bg-[#162032] border-[#E2B773]/40 shadow-sm'
                      : 'bg-[#0D131F]/60 border-slate-800/80 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 ${
                        b.isUnlocked
                          ? 'bg-[#E2B773]/20 text-[#E2B773]'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {b.icon === 'Flame' && <Flame className="w-3.5 h-3.5 fill-current" />}
                      {b.icon === 'Sparkles' && <Sparkles className="w-3.5 h-3.5" />}
                      {b.icon === 'BookOpen' && <BookOpen className="w-3.5 h-3.5" />}
                      {b.icon === 'Award' && <Award className="w-3.5 h-3.5" />}
                      {b.icon === 'Volume2' && <Volume2 className="w-3.5 h-3.5" />}
                      {b.icon === 'GraduationCap' && <GraduationCap className="w-3.5 h-3.5" />}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-200 leading-tight">{b.title}</h4>
                      <span className="text-[10px] text-slate-400 font-mono block">
                        {b.progressText}
                      </span>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-tight">{b.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={handleShareStreak}
              className="w-full py-3 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة إنجاز القراءة والتحفيز</span>
            </button>

            {onOpenAbout && (
              <button
                onClick={() => {
                  onClose();
                  onOpenAbout();
                }}
                className="w-full py-2.5 rounded-2xl bg-[#0D131F] border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
              >
                <Heart className="w-3.5 h-3.5 text-rose-400" />
                <span>عن التطبيق والدعاء بظهر الغيب</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
