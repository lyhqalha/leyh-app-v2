import React, { useMemo } from 'react';
import { HadithItem, ActiveTab } from '../types/hadith';
import { getDailyHadith, formatShortArabicDate } from '../utils/dailyHadith';
import { ReadingStats } from '../utils/readingTracker';
import {
  Search,
  Settings,
  Play,
  Bookmark,
  LayoutGrid,
  Sparkles,
  ChevronLeft,
  Calendar,
  Sun,
  Moon,
  Flame,
  Heart,
} from 'lucide-react';

interface HomeViewProps {
  hadiths: HadithItem[];
  stats: ReadingStats;
  onOpenStory: (hadith: HadithItem) => void;
  onSelectHadith: (hadith: HadithItem) => void;
  onChangeTab: (tab: ActiveTab) => void;
  onOpenSettings: () => void;
  onOpenStats: () => void;
  onOpenAbout: () => void;
  themeMode?: 'default' | 'light' | 'ultra-dark';
  onToggleTheme?: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  hadiths,
  stats,
  onOpenStory,
  onChangeTab,
  onOpenSettings,
  onOpenStats,
  onOpenAbout,
  themeMode = 'default',
  onToggleTheme,
}) => {
  // Automatically rotates every single day across all available hadiths
  const featuredHadith = useMemo(() => getDailyHadith(hadiths, new Date()), [hadiths]);
  const todayArabicDate = useMemo(() => formatShortArabicDate(new Date()), []);

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto space-y-5">
      {/* Top Header */}
      <header className="flex items-center justify-between pt-2">
        <button
          onClick={() => onChangeTab('search')}
          className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
          title="البحث"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Center Logo Branding matching mockup */}
        <div className="text-center flex flex-col items-center">
          {/* Mosque Dome and Crescent symbol */}
          <div className="flex items-center justify-center text-[#E2B773] mb-0.5">
            <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
              <path d="M12 2C10.5 4 9 6.5 9 9C9 10.66 10.34 12 12 12C13.66 12 15 10.66 15 9C15 6.5 13.5 4 12 2ZM4 19V11C4 10.45 4.45 10 5 10H6V19H4ZM18 10H19C19.55 10 20 10.45 20 11V19H18V10ZM8 19V11.5C8 9.5 9.8 8 12 8C14.2 8 16 9.5 16 11.5V19H8ZM3 21H21V22H3V21Z" />
            </svg>
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight leading-none">
            ليه قالها؟
          </h1>
          <p className="text-[11px] text-[#94A3B8] font-medium mt-1">
            كل حديث قصة قبل أن يكون كلمة
          </p>
        </div>

        {/* Left Actions: Day Mode Toggle + Settings */}
        <div className="flex items-center gap-2">
          {onToggleTheme && (
            <button
              onClick={onToggleTheme}
              className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-[#E2B773] hover:text-white active:scale-95 transition-all shadow-sm"
              title={themeMode === 'light' ? 'التبديل إلى الوضع الافتراضي' : 'التبديل إلى وضع النهار'}
            >
              {themeMode === 'light' ? (
                <Moon className="w-5 h-5 text-slate-700" />
              ) : (
                <Sun className="w-5 h-5 text-[#E2B773]" />
              )}
            </button>
          )}

          <button
            onClick={onOpenSettings}
            className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
            title="الإعدادات"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Featured Hero Card: clean classic look without the phone/background artwork */}
      <div className="relative w-full rounded-3xl overflow-hidden border border-slate-800/80 shadow-2xl bg-gradient-to-br from-[#18243A] via-[#131B2E] to-[#0D131F]">
        <div className="relative min-h-64 sm:min-h-72 flex flex-col items-center justify-center p-6 text-center">
          <div className="absolute inset-0 bg-gradient-to-b from-amber-500/5 via-transparent to-black/10 pointer-events-none" />
          <div className="relative z-10 flex flex-col items-center">
            <span className="px-4 py-1.5 rounded-full bg-black/20 border border-[#E2B773]/40 text-xs text-[#E2B773] font-bold flex items-center gap-1.5 mb-5">
              <Calendar className="w-3.5 h-3.5" />
              <span>حديث اليوم · {todayArabicDate}</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#131B2E] border border-slate-700/80 text-[11px] font-semibold text-[#E2B773] mb-3">
              <Sparkles className="w-3 h-3" />
              <span>{featuredHadith.topic} · {featuredHadith.narrator}</span>
            </span>
            <h3 className="text-xl sm:text-2xl font-extrabold text-white mb-2 max-w-sm">
              قبل أن تقرأ الحديث...
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 mb-5 font-medium max-w-md line-clamp-2 px-2">
              {featuredHadith.context.slice(0, 95)}{featuredHadith.context.length > 95 ? '...' : ''}
            </p>
            <button
              onClick={() => onOpenStory(featuredHadith)}
              className="py-3 px-8 rounded-full bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-sm flex items-center gap-2 shadow-xl shadow-black/30 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
              <span>ابدأ قصة اليوم</span>
            </button>
          </div>
        </div>
      </div>

      {/* Interactive User Reading Streak & Stats Card */}
      <div
        onClick={onOpenStats}
        className="p-4 rounded-2xl bg-gradient-to-r from-[#1A2438] via-[#141C2E] to-[#101726] border border-amber-500/30 hover:border-amber-500/60 transition-all cursor-pointer shadow-lg group relative overflow-hidden"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Flame className="w-6 h-6 text-amber-500 fill-current animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-white">
                  {stats.currentStreak > 0
                    ? `سلسلة القراءة: ${stats.currentStreak} ${stats.currentStreak === 1 ? 'يوم' : stats.currentStreak === 2 ? 'يومان' : 'أيام متتالية'}`
                    : 'ابدأ سلسلة القراءة اليومية 🔥'}
                </span>
                {stats.currentStreak >= 3 && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                    ما شاء الله!
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                قرأت {stats.readHadithIds.length} من {hadiths.length} حديثاً · اضغط لعرض الإحصائيات والأوسمة
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-xs font-bold text-amber-400 shrink-0">
            <span className="hidden sm:inline">لوحة الإحصائيات</span>
            <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* Charitable dedication shortcut replaces the redundant quick-access buttons */}
      <div
        onClick={onOpenAbout}
        role="button"
        tabIndex={0}
        onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') onOpenAbout(); }}
        className="p-4 rounded-2xl bg-gradient-to-r from-rose-500/10 via-[#131B2E] to-amber-500/10 border border-rose-500/25 hover:border-rose-500/50 transition-all cursor-pointer flex items-center justify-between text-right group shadow-lg"
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
            <Heart className="w-6 h-6 fill-current" />
          </div>
          <div className="min-w-0">
            <span className="text-white font-extrabold block text-sm sm:text-base">عمل خيري خالص لوجه الله تعالى</span>
            <span className="text-xs sm:text-sm text-slate-400 block mt-1">عن التطبيق، أهدافه، ودعوة صالحة بظهر الغيب ❤️</span>
          </div>
        </div>
        <ChevronLeft className="w-5 h-5 text-slate-400 group-hover:text-white group-hover:-translate-x-1 transition-all shrink-0" />
      </div>

      {/* Value Proposition Highlights Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#1E293B] to-[#131B2E] border border-slate-800 flex items-center justify-around text-center text-xs text-slate-300">
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">2000+</span>
          <span className="text-[10px] text-slate-400">حديث صحيح</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">5 مشاهد</span>
          <span className="text-[10px] text-slate-400">قصة تفاعلية</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">صوتيات</span>
          <span className="text-[10px] text-slate-400">راوية هادئة</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">مشاركة</span>
          <span className="text-[10px] text-slate-400">بطاقات مصممة</span>
        </div>
      </div>

    </div>
  );
};
