import React, { useState } from 'react';
import {
  X,
  Heart,
  Share2,
  Sparkles,
  BookOpen,
  Check,
  Flame,
  Award
} from 'lucide-react';

interface AboutAppModalProps {
  onClose: () => void;
}

export const AboutAppModal: React.FC<AboutAppModalProps> = ({ onClose }) => {
  const [blessingStep, setBlessingStep] = useState(0);
  const blessingResponses = [
    'جزاك الله خيرًا، وتقبّل الله دعاءك ولك بالمثل وزيادة ❤️',
    'بارك الله فيك، وجعل لك من الأجر أوفره ❤️',
    'غفر الله لك ولوالديك، وكتب لك الخير حيث كان ❤️',
    'اللهم آمين، ولك بمثل ما دعوت وزيادة ❤️'
  ];

  const handlePrayDuaa = () => {
    setBlessingStep((current) => (current + 1) % blessingResponses.length);
  };

  const handleShareApp = async () => {
    const text = `تطبيق «ليه قالها؟» – كل يوم قصة وحديث للنبي ﷺ ❤️\nتطبيق خيري مجاني يضم أكثر من 2000 حديث صحيح مع أسباب ورودها وسياقها التاريخي ومشاهد تفاعلية وصوتية هادئة.\nشاركونا الأجر ونشر سنة النبي ﷺ:`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'تطبيق ليه قالها – سيرة وحديث النبي ﷺ',
          text,
          url: window.location.href
        });
      } catch {
        // Cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(`${text}\n${window.location.href}`);
        alert('تم نسخ رابط ورسالة التطبيق بنجاح!');
      } catch {
        // Fallback
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn select-none">
      <div className="relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773]">
              <Heart className="w-4 h-4 fill-current text-rose-500" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">عن تطبيق ليه قالها؟</h2>
              <p className="text-[11px] text-[#E2B773] font-medium">عمل خيري خالص لوجه الله تعالى</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-right">
          {/* Main Title & Slogan */}
          <div className="text-center pb-1 border-b border-slate-800/80">
            <span className="text-xl font-extrabold text-[#E2B773] block mb-1 font-hadith">
              ليه قالها – كل يوم قصة وحديث للنبي ﷺ
            </span>
            <p className="text-sm font-bold text-slate-200 flex items-center justify-center gap-1.5">
              <span>اجعل لك كل يوم دقائق مع سنة النبي ﷺ</span>
              <span className="text-rose-400">❤️</span>
            </p>
          </div>

          {/* Description */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed space-y-2">
            <p>
              تطبيق <strong className="text-white">«ليه قالها»</strong> هو تطبيق مجاني يهدف إلى نشر وتعليم أحاديث النبي محمد ﷺ وقصص من سيرته بطريقة بسيطة وسهلة، لتكون سنة النبي ﷺ أقرب إلى حياتنا اليومية.
            </p>
            <p>
              يضم التطبيق <strong className="text-[#E2B773]">أكثر من 2000 حديث صحيح</strong>، بالإضافة إلى قصة وفائدة يومية تساعدك على التعلم والتدبر والاستفادة والعمل بالأثر.
            </p>
          </div>

          {/* Feature Highlights Points */}
          <div className="grid grid-cols-1 gap-2 text-xs">
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">📖</span>
              <span className="font-semibold text-slate-200">أكثر من 2000 حديث صحيح من كتب السنة المعتمدة</span>
            </div>
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">📚</span>
              <span className="font-semibold text-slate-200">قصة وفائدة وسياق تاريخي لكل حديث</span>
            </div>
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">💡</span>
              <span className="font-semibold text-slate-200">محتوى بسيط وسهل ومناسب للجميع وللأسرة</span>
            </div>
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">❤️</span>
              <span className="font-semibold text-slate-200">رحلة يومية تفاعلية وسلسلة التزام مع سنة النبي ﷺ</span>
            </div>
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">🆓</span>
              <span className="font-semibold text-slate-200">التطبيق مجاني بالكامل وبلا أي إعلانات تجارية</span>
            </div>
          </div>

          {/* Charitable Dedication Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-[#E2B773]/10 to-amber-500/10 border border-[#E2B773]/30 text-xs text-slate-300 leading-relaxed space-y-2">
            <p className="font-bold text-[#E2B773] text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#E2B773]" />
              <span>عمل خيري خالص لوجه الله</span>
            </p>
            <p>
              هذا التطبيق عمل خيري، وهدفه أن يصل كلام النبي ﷺ إلى أكبر عدد ممكن من الناس، دون مقابل.
            </p>
            <div className="pt-2 border-t border-[#E2B773]/20">
              <p className="font-bold text-white text-xs mb-1">وفي النهاية لا نطلب منك إلا شيئًا واحدًا:</p>
              <p className="text-slate-300 leading-normal">
                إذا وجدت في هذا التطبيق خيرًا ونفعًا، فلا تنسَ من قام عليه وأهله من دعوة صادقة بظهر الغيب.
              </p>
              <p className="mt-3 pt-3 border-t border-[#E2B773]/20 text-[#E2B773] font-bold text-xs leading-relaxed">
                ربي تقبّل مني هذا العمل، أخوكم في الله أحمد بدوي أحمد رضوان.
              </p>
            </div>
          </div>

          {/* Du'aa Box with Interactive Response */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 text-center space-y-3">
            <p className="font-hadith text-sm sm:text-base text-slate-100 font-bold leading-relaxed">
              «اللهم اجعل هذا العمل خالصًا لوجهك الكريم، وانفع به كل من استخدمه أو نشره أو علّم به غيره»
            </p>
            <p className="text-[11px] text-[#E2B773] font-bold">
              ليه قالها؟ عشان نعرف سنته ﷺ ونفهمها ونعيش بها.
            </p>

            <button
              onClick={handlePrayDuaa}
              className={`py-2.5 px-4 rounded-xl border font-bold text-xs flex items-center justify-center gap-2 mx-auto active:scale-95 transition-all w-full ${blessingStep > 0 ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300' : 'bg-rose-500/20 hover:bg-rose-500/30 border-rose-500/30 text-rose-300'}`}
            >
              {blessingStep > 0 ? <Check className="w-4 h-4 shrink-0" /> : <Heart className="w-3.5 h-3.5 fill-current text-rose-400 shrink-0" />}
              <span>{blessingStep > 0 ? blessingResponses[blessingStep - 1] : 'دعوتُ لكم بظهر الغيب ❤️'}</span>
            </button>
          </div>

          {/* Share App Action */}
          <div className="pt-1">
            <button
              onClick={handleShareApp}
              className="w-full py-3 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة التطبيق ولك أجر الدال على الخير</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
