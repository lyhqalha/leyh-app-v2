import React, { useState, useEffect } from 'react';
import { audioEngine, SOLEMN_VOICE, PODCAST_VOICES } from '../utils/audioService';
import { ambientEngine, AMBIENT_PRESETS, AmbientContextType } from '../utils/ambientSoundService';
import { getAllDownloadedAudios, getTotalOfflineSizeMB, clearAllOfflineAudios } from '../utils/offlineAudioService';
import {
  X,
  Smartphone,
  Monitor,
  Type,
  Sparkles,
  Info,
  Mic,
  Moon,
  Bell,
  Clock,
  Check,
  Play,
  Square,
  Waves,
  Volume2,
  VolumeX,
  Sun,
  Flame,
  Heart,
  Radio,
  Download,
  Trash2,
  WifiOff,
  Database,
  FileCheck2,
  RefreshCw
} from 'lucide-react';
import { HADITHS_IMPORT_REPORT } from '../data/hadiths';
import HADITHS_RAW from '../data/hadiths2000.json';
import { batchImportHadiths } from '../utils/hadithBatchImporter';

interface SettingsModalProps {
  isOpen?: boolean;
  onClose: () => void;
  // Support both isDeviceFrame and isMobileOnlyMode
  isDeviceFrame?: boolean;
  onToggleDeviceFrame?: () => void;
  isMobileOnlyMode?: boolean;
  onToggleDisplayMode?: () => void;
  // Font size
  fontSize?: 'sm' | 'md' | 'lg' | 'normal' | 'large' | 'xlarge';
  onChangeFontSize?: (size: any) => void;
  // Theme mode (الوضع الافتراضي / وضع النهار / الوضع المظلم الفائق)
  themeMode?: 'default' | 'light' | 'ultra-dark';
  onChangeThemeMode?: (mode: 'default' | 'light' | 'ultra-dark') => void;
  // Ultra dark mode (backward compat)
  isUltraDarkMode?: boolean;
  onToggleUltraDarkMode?: (enabled?: any) => void;
  // Daily reminder
  isReminderEnabled: boolean;
  onToggleReminder: (enabled: boolean) => void;
  reminderTime: string;
  onChangeReminderTime: (time: string) => void;
  onTriggerTestReminder?: () => void;
  onTestReminder?: () => void;
  onOpenStats?: () => void;
  onOpenAbout?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen = true,
  onClose,
  isDeviceFrame,
  onToggleDeviceFrame,
  isMobileOnlyMode,
  onToggleDisplayMode,
  fontSize = 'md',
  onChangeFontSize,
  themeMode = 'default',
  onChangeThemeMode,
  isUltraDarkMode = false,
  onToggleUltraDarkMode,
  isReminderEnabled,
  onToggleReminder,
  reminderTime,
  onChangeReminderTime,
  onTriggerTestReminder,
  onTestReminder,
  onOpenStats,
  onOpenAbout
}) => {
  const [internalFontSize, setInternalFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [podcastVoiceId, setPodcastVoiceId] = useState<string>(() => audioEngine.getSelectedVoice().id);
  const [offlineCount, setOfflineCount] = useState<number>(0);
  const [offlineSizeMB, setOfflineSizeMB] = useState<number>(0);
  const [testNotificationSent, setTestNotificationSent] = useState(false);
  const [isAmbientMuted, setIsAmbientMuted] = useState<boolean>(ambientEngine.getIsMuted());
  const [ambientVolume, setAmbientVolume] = useState<number>(ambientEngine.getVolume());
  const [testingAmbientType, setTestingAmbientType] = useState<AmbientContextType | null>(null);
  const [importReport, setImportReport] = useState(HADITHS_IMPORT_REPORT);
  const [isReimporting, setIsReimporting] = useState(false);
  const [reimportSuccess, setReimportSuccess] = useState(false);

  const handleRunBatchImport = () => {
    setIsReimporting(true);
    setTimeout(() => {
      const res = batchImportHadiths(HADITHS_RAW);
      setImportReport(res.report);
      setIsReimporting(false);
      setReimportSuccess(true);
      setTimeout(() => setReimportSuccess(false), 4000);
    }, 400);
  };

  useEffect(() => {
    if (isOpen) {
      setOfflineCount(getAllDownloadedAudios().length);
      setOfflineSizeMB(getTotalOfflineSizeMB());
    }
  }, [isOpen]);

  const handleClearAllOffline = async () => {
    if (window.confirm('هل تريد حذف جميع الملفات الصوتية المحفوظة بدون إنترنت لتفريغ المساحة؟')) {
      await clearAllOfflineAudios();
      setOfflineCount(0);
      setOfflineSizeMB(0);
    }
  };

  const effectiveIsMobileFrame = isDeviceFrame ?? isMobileOnlyMode ?? true;
  const handleToggleFrame = () => {
    if (onToggleDeviceFrame) onToggleDeviceFrame();
    else if (onToggleDisplayMode) onToggleDisplayMode();
  };

  if (!isOpen) return null;

  const handleTestVoice = () => {
    if (isTestingVoice) {
      audioEngine.stopSpeaking();
      ambientEngine.stop();
      setIsTestingVoice(false);
    } else {
      setIsTestingVoice(true);
      ambientEngine.play('sanctuary');
      audioEngine.testSample(podcastVoiceId, () => {
        setIsTestingVoice(false);
        ambientEngine.stop();
      });
    }
  };

  const handleToggleAmbientMute = () => {
    const next = ambientEngine.toggleMute();
    setIsAmbientMuted(next);
  };

  const handleChangeAmbientVolume = (vol: number) => {
    setAmbientVolume(vol);
    ambientEngine.setVolume(vol);
  };

  const handleTestAmbient = (type: AmbientContextType) => {
    if (testingAmbientType === type) {
      ambientEngine.stop();
      setTestingAmbientType(null);
    } else {
      setTestingAmbientType(type);
      ambientEngine.play(type);
    }
  };

  const handleTriggerTestReminder = () => {
    if (onTriggerTestReminder) {
      onTriggerTestReminder();
    } else if (onTestReminder) {
      onTestReminder();
    }
    setTestNotificationSent(true);
    setTimeout(() => {
      setTestNotificationSent(false);
    }, 3000);
  };

  const REMINDER_PRESETS = [
    { label: 'فجراً', time: '05:30' },
    { label: 'صباحاً', time: '09:00' },
    { label: 'عصراً', time: '16:30' },
    { label: 'مساءً', time: '21:00' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773]">
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white">إعدادات التطبيق</h2>
          </div>
          <button
            onClick={() => {
              if (isTestingVoice) audioEngine.stopSpeaking();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* 1. Theme / Appearance Modes: الوضع الافتراضي / وضع النهار / الوضع المظلم الفائق */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-2 text-sm">
                <Sun className="w-4 h-4 text-[#E2B773]" />
                <span>مظهر التطبيق (الوضع)</span>
              </span>
              <span className="text-xs text-[#E2B773] font-semibold">
                {themeMode === 'light' ? 'وضع النهار' : themeMode === 'ultra-dark' ? 'مظلم فائق' : 'الافتراضي'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {/* 1. Default (الافتراضي) */}
              <button
                onClick={() => {
                  onChangeThemeMode?.('default');
                  if (onToggleUltraDarkMode) onToggleUltraDarkMode(false);
                }}
                className={`p-3 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${
                  themeMode === 'default'
                    ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773] font-bold shadow-md'
                    : 'border-slate-800 bg-[#131B2E] text-slate-400 hover:text-slate-200'
                }`}
              >
                <Moon className="w-5 h-5 text-[#E2B773]" />
                <span className="text-xs">الافتراضي</span>
                <span className="text-[10px] text-slate-500">ليلي كحلي</span>
              </button>

              {/* 2. Light / Day Mode (وضع النهار) */}
              <button
                onClick={() => {
                  onChangeThemeMode?.('light');
                  if (onToggleUltraDarkMode) onToggleUltraDarkMode(false);
                }}
                className={`p-3 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${
                  themeMode === 'light'
                    ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773] font-bold shadow-md'
                    : 'border-slate-800 bg-[#131B2E] text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sun className="w-5 h-5 text-amber-500" />
                <span className="text-xs">وضع النهار</span>
                <span className="text-[10px] text-slate-500">فاتح ومريح</span>
              </button>

              {/* 3. Ultra Dark (مظلم فائق) */}
              <button
                onClick={() => {
                  onChangeThemeMode?.('ultra-dark');
                  if (onToggleUltraDarkMode) onToggleUltraDarkMode(true);
                }}
                className={`p-3 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${
                  themeMode === 'ultra-dark'
                    ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773] font-bold shadow-md'
                    : 'border-slate-800 bg-[#131B2E] text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="w-5 h-5 rounded-full bg-black border border-slate-700 flex items-center justify-center text-[10px] text-slate-400">●</div>
                <span className="text-xs">مظلم فائق</span>
                <span className="text-[10px] text-slate-500">سواد تام</span>
              </button>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed pt-1">
              {themeMode === 'light'
                ? 'وضع النهار يوفر خلفية فاتحة وألواناً نضرة مريحة جداً للقراءة في ضوء النهار وأثناء الصباح.'
                : themeMode === 'ultra-dark'
                ? 'الوضع المظلم الفائق يخفض السطوع إلى أقصى حد للقراءة في الغرف المظلمة تماماً.'
                : 'الوضع الافتراضي الملكي بألوانه الكحلية والذهبية الأنيقة المستوحاة من السكينة النبوية.'}
            </p>
          </div>

          {/* 2. Daily Reading Reminder (تذكير القراءة اليومي) */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Bell className={`w-4 h-4 ${isReminderEnabled ? 'text-[#E2B773]' : 'text-slate-400'}`} />
                <span>تذكير القراءة اليومي</span>
              </span>
              <button
                onClick={() => onToggleReminder(!isReminderEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                  isReminderEnabled ? 'bg-[#E2B773]' : 'bg-slate-800'
                }`}
                title="تفعيل أو تعطيل التذكير اليومي"
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-[#0D131F] transition-transform ${
                    isReminderEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              تنبيه بسيط يومي يذكرك بقراءة حديث اليوم وتدبر سبب وروده النبوي الشريف في وقت تختاره.
            </p>

            {isReminderEnabled && (
              <div className="pt-2 border-t border-slate-800/80 space-y-2.5 animate-fadeIn">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#E2B773]" />
                    <span>حدد وقت التنبيه:</span>
                  </span>
                  <input
                    type="time"
                    value={reminderTime}
                    onChange={(e) => onChangeReminderTime(e.target.value)}
                    className="bg-[#141C2E] border border-slate-700 text-[#E2B773] font-mono font-bold text-xs px-2.5 py-1 rounded-xl focus:outline-none focus:border-[#E2B773]"
                  />
                </div>

                {/* Quick Presets */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {REMINDER_PRESETS.map((p) => (
                    <button
                      key={p.time}
                      onClick={() => onChangeReminderTime(p.time)}
                      className={`py-1 px-1 rounded-lg text-center transition-all text-[10px] ${
                        reminderTime === p.time
                          ? 'bg-[#E2B773] text-[#0D131F] font-bold shadow-sm'
                          : 'bg-[#141C2E] text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                {/* Test Notification Button */}
                <div className="pt-1 flex items-center justify-between gap-2">
                  <button
                    onClick={handleTriggerTestReminder}
                    className="w-full py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-98 text-slate-200 text-[11px] font-semibold flex items-center justify-center gap-2 border border-slate-700/80 transition-all"
                  >
                    <Bell className="w-3.5 h-3.5 text-[#E2B773]" />
                    <span>{testNotificationSent ? 'تم إرسال إشعار تجريبي بنجاح!' : 'تجربة الإشعار الآن'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 3. Professional Podcast Voices (أصوات بودكاست بشرية احترافية مجانية) */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs sm:text-sm">
                <Radio className="w-4 h-4 text-[#E2B773]" />
                <span>أصوات بودكاست بشرية احترافية</span>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                مجانية بالكامل
              </span>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              أصوات قراءة بشرية احترافية مجانية فصيحة بنبرات إذاعية وبودكاست تسرد الحديث وقصته بأعلى جودة واقعية.
            </p>

            <div className="grid grid-cols-3 gap-2">
              {Object.values(PODCAST_VOICES).map((voice) => {
                const isSelected = podcastVoiceId === voice.id;
                return (
                  <button
                    key={voice.id}
                    onClick={() => {
                      setPodcastVoiceId(voice.id);
                      audioEngine.setSelectedVoice(voice.id);
                      if (isTestingVoice) {
                        audioEngine.stopSpeaking();
                        setIsTestingVoice(false);
                      }
                    }}
                    className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center gap-1 ${
                      isSelected
                        ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773] font-bold shadow-md'
                        : 'border-slate-800 bg-[#131B2E] text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <Mic className="w-4 h-4 text-[#E2B773]" />
                    <span className="text-xs font-bold leading-tight">{voice.name.split(' ')[1]}</span>
                    <span className="text-[9px] text-slate-400 truncate">{voice.subtitle}</span>
                  </button>
                );
              })}
            </div>

            {/* Test Voice Sample Button */}
            <div className="pt-1">
              <button
                onClick={handleTestVoice}
                className={`w-full py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-bold transition-all text-xs ${
                  isTestingVoice
                    ? 'bg-rose-500/20 border-rose-500/40 text-rose-300 animate-pulse'
                    : 'bg-[#141C2E] border-slate-700/80 hover:border-[#E2B773]/50 text-slate-200'
                }`}
              >
                {isTestingVoice ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>إيقاف تجربة الصوت</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current text-[#E2B773]" />
                    <span>تجربة صوت البودكاست المحدد الآن ({PODCAST_VOICES[podcastVoiceId]?.name})</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 4. Offline Audio Manager (إدارة الملفات الصوتية المحفوظة بدون إنترنت) */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs sm:text-sm">
                <WifiOff className="w-4 h-4 text-emerald-400" />
                <span>الصوتيات المحفوظة بدون إنترنت (أوفلاين)</span>
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400">
                {offlineCount} ملف ({offlineSizeMB} ميجابايت)
              </span>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              يمكنك تحميل أي حديث أو قصة بنقرة واحدة عبر زر «تحميل بدون إنترنت» لتبقى محفوظة في ذاكرة التطبيق للاستماع إليها في أي وقت دون اتصال بالإنترنت.
            </p>

            {offlineCount > 0 && (
              <div className="pt-1 flex items-center justify-between">
                <span className="text-[10px] text-slate-400">
                  المساحة المستهلكة في الذاكرة: {offlineSizeMB} MB
                </span>
                <button
                  onClick={handleClearAllOffline}
                  className="py-1.5 px-3 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-1.5 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>تفريغ الذاكرة وحذف كل الملفات</span>
                </button>
              </div>
            )}
          </div>

          {/* 4. Ambient Sounds Settings (طبقة المؤثرات الصوتية الخفيفة) */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Waves className={`w-4 h-4 ${!isAmbientMuted ? 'text-[#E2B773]' : 'text-slate-400'}`} />
                <span>المؤثرات الصوتية الخفيفة (Ambient)</span>
              </span>
              <button
                onClick={handleToggleAmbientMute}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                  !isAmbientMuted ? 'bg-[#E2B773]' : 'bg-slate-800'
                }`}
                title="تفعيل أو كتم المؤثرات الصوتية البيئية"
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-[#0D131F] transition-transform ${
                    !isAmbientMuted ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              طبقة صوتية بيئية خفيفة وهادئة تعمل في الخلفية خلف صوت الراوي الوقور تتطابق مع سياق كل قصة (مثل: نسيم الصحراء، سكينة المسجد، هدوء الليل، خرير الماء، دفء المجالس).
            </p>

            {/* Ambient Presets Preview buttons */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] text-slate-400 block font-medium">تجربة أنماط المؤثرات البيئية:</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                {(Object.keys(AMBIENT_PRESETS) as AmbientContextType[]).map((type) => {
                  const preset = AMBIENT_PRESETS[type];
                  const isPlayingThis = testingAmbientType === type;
                  return (
                    <button
                      key={type}
                      onClick={() => handleTestAmbient(type)}
                      className={`p-2 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
                        isPlayingThis
                          ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] shadow-sm'
                          : 'bg-[#141C2E] border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                      }`}
                    >
                      <span className="truncate flex items-center gap-1">
                        <span>{preset.icon}</span>
                        <span>{preset.name.split(' ')[0]}</span>
                      </span>
                      {isPlayingThis ? (
                        <Square className="w-3 h-3 fill-current shrink-0" />
                      ) : (
                        <Play className="w-3 h-3 fill-current shrink-0 opacity-60" />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Volume slider */}
            {!isAmbientMuted && (
              <div className="pt-2 border-t border-slate-800/80 flex items-center gap-3">
                <span className="text-[10px] text-slate-400 shrink-0">شدة المؤثرات:</span>
                <input
                  type="range"
                  min="0.05"
                  max="0.5"
                  step="0.02"
                  value={ambientVolume}
                  onChange={(e) => handleChangeAmbientVolume(parseFloat(e.target.value))}
                  className="w-full accent-[#E2B773] h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />
                <span className="text-[10px] font-mono text-slate-400 shrink-0">{Math.round(ambientVolume * 200)}%</span>
              </div>
            )}
          </div>

          {/* 4. Display Mode (Mobile Frame vs Responsive Full) */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2">
            <span className="font-bold text-slate-200 block">طريقة عرض التطبيق</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleToggleFrame}
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  effectiveIsMobileFrame
                    ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F]'
                    : 'border-slate-800 text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                <span>إطار الهاتف الذكي</span>
              </button>
              <button
                onClick={handleToggleFrame}
                className={`flex items-center justify-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                  !effectiveIsMobileFrame
                    ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F]'
                    : 'border-slate-800 text-slate-300 hover:bg-slate-800/60'
                }`}
              >
                <Monitor className="w-4 h-4" />
                <span>شاشة كاملة مرنة</span>
              </button>
            </div>
          </div>

          {/* 5. Font Size Setting */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2">
            <span className="font-bold text-slate-200 block">حجم الخط لقراءة القصة</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'sm', altId: 'normal', label: 'طبيعي' },
                { id: 'md', altId: 'large', label: 'كبير' },
                { id: 'lg', altId: 'xlarge', label: 'كبير جداً' }
              ].map((item) => {
                const isSelected = fontSize === item.id || fontSize === item.altId || internalFontSize === item.altId;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (onChangeFontSize) {
                        onChangeFontSize(item.id as any);
                      }
                      setInternalFontSize(item.altId as any);
                    }}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] font-bold'
                        : 'border-slate-800 text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    <Type className="w-3.5 h-3.5 mx-auto mb-1 opacity-70" />
                    <span className="text-xs">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 6. Database Batch Importer & Pillars Verification */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-[#E2B773]/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-[#E2B773]" />
                <span className="font-bold text-slate-200 text-xs">قاعدة البيانات والاستيراد الذكي</span>
              </div>
              <button
                onClick={handleRunBatchImport}
                disabled={isReimporting}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#E2B773]/15 hover:bg-[#E2B773]/25 text-[#E2B773] text-[11px] font-bold border border-[#E2B773]/30 transition-all active:scale-95 disabled:opacity-50"
              >
                <RefreshCw className={`w-3 h-3 ${isReimporting ? 'animate-spin' : ''}`} />
                <span>{isReimporting ? 'جارٍ الاستيراد...' : 'إعادة فحص الدفعة'}</span>
              </button>
            </div>

            {reimportSuccess && (
              <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-medium flex items-center gap-1.5 animate-fadeIn">
                <FileCheck2 className="w-4 h-4 shrink-0" />
                <span>تم استيراد وفحص 2,000 حديث بنجاح مع مطابقة كافة الحقول الأربعة!</span>
              </div>
            )}

            <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>إجمالي الأحاديث المستوردة:</span>
                <span className="font-mono font-bold text-[#E2B773]">{importReport.successfulCount.toLocaleString()} / {importReport.totalProcessed.toLocaleString()} حديث</span>
              </div>

              {/* 4 Pillars Verification Checklist */}
              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-800 text-[11px]">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                  <span>الحديث: {importReport.hasHadithCount.toLocaleString()} (100%)</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                  <span>السند: {importReport.hasSanadCount.toLocaleString()} (100%)</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                  <span>القصة: {importReport.hasStoryCount.toLocaleString()} (100%)</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                  <span>الفائدة: {importReport.hasBenefitCount.toLocaleString()} (100%)</span>
                </div>
              </div>
            </div>
          </div>

          {/* 7. Quick Navigation: statistics, mission, and app information */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            {onOpenStats && (
              <button
                onClick={() => {
                  onClose();
                  onOpenStats();
                }}
                className="p-3 rounded-2xl bg-[#0D131F] border border-amber-500/30 hover:border-amber-500/60 text-right flex items-center gap-2.5 transition-all group"
              >
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Flame className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">إحصائياتي والهمة</span>
                  <span className="text-[10px] text-slate-400">سلسلة الأيام والأوسمة</span>
                </div>
              </button>
            )}

            {onOpenAbout && (
              <button
                onClick={() => {
                  onClose();
                  onOpenAbout();
                }}
                className="p-3 rounded-2xl bg-[#0D131F] border border-rose-500/30 hover:border-rose-500/60 text-right flex items-center gap-2.5 transition-all group"
              >
                <div className="w-8 h-8 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
                  <Heart className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">عن التطبيق</span>
                  <span className="text-[10px] text-slate-400">دعوة بظهر الغيب ❤️</span>
                </div>
              </button>
            )}
            {onOpenAbout && (
              <button
                onClick={() => {
                  onClose();
                  onOpenAbout();
                }}
                className="p-3 rounded-2xl bg-[#0D131F] border border-[#E2B773]/30 hover:border-[#E2B773]/60 text-right flex items-center gap-2.5 transition-all group"
              >
                <div className="w-8 h-8 rounded-xl bg-[#E2B773]/15 text-[#E2B773] flex items-center justify-center shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-xs font-bold text-white block">المهمة ورسالة التطبيق</span>
                  <span className="text-[10px] text-slate-400">هدف التطبيق ورسالته</span>
                </div>
              </button>
            )}
          </div>

          {/* 7. About Info Box */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 flex items-start gap-3">
            <Info className="w-5 h-5 text-[#E2B773] shrink-0 mt-0.5" />
            <div className="text-xs text-slate-400 space-y-1 leading-relaxed">
              <span className="font-bold text-white block">رسالة تطبيق «ليه قالها؟»</span>
              <p>
                تطبيق إيماني خيري يهدف إلى نشر سنة النبي ﷺ وأسباب ورود أحاديثه الشريفة بأسلوب قصصي بسيط وميسر ليعيش المسلم مع هديه ﷺ كل يوم.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-[#0D131F] flex justify-end">
          <button
            onClick={() => {
              if (isTestingVoice) audioEngine.stopSpeaking();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-bold text-xs transition-colors flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            <span>حفظ وإغلاق</span>
          </button>
        </div>
      </div>
    </div>
  );
};
