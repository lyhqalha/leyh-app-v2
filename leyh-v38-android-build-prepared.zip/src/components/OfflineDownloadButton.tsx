import React, { useState, useEffect, useRef } from 'react';
import { audioEngine } from '../utils/audioService';
import {
  isAudioDownloaded,
  downloadAudioForOffline,
  removeDownloadedAudio
} from '../utils/offlineAudioService';
import {
  Download,
  CheckCircle2,
  Loader2,
  Trash2,
  WifiOff
} from 'lucide-react';

interface OfflineDownloadButtonProps {
  hadithId: string;
  type?: 'hadith' | 'story';
  textToSpeak: string;
  title?: string;
  variant?: 'button' | 'icon' | 'compact';
  onDownloadedChange?: (isDownloaded: boolean) => void;
}

export const OfflineDownloadButton: React.FC<OfflineDownloadButtonProps> = ({
  hadithId,
  type = 'hadith',
  textToSpeak,
  title = '',
  variant = 'button',
  onDownloadedChange
}) => {
  const [isDownloaded, setIsDownloaded] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const onDownloadedChangeRef = useRef(onDownloadedChange);
  useEffect(() => {
    onDownloadedChangeRef.current = onDownloadedChange;
  });

  useEffect(() => {
    let isMounted = true;
    isAudioDownloaded(hadithId, type, audioEngine.getSelectedVoice().serverVoice).then((downloaded) => {
      if (isMounted) {
        setIsDownloaded(downloaded);
        onDownloadedChangeRef.current?.(downloaded);
      }
    });
    return () => {
      isMounted = false;
    };
  }, [hadithId, type]);

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isDownloading) return;

    if (isDownloaded) {
      setShowDeleteConfirm(prev => !prev);
      return;
    }

    try {
      setIsDownloading(true);
      setProgress(10);
      await downloadAudioForOffline(
        hadithId,
        type,
        textToSpeak,
        title,
        audioEngine.getSelectedVoice().serverVoice,
        (pct) => setProgress(pct)
      );
      setIsDownloaded(true);
      onDownloadedChange?.(true);
    } catch {
      // Avoid window.alert in iframe environment
      setIsDownloading(false);
    } finally {
      setIsDownloading(false);
      setProgress(0);
    }
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    await removeDownloadedAudio(hadithId, type);
    setIsDownloaded(false);
    setShowDeleteConfirm(false);
    onDownloadedChange?.(false);
  };

  if (variant === 'icon') {
    return (
      <div className="relative inline-flex items-center">
        <button
          onClick={handleDownload}
          disabled={isDownloading}
          className={`p-1.5 rounded-lg transition-all ${
            isDownloaded
              ? 'bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25 border border-emerald-500/30'
              : 'bg-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700'
          }`}
          title={isDownloaded ? 'الصوت محفوظ على جهازك بدون إنترنت (اضغط للحذف)' : 'تحميل الصوت للاستماع بدون إنترنت'}
        >
          {isDownloading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E2B773]" />
          ) : isDownloaded ? (
            <CheckCircle2 className="w-3.5 h-3.5 fill-emerald-500/20 text-emerald-400" />
          ) : (
            <Download className="w-3.5 h-3.5" />
          )}
        </button>

        {showDeleteConfirm && isDownloaded && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute left-0 top-full mt-1.5 z-40 bg-[#0D131F] border border-slate-700 rounded-xl p-2 shadow-2xl flex flex-col gap-1 text-[11px] whitespace-nowrap min-w-[140px]"
          >
            <div className="flex items-center gap-1 text-emerald-400 font-bold px-1">
              <WifiOff className="w-3 h-3" />
              <span>متاح بدون إنترنت</span>
            </div>
            <button
              onClick={handleDelete}
              className="py-1 px-2 rounded-lg bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 flex items-center gap-1.5 text-right font-medium transition-colors"
            >
              <Trash2 className="w-3 h-3 text-rose-400" />
              <span>حذف لتوفير المساحة</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div className="relative inline-flex items-center">
        <button
          onClick={handleDownload}
          disabled={isDownloading}
          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold flex items-center gap-1.5 transition-all ${
            isDownloaded
              ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 shadow-sm'
              : 'bg-slate-800/90 text-slate-300 hover:text-white hover:bg-slate-700 border border-slate-700'
          }`}
        >
          {isDownloading ? (
            <>
              <Loader2 className="w-3 h-3 animate-spin text-[#E2B773]" />
              <span>%{progress}</span>
            </>
          ) : isDownloaded ? (
            <>
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>بدون إنترنت ✓</span>
            </>
          ) : (
            <>
              <Download className="w-3 h-3" />
              <span>تحميل أوفلاين</span>
            </>
          )}
        </button>

        {showDeleteConfirm && isDownloaded && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute left-0 top-full mt-1 z-30 bg-[#0D131F] border border-slate-700 rounded-xl p-2 shadow-2xl flex flex-col gap-1 text-[11px] whitespace-nowrap"
          >
            <button
              onClick={handleDelete}
              className="py-1 px-2 rounded-lg bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 flex items-center gap-1.5 font-bold"
            >
              <Trash2 className="w-3 h-3 text-rose-400" />
              <span>حذف الملف من الجهاز</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  // Full button variant
  return (
    <div className="relative inline-flex items-center">
      <button
        onClick={handleDownload}
        disabled={isDownloading}
        className={`py-2 px-3.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all ${
          isDownloaded
            ? 'bg-emerald-500/15 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
            : 'bg-[#141C2E] hover:bg-[#1A2438] text-slate-300 hover:text-white border border-slate-700/80'
        }`}
      >
        {isDownloading ? (
          <>
            <Loader2 className="w-3.5 h-3.5 animate-spin text-[#E2B773]" />
            <span>جارٍ تحميل الصوت للعمل بدون إنترنت ({progress}%)...</span>
          </>
        ) : isDownloaded ? (
          <>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>محفوظ على جهازك · يعمل بدون إنترنت ✓</span>
          </>
        ) : (
          <>
            <Download className="w-3.5 h-3.5 text-[#E2B773]" />
            <span>تحميل الصوت للاستماع بدون إنترنت (أوفلاين)</span>
          </>
        )}
      </button>

      {showDeleteConfirm && isDownloaded && (
        <div
          onClick={(e) => e.stopPropagation()}
          className="absolute right-0 top-full mt-1.5 z-40 bg-[#0D131F] border border-slate-700 rounded-2xl p-2.5 shadow-2xl flex flex-col gap-1.5 text-xs whitespace-nowrap"
        >
          <div className="flex items-center gap-1.5 text-emerald-400 font-bold px-1 text-[11px]">
            <WifiOff className="w-3.5 h-3.5" />
            <span>الصوت محفوظ ومتاح 100% بدون إنترنت</span>
          </div>
          <button
            onClick={handleDelete}
            className="py-1.5 px-3 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 flex items-center gap-2 text-right font-bold transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            <span>حذف الصوت لتفريغ المساحة</span>
          </button>
        </div>
      )}
    </div>
  );
};
