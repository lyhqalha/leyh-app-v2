import { HadithItem, BatchImportReport } from '../types/hadith';
import HADITHS_RAW from './hadiths2000.json';
import { batchImportHadiths } from '../utils/hadithBatchImporter';

// Visual story artworks
export const desertHeroImage = '/src/assets/images/hadith_desert_story_hero_1791342804799.jpg';
export const mosqueMinaretImage = '/src/assets/images/prophet_mosque_minaret_1791342819421.jpg';
export const companionsStoryImage = '/src/assets/images/companions_gathering_story_1791342830741.jpg';
export const prophetCourtyardImage = '/src/assets/images/prophet_courtyard_1791399544278.jpg';
export const nightDesertStarsImage = '/src/assets/images/night_desert_stars_1791399557332.jpg';

// Execute batch import with complete verification of the 4 mandatory fields
// (الحديث، السند، القصة، الفائدة) across all 2,000 hadiths
const importResult = batchImportHadiths(HADITHS_RAW);

export const HADITHS_DATABASE: HadithItem[] = importResult.items;
export const HADITHS_IMPORT_REPORT: BatchImportReport = importResult.report;

export const CATEGORIES_LIST = [
  { id: 'morals', name: 'الأخلاق', iconName: 'MessageSquareHeart', count: 116, description: 'مكارم الأخلاق، الرحمة، الصدق، وحفظ اللسان' },
  { id: 'faith', name: 'الإيمان', iconName: 'ShieldCheck', count: 113, description: 'أصول العقيدة، توحيد الله، وأركان الإيمان الستة' },
  { id: 'people', name: 'التعامل مع الناس', iconName: 'UsersRound', count: 112, description: 'حسن الجوار، إكرام الضيف، ولين الجانب والتسامح' },
  { id: 'supplication', name: 'الدعاء', iconName: 'Hands', count: 112, description: 'مخ العبادة، سيد الاستغفار، وأوقات الإجابة' },
  { id: 'prayer', name: 'الصلاة', iconName: 'Compass', count: 111, description: 'عمود الدين، الخشوع، صلاة الجماعة وسنن الصلوات' },
  { id: 'repentance', name: 'التوبة', iconName: 'RotateCcw', count: 111, description: 'الاستغفار، الرجوع إلى الله، وسعة رحمة الغفور' },
  { id: 'quran', name: 'القرآن', iconName: 'BookOpen', count: 111, description: 'فضل التلاوة والتدبر، والماهر بالقرآن وشفاعته' },
  { id: 'work', name: 'المال والعمل', iconName: 'Coins', count: 111, description: 'أكل الحلال، أجر الأجير، والأمانة في التجارة' },
  { id: 'marriage', name: 'الزواج', iconName: 'Heart', count: 111, description: 'المودة والرحمة، وبناء البيت المسلم والعفة' },
  { id: 'manners', name: 'حسن الخلق', iconName: 'Smile', count: 111, description: 'طلاقة الوجه، التبسم صدقة، والحلم وكظم الغيظ' },
  { id: 'family', name: 'الأسرة والتربية', iconName: 'Users', count: 111, description: 'كلكم راع، خيركم لأهله، ورعاية الأبناء والنشء' },
  { id: 'shyness', name: 'الحياء', iconName: 'Sparkles', count: 110, description: 'الحياء لا يأتي إلا بخير، وزينة المؤمن الباطنة' },
  { id: 'patience', name: 'الصبر', iconName: 'Flame', count: 110, description: 'الصبر عند الصدمة الأولى، عجباً لأمر المؤمن واحتساب البلاء' },
  { id: 'parents', name: 'بر الوالدين', iconName: 'Award', count: 110, description: 'أمك ثم أمك ثم أبوك، ورضا الرب في رضا الوالدين' },
  { id: 'knowledge', name: 'العلم', iconName: 'GraduationCap', count: 110, description: 'فضل طلب العلم، والعلماء ورثة الأنبياء' },
  { id: 'ramadan', name: 'رمضان', iconName: 'Sparkle', count: 110, description: 'شهر الغفران، تصفيد الشياطين، وفضل ليلة القدر' },
  { id: 'hajj', name: 'الحج والعمرة', iconName: 'Navigation', count: 110, description: 'الحج المبرور ليس له جزاء إلا الجنة، ومناسك المشاعر' },
  { id: 'fasting', name: 'الصيام', iconName: 'Moon', count: 110, description: 'الصيام جنة، وباب الريان، وإني امرؤ صائم' }
];
