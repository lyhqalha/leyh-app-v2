package com.leyhqalha.leyh;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

/**
 * Main-process bridge for offline Miro High Arabic TTS.
 * The actual Sherpa-ONNX work runs in a separate Android process so a native
 * Sherpa/model crash cannot take down the WebView/UI process.
 */
public final class OfflineTtsBridge {
    public static final String ACTION_TTS = "com.leyhqalha.leyh.TTS";
    public static final String ACTION_DONE = "com.leyhqalha.leyh.TTS_DONE";
    public static final String ACTION_ERROR = "com.leyhqalha.leyh.TTS_ERROR";
    public static final String EXTRA_COMMAND = "command";
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_SPEED = "speed";
    public static final String EXTRA_REQUEST = "request";
    public static final String EXTRA_MESSAGE = "message";

    private final Activity activity;
    private final WebView webView;
    private final BroadcastReceiver receiver;
    private volatile boolean playing = false;
    private int requestId = 0;
    private boolean receiverRegistered = false;

    public OfflineTtsBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.webView = webView;
        this.receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                int req = intent.getIntExtra(EXTRA_REQUEST, -1);
                if (req != requestId) return;
                String action = intent.getAction();
                if (ACTION_DONE.equals(action)) {
                    playing = false;
                    jsDone();
                } else if (ACTION_ERROR.equals(action)) {
                    playing = false;
                    jsError(intent.getStringExtra(EXTRA_MESSAGE));
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_DONE);
        filter.addAction(ACTION_ERROR);
        if (Build.VERSION.SDK_INT >= 33) {
            activity.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            activity.registerReceiver(receiver, filter);
        }
        receiverRegistered = true;
    }

    @JavascriptInterface
    public synchronized void speak(String text, float speed) {
        if (text == null || text.trim().isEmpty()) return;
        int req = ++requestId;
        playing = true;
        Intent intent = new Intent(activity, OfflineTtsService.class);
        intent.setAction(ACTION_TTS);
        intent.putExtra(EXTRA_COMMAND, "speak");
        intent.putExtra(EXTRA_TEXT, text);
        intent.putExtra(EXTRA_SPEED, Math.max(0.7f, Math.min(1.25f, speed)));
        intent.putExtra(EXTRA_REQUEST, req);
        try {
            activity.startService(intent);
        } catch (Throwable e) {
            playing = false;
            jsError(e.getMessage() == null ? "تعذر تشغيل محرك Miro" : e.getMessage());
        }
    }

    @JavascriptInterface
    public synchronized void stop() {
        int req = ++requestId;
        playing = false;
        Intent intent = new Intent(activity, OfflineTtsService.class);
        intent.setAction(ACTION_TTS);
        intent.putExtra(EXTRA_COMMAND, "stop");
        intent.putExtra(EXTRA_REQUEST, req);
        try { activity.startService(intent); } catch (Throwable ignored) { }
    }

    @JavascriptInterface public void pause() {
        sendCommand("pause");
    }

    @JavascriptInterface public void resume() {
        sendCommand("resume");
    }

    private void sendCommand(String command) {
        Intent intent = new Intent(activity, OfflineTtsService.class);
        intent.setAction(ACTION_TTS);
        intent.putExtra(EXTRA_COMMAND, command);
        intent.putExtra(EXTRA_REQUEST, requestId);
        try { activity.startService(intent); } catch (Throwable ignored) { }
    }

    @JavascriptInterface public boolean isPlaying() { return playing; }

    private void jsDone() {
        webView.post(() -> webView.evaluateJavascript(
            "window.__leyhOfflineTtsDone&&window.__leyhOfflineTtsDone()", null));
    }

    private void jsError(String message) {
        webView.post(() -> webView.evaluateJavascript(
            "window.__leyhOfflineTtsError&&window.__leyhOfflineTtsError(" + quote(message) + ")", null));
    }

    private String quote(String s) {
        if (s == null) s = "تعذر تشغيل الصوت";
        return "\"" + s.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r") + "\"";
    }

    public void shutdown() {
        playing = false;
        if (receiverRegistered) {
            try { activity.unregisterReceiver(receiver); } catch (Throwable ignored) { }
            receiverRegistered = false;
        }
    }
}
