#!/usr/bin/env bash
set -euo pipefail

# Android 10+ only.
if [ -f android/variables.gradle ]; then
  sed -E -i 's/minSdkVersion = [0-9]+/minSdkVersion = 29/' android/variables.gradle
fi

if [ -f android/app/build.gradle ]; then
  if grep -Eq 'minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+' android/app/build.gradle; then
    sed -E -i 's/minSdk(Source)?[[:space:]]*[=:][[:space:]]*[0-9]+/minSdk\1 = 29/g' android/app/build.gradle
  elif grep -q 'defaultConfig {' android/app/build.gradle; then
    sed -i '/defaultConfig {/a\        minSdk 29' android/app/build.gradle
  fi
fi

# Bundle notification audio in Android's raw resources.
mkdir -p android/app/src/main/res/raw
cp resources/salawat.wav android/app/src/main/res/raw/salawat.wav
cp resources/notification.wav android/app/src/main/res/raw/notification.wav

# Bundle Sherpa-ONNX and the free Kareem Arabic neural TTS model.
# The model is MIT-licensed and runs fully offline on the device.
SHERPA_VERSION="1.13.8"
SHERPA_AAR_URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/v${SHERPA_VERSION}/sherpa-onnx-${SHERPA_VERSION}.aar"
KAREEM_MODEL_URL="https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-ar_JO-kareem-medium.tar.bz2"
mkdir -p android/app/libs android/app/src/main/assets/tts-model
curl -L --retry 3 --fail --silent --show-error "$SHERPA_AAR_URL" -o android/app/libs/sherpa-onnx-${SHERPA_VERSION}.aar
curl -L --retry 3 --fail --silent --show-error "$KAREEM_MODEL_URL" -o /tmp/kareem-medium.tar.bz2
rm -rf /tmp/kareem-tts
mkdir -p /tmp/kareem-tts
tar -xjf /tmp/kareem-medium.tar.bz2 -C /tmp/kareem-tts
KAREEM_DIR="$(find /tmp/kareem-tts -maxdepth 2 -type f -name 'ar_JO-kareem-medium.onnx' -print -quit | xargs -r dirname)"
if [ -z "$KAREEM_DIR" ] || [ ! -f "$KAREEM_DIR/ar_JO-kareem-medium.onnx" ]; then
  echo "ERROR: Kareem model extraction failed"
  find /tmp/kareem-tts -maxdepth 4 -type f | head -50
  exit 1
fi
rm -rf android/app/src/main/assets/tts-model/vits-piper-ar_JO-kareem-medium
mkdir -p android/app/src/main/assets/tts-model/vits-piper-ar_JO-kareem-medium
cp -R "$KAREEM_DIR/." android/app/src/main/assets/tts-model/vits-piper-ar_JO-kareem-medium/

# Add the local AAR to the generated Capacitor Android module.
python3 - <<'PY2'
from pathlib import Path
p=Path('android/app/build.gradle')
s=p.read_text()
line="    implementation files('libs/sherpa-onnx-1.13.8.aar')"
if line not in s:
    marker='dependencies {'
    s=s.replace(marker, marker+'\n'+line, 1)
p.write_text(s)
PY2

# Keep normal Android system bars visible (clock, network, battery, navigation bar).
# The app uses the available screen area without a fake phone frame.
MAIN_JAVA_DIR="android/app/src/main/java/com/leyhqalha/leyh"
mkdir -p "$MAIN_JAVA_DIR"
cp scripts/OfflineTtsBridge.java "$MAIN_JAVA_DIR/OfflineTtsBridge.java"
cp scripts/OfflineTtsService.java "$MAIN_JAVA_DIR/OfflineTtsService.java"
find android/app/src/main/java -type f \( -name 'MainActivity.java' -o -name 'MainActivity.kt' \) -delete
cat > "$MAIN_JAVA_DIR/MainActivity.java" <<'JAVA'
package com.leyhqalha.leyh;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    private String lastSystemBarColor = "#0D131F";
    private boolean lastLightIcons = false;

    private static final String DAILY_CHANNEL_ID = "daily-reading-v5";
    private static final String SALAWAT_CHANNEL_ID = "salawat-reminder-v5";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setSystemBars("#0D131F", false);

        // Allow the web UI to switch the native status/navigation bars when
        // the user changes between the two app themes.
        try {
            WebView webView = getBridge().getWebView();
            webView.addJavascriptInterface(new SystemBarsBridge(), "LeyhSystemBars");
            webView.addJavascriptInterface(new OfflineTtsBridge(this, webView), "LeyhOfflineTts");
        } catch (Exception ignored) {
            // Keep native defaults if the bridge is unavailable.
        }

        createNotificationChannels();
        // Capacitor can re-apply window flags after onCreate. Re-apply once the
        // WebView is attached so the Android bars cannot fall back to gray.
        getWindow().getDecorView().post(() -> setSystemBars(lastSystemBarColor, lastLightIcons));
    }

    @Override
    public void onResume() {
        super.onResume();
        getWindow().getDecorView().post(() -> setSystemBars(lastSystemBarColor, lastLightIcons));
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            getWindow().getDecorView().post(() -> setSystemBars(lastSystemBarColor, lastLightIcons));
        }
    }

    private final class SystemBarsBridge {
        @android.webkit.JavascriptInterface
        public void setSystemBars(String color, boolean lightIcons) {
            MainActivity.this.runOnUiThread(() -> MainActivity.this.setSystemBars(color, lightIcons));
        }
    }

    private void setSystemBars(String color, boolean lightIcons) {
        try {
            lastSystemBarColor = color;
            lastLightIcons = lightIcons;
            Window window = getWindow();
            int parsed = Color.parseColor(color);
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // Transparent system bars let the app background continue behind
                // the status/navigation areas while the system icons and clock stay visible.
                window.setStatusBarColor(Color.TRANSPARENT);
                window.setNavigationBarColor(Color.TRANSPARENT);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    window.setNavigationBarDividerColor(Color.TRANSPARENT);
                }
                window.getDecorView().setBackgroundColor(parsed);
            }
            // True edge-to-edge layout: the app uses the entire physical display
            // area while Android's status/navigation bars remain visible.
            // The bars are transparent and the WebView draws underneath them.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    window.setDecorFitsSystemWindows(false);
                } catch (Exception ignored) { }
            } else {
                int layoutFlags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
                window.getDecorView().setSystemUiVisibility(layoutFlags);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.setNavigationBarContrastEnforced(false);
                window.setStatusBarContrastEnforced(false);
            }
            int flags = 0;
            if (lightIcons && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            if (lightIcons && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
            try {
                WebView webView = getBridge().getWebView();
                webView.setBackgroundColor(parsed);
            } catch (Exception ignored) { }
        } catch (Exception ignored) {
            // Keep native defaults if an OEM rejects a system-bar setting.
        }
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;

        NotificationManager manager =
            (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;

        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();

        // Use the explicit /raw/<name> form. This is valid for android.resource URIs
        // and avoids ambiguity with resource IDs on OEM Android builds.
        Uri dailySound = Uri.parse("android.resource://" + getPackageName() + "/raw/notification");
        Uri salawatSound = Uri.parse("android.resource://" + getPackageName() + "/raw/salawat");

        createChannelIfMissing(manager, DAILY_CHANNEL_ID,
            "تذكير القراءة اليومية", "تنبيهات يومية لقراءة حديث اليوم وقصته", dailySound, attrs);
        createChannelIfMissing(manager, SALAWAT_CHANNEL_ID,
            "الصلاة على النبي ﷺ", "تذكير صوتي للصلاة على النبي محمد ﷺ", salawatSound, attrs);
    }

    private void createChannelIfMissing(NotificationManager manager, String id, String name,
                                       String description, Uri sound, AudioAttributes attrs) {
        if (manager.getNotificationChannel(id) != null) return;

        NotificationChannel channel = new NotificationChannel(
            id, name, NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription(description);
        channel.enableVibration(true);
        channel.setShowBadge(true);
        channel.setSound(sound, attrs);
        manager.createNotificationChannel(channel);
    }
}
JAVA


# Register the isolated TTS service in its own Android process.
python3 - <<'PY3'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text()
service='''
        <service
            android:name=".OfflineTtsService"
            android:exported="false"
            android:process=":leyh_tts" />
'''
if 'android:name=".OfflineTtsService"' not in s:
    s=s.replace('</application>', service + '    </application>', 1)
p.write_text(s)
PY3
