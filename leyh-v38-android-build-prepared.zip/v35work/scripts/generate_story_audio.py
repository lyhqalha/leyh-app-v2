#!/usr/bin/env python3
"""Generate the app's permanent story narration files with Audar-TTS-V1-Flash.

This runs during the GitHub build only. The TTS model is never copied into the APK.
It creates ordinary MP3 files under public/story-audio/<hadithId>/scene-N.mp3.
"""
from pathlib import Path
import re, subprocess, sys, urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "story-audio"
DATA_FILE = ROOT / "src" / "data" / "additionalHadiths.ts"
AUDIO_REPO = ROOT / ".audar-tts"
REF = ROOT / ".audar-reference.wav"
REF_URL = "https://huggingface.co/audarai/Audar-TTS-V1-Flash/resolve/main/samples/demo_male_1_ar.wav"
# This is the exact caption published by AudarAI for the synthetic demo_male_1 Arabic reference.
REF_TEXT = "لا يمكنني الانتظار لأخبرك — [excited] لقد أنجزنا المشروع أخيراً بعد كلّ هذا التعب، [laughs] وصدّقني، إنه أجمل شعورٍ على الإطلاق!"


def scenes():
    text = DATA_FILE.read_text(encoding="utf-8")
    # additionalHadiths.ts is deliberately data-only. Pair each hadith id with its scene audioText fields.
    blocks = re.findall(r"id:\s*'([^']+)'(?P<body>.*?)(?=\n\s*\},\n\n\s*//|\n\s*\}\s*,\n\s*//|\n\s*\}\s*\n\s*\])", text, re.S)
    found = []
    for hid, body in blocks:
        for n, audio_text in re.findall(r"sceneNumber:\s*(\d+).*?audioText:\s*'((?:[^'\\]|\\.)*)'", body, re.S):
            audio_text = audio_text.replace("\\'", "'").replace("\\n", " ")
            found.append((hid, int(n), audio_text))
    if not found:
        raise RuntimeError("No story scenes were found in additionalHadiths.ts")
    return found


def run(cmd, cwd=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    items = scenes()
    print(f"Found {len(items)} story scenes", flush=True)

    if not AUDIO_REPO.exists():
        run(["git", "clone", "--depth", "1", "https://github.com/AudarAI/Audar-TTS-V1.git", str(AUDIO_REPO)])
    if not REF.exists():
        print("Downloading Audar's free synthetic demo_male_1 reference...", flush=True)
        urllib.request.urlretrieve(REF_URL, REF)

    # Install the official inference dependencies once in the build environment.
    run([sys.executable, "-m", "pip", "install", "-r", str(AUDIO_REPO / "examples" / "requirements.txt")])
    run([sys.executable, "-m", "pip", "install", "llama-cpp-python", "neucodec", "soundfile", "torch", "librosa", "huggingface_hub"])

    synth = AUDIO_REPO / "examples" / "synthesize_gguf.py"
    for hid, n, text in items:
        out_dir = OUT / hid
        out_dir.mkdir(parents=True, exist_ok=True)
        wav = out_dir / f"scene-{n}.wav"
        mp3 = out_dir / f"scene-{n}.mp3"
        if mp3.exists() and mp3.stat().st_size > 10000:
            continue
        # Gentle storyteller direction: natural pauses and restrained expression rather than a flat read.
        target = f"[exhales] {text}"
        run([
            sys.executable, str(synth), target,
            "--ref", str(REF), "--ref-text", REF_TEXT,
            "--tier", "flash", "--out", str(wav), "--gpu-layers", "0"
        ], cwd=AUDIO_REPO)
        run(["ffmpeg", "-y", "-i", str(wav), "-codec:a", "libmp3lame", "-b:a", "96k", str(mp3)])
        wav.unlink(missing_ok=True)
    print("Story audio generation complete.", flush=True)


if __name__ == "__main__":
    main()
