#!/usr/bin/env python3
"""Generate permanent story narration MP3s once during CI.

Uses Audar-TTS-V1-Flash GGUF + the free synthetic demo_male_1 Arabic reference.
The model is used only on the GitHub runner and is NEVER bundled into the APK.
The model and codec are loaded once, then all story scenes are generated.
"""
from pathlib import Path
import re
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "story-audio"
DATA_FILE = ROOT / "src" / "data" / "additionalHadiths.ts"
AUDIO_REPO = ROOT / ".audar-tts"
REF = ROOT / ".audar-reference.wav"
REF_URL = "https://huggingface.co/audarai/Audar-TTS-V1-Flash/resolve/main/samples/demo_male_1_ar.wav"
REF_TEXT = "لا يمكنني الانتظار لأخبرك — [excited] لقد أنجزنا المشروع أخيراً بعد كلّ هذا التعب، [laughs] وصدّقني، إنه أجمل شعورٍ على الإطلاق!"


def scenes():
    text = DATA_FILE.read_text(encoding="utf-8")
    blocks = re.findall(
        r"id:\s*'([^']+)'(?P<body>.*?)(?=\n\s*\},\n\n\s*//|\n\s*\}\s*,\n\s*//|\n\s*\}\s*\n\s*\])",
        text,
        re.S,
    )
    found = []
    for hid, body in blocks:
        for n, audio_text in re.findall(
            r"sceneNumber:\s*(\d+).*?audioText:\s*'((?:[^'\\]|\\.)*)'",
            body,
            re.S,
        ):
            audio_text = audio_text.replace("\\'", "'").replace("\\n", " ")
            found.append((hid, int(n), audio_text))
    if not found:
        raise RuntimeError("No story scenes were found in additionalHadiths.ts")
    return found


def run(cmd, cwd=None):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.run(cmd, cwd=cwd, check=True)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    items = scenes()
    print(f"Found {len(items)} permanent story scenes", flush=True)

    if not AUDIO_REPO.exists():
        run([
            "git", "clone", "--depth", "1",
            "https://github.com/AudarAI/Audar-TTS-V1.git",
            str(AUDIO_REPO),
        ])

    if not REF.exists():
        print("Downloading Audar demo_male_1 Arabic reference...", flush=True)
        urllib.request.urlretrieve(REF_URL, REF)

    # IMPORTANT: do NOT install Audar's Transformers requirements here.
    # The CI uses the official GGUF/llama.cpp path, which avoids the
    # torch/torchao/torchaudio version conflict that broke previous runs.
    run([
        sys.executable, "-m", "pip", "install", "--upgrade",
        "llama-cpp-python", "neucodec", "soundfile", "librosa", "huggingface_hub"
    ])

    sys.path.insert(0, str(AUDIO_REPO))
    from audar_tts import HF_REPOS, OUT_SR, build_prompt, encode_reference
    import soundfile as sf
    import torch
    from huggingface_hub import hf_hub_download
    from llama_cpp import Llama
    from neucodec import NeuCodec

    print("Loading Audar Flash GGUF once...", flush=True)
    gguf = hf_hub_download(
        HF_REPOS["flash"],
        "Audar-TTS-V1-Flash-Q4_K_M.gguf",
    )
    llm = Llama(model_path=gguf, n_ctx=4096, n_gpu_layers=0, verbose=False)
    codec = NeuCodec.from_pretrained("neuphonic/neucodec").eval()
    ref_codes = encode_reference(codec, str(REF))
    ref_text = REF_TEXT
    print("Audar model loaded. Generating scenes...", flush=True)

    end_token = llm.tokenize(b"<|TARGET_CODES_END|>", add_bos=False, special=True)[0]

    for index, (hid, n, text) in enumerate(items, 1):
        out_dir = OUT / hid
        out_dir.mkdir(parents=True, exist_ok=True)
        wav_path = out_dir / f"scene-{n}.wav"
        mp3_path = out_dir / f"scene-{n}.mp3"

        if mp3_path.exists() and mp3_path.stat().st_size > 10000:
            print(f"[{index}/{len(items)}] exists: {mp3_path}", flush=True)
            continue

        # Storyteller direction: natural breathing plus restrained expression.
        target = f"[exhales] {text}"
        prompt = build_prompt(target, ref_text, ref_codes)
        toks = llm.tokenize(prompt.encode("utf-8"), add_bos=False, special=True)
        ids = []
        for tid in llm.generate(toks, temp=0.85, top_k=40, top_p=0.9, repeat_penalty=1.1):
            if tid == end_token or len(ids) >= 2048:
                break
            ids.append(tid)

        generated = "".join(
            llm.detokenize([t], special=True).decode("utf-8", "ignore")
            for t in ids
        )
        codes = [int(x) for x in re.findall(r"<\|speech_(\d+)\|>", generated)]
        if not codes:
            raise RuntimeError(f"Audar generated no speech codes for {hid} scene {n}")

        wav = codec.decode_code(torch.tensor(codes)[None, None, :]).cpu().numpy()[0, 0, :]
        sf.write(str(wav_path), wav, OUT_SR)
        run([
            "ffmpeg", "-y", "-loglevel", "error",
            "-i", str(wav_path),
            "-codec:a", "libmp3lame", "-b:a", "96k",
            str(mp3_path),
        ])
        wav_path.unlink(missing_ok=True)
        print(f"[{index}/{len(items)}] generated: {mp3_path}", flush=True)

    print("Story audio generation complete.", flush=True)


if __name__ == "__main__":
    main()
