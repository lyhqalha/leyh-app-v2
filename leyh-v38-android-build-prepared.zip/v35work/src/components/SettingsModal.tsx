import React, { useState } from 'react';
import { audioEngine, SOLEMN_VOICE } from '../utils/audioService';
import {
  X,
  Type,
  Sparkles,
  Info,
  Heart,
  Flame,
  Mic,
  Moon,
  Bell,
  Clock,
  Check,
  Play,
  Square,
  Sun,
  WifiOff,
  Trash2
} from 'lucide-react';

interface SettingsModalProps {
  isOpen?: boolean;
  onClose: () => void;
  // Font size
  fontSize?: 'sm' | 'md' | 'lg' | 'normal' | 'large' | 'xlarge';
  onChangeFontSize?: (size: any) => void;
  // Theme mode (الوضع الافتراضي / وضع النهار / الوضع المظلم الفائق)
  themeMode?: 'default' | 'light';
  onChangeThemeMode?: (mode: 'default' | 'light') => void;
  // Daily reminder
  isReminderEnabled: boolean;
  onToggleReminder: (enabled: boolean) => void;
  reminderTime: string;
  onChangeReminderTime: (time: string) => void;
  onTriggerTestReminder?: () => void;
  onTestReminder?: () => void;
  // Salawat reminder
  isSalawatReminderEnabled?: boolean;
  onToggleSalawatReminder?: (enabled: boolean) => void;
  salawatInterval?: 30 | 60;
  onChangeSalawatInterval?: (interval: 30 | 60) => void;
  onTestSalawat?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen = true,
  onClose,
  fontSize = 'md',
  onChangeFontSize,
  themeMode = 'default',
  onChangeThemeMode,
  isReminderEnabled,
  onToggleReminder,
  reminderTime,
  onChangeReminderTime,
  onTriggerTestReminder,
  onTestReminder,
  isSalawatReminderEnabled = false,
  onToggleSalawatReminder,
  salawatInterval = 30,
  onChangeSalawatInterval,
  onTestSalawat,
}) => {
  const [internalFontSize, setInternalFontSize] = useState<'normal' | 'large' | 'xlarge'>('normal');
  const [isTestingVoice, setIsTestingVoice] = useState(false);
  const [testNotificationSent, setTestNotificationSent] = useState(false);
  const [activeInfoPanel, setActiveInfoPanel] = useState<'stats' | 'about' | null>(null);


  if (!isOpen) return null;

  const handleTestVoice = () => {
    if (isTestingVoice) {
      audioEngine.stopSpeaking();
      setIsTestingVoice(false);
    } else {
      setIsTestingVoice(true);
      audioEngine.testSample(SOLEMN_VOICE.pitch, SOLEMN_VOICE.rate, () => {
        setIsTestingVoice(false);
      });
    }
  };

  const handleTriggerTestReminder = () => {
    if (onTriggerTestReminder) {
      onTriggerTestReminder();
    } else if (onTestReminder) {
      onTestReminder();
    }
    setTestNotificationSent(true);
    setTimeout(() => {
      setTestNotificationSent(false);
    }, 3000);
  };

  const REMINDER_PRESETS = [
    { label: 'فجراً', time: '05:30' },
    { label: 'صباحاً', time: '09:00' },
    { label: 'عصراً', time: '16:30' },
    { label: 'مساءً', time: '21:00' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className={`settings-modal relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh] ${themeMode === 'light' ? 'settings-modal-light' : ''}`}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773]">
              <Sparkles className="w-4 h-4" />
            </div>
            <h2 className="text-base font-bold text-white">إعدادات التطبيق</h2>
          </div>
          <button
            onClick={() => {
              if (isTestingVoice) audioEngine.stopSpeaking();
              onClose();
            }}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Shortcuts requested for Settings */}
          <div className="grid grid-cols-2 gap-3">
            <button type="button" onClick={() => setActiveInfoPanel(activeInfoPanel === 'stats' ? null : 'stats')} className={`min-h-[150px] rounded-[24px] border p-4 text-right transition-colors ${activeInfoPanel === 'stats' ? 'border-amber-400 bg-[#182238]' : 'border-amber-500/40 bg-[#0D131F] hover:border-amber-400/70'}`}>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-bold text-white leading-6">إحصائياتي والمهمة</span>
                <span className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0"><Flame className="w-6 h-6" /></span>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-400">سلسلة الأيام والأوسمة</p>
            </button>
            <button type="button" onClick={() => setActiveInfoPanel(activeInfoPanel === 'about' ? null : 'about')} className={`min-h-[150px] rounded-[24px] border p-4 text-right transition-colors ${activeInfoPanel === 'about' ? 'border-rose-400 bg-[#182238]' : 'border-rose-500/40 bg-[#0D131F] hover:border-rose-400/70'}`}>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-bold text-white leading-6">عن التطبيق</span>
                <span className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0"><Heart className="w-6 h-6 fill-current" /></span>
              </div>
              <p className="mt-3 text-sm leading-6 text-slate-400">دعوة تظهر في الغيب</p>
            </button>
          </div>

          {activeInfoPanel === 'stats' && (
            <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-4 space-y-2 animate-fadeIn">
              <h3 className="font-bold text-white flex items-center gap-2"><Flame className="w-5 h-5 text-amber-400" /> إحصائياتي والمهمة</h3>
              <p className="text-sm text-slate-300 leading-7">اجعل لك وردًا يوميًا من الأحاديث النبوية. عد إلى التطبيق كل يوم للمحافظة على استمرارية القراءة، واحتسب الأجر عند الله.</p>
              <p className="text-xs text-slate-500">سيتم عرض سلسلة الأيام والأوسمة عند توفر سجل قراءة يومي محفوظ في التطبيق.</p>
            </div>
          )}

          {activeInfoPanel === 'about' && (
            <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-4 space-y-2 animate-fadeIn">
              <h3 className="font-bold text-white flex items-center gap-2"><Info className="w-5 h-5 text-[#E2B773]" /> رسالة تطبيق «ليه قالها؟»</h3>
              <p className="text-sm text-slate-300 leading-7">تطبيق «ليه قالها؟» تطبيق إيماني خيري مجاني، يهدف إلى نشر الأحاديث النبوية الصحيحة والتعريف بأسباب ورودها وقصصها بأسلوب بسيط وميسر، يساعدنا على فهم سنة النبي محمد ﷺ والاقتداء به في حياتنا اليومية.</p>
              <p className="text-sm text-slate-300 leading-7">يضم التطبيق أكثر من 2000 حديث نبوي، مع قصص ومواقف وعِبر وفوائد إيمانية، لنقترب من هدي النبي ﷺ، ونجعل تعلُّم سنته جزءًا من يومنا.</p>
              <p className="text-sm text-slate-400 leading-7">نسأل الله أن يجعل هذا العمل خالصًا لوجهه الكريم، وأن ينفع به كل من قرأ أو تعلّم أو ساهم في نشر الخير، وأن يجعله صدقة جارية لنا ولوالدينا ولجميع المسلمين.</p>
              <div className="border-t border-slate-800 pt-3 mt-3 space-y-2">
                <p className="text-sm text-slate-200 leading-7">أرجو أن يكون هذا التطبيق سببًا في نشر الخير والمحبة، وأن يترك أثرًا طيبًا في قلوبكم، ولو بحديث واحد غيّر يومًا أو أصلح قلبًا.</p>
                <p className="text-sm text-[#E2B773] font-bold leading-7">أخوكم ومحبكم في الله<br />أحمد بدوي أحمد رضوان</p>
                <p className="text-sm text-slate-400">لا تنسونا من صالح دعائكم، ولكم بالمثل وأكثر بإذن الله. ❤️</p>
                <p className="text-sm text-slate-400">للتواصل مع مطوّر التطبيق: <a className="text-emerald-400 underline" href="mailto:lyhqalha@gmail.com">lyhqalha@gmail.com</a></p>
              </div>
            </div>
          )}

          {/* Saved audio files (offline) */}
          <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-5 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <WifiOff className="w-5 h-5 text-emerald-400 shrink-0" />
                <h3 className="font-bold text-slate-100 text-sm leading-6">الصوتيات المحفوظة بدون إنترنت (أوفلاين)</h3>
              </div>
              <span className="text-emerald-400 text-sm font-bold text-left">0 ملف<br /><span className="text-xs">(0 ميجابايت)</span></span>
            </div>
            <p className="text-sm leading-7 text-slate-400">
              يمكنك حفظ أي حديث أو قصة للاستماع إليها دون اتصال بالإنترنت. لا توجد ملفات صوتية محفوظة محليًا في هذه النسخة حتى الآن.
            </p>
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <span className="text-xs text-slate-500">المساحة المستخدمة في الذاكرة: 0 MB</span>
              <button
                type="button"
                onClick={async () => {
                  try {
                    if ('caches' in window) {
                      const cacheNames = await caches.keys();
                      await Promise.all(cacheNames.filter(name => /audio|story/i.test(name)).map(name => caches.delete(name)));
                    }
                    Object.keys(localStorage).filter(key => /saved.*audio|audio.*saved|offline.*audio/i.test(key)).forEach(key => localStorage.removeItem(key));
                  } catch (error) {
                    console.warn('تعذر تنظيف ملفات الصوت المحفوظة', error);
                  }
                }}
                className="rounded-2xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-rose-300 font-bold text-sm flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>تفريغ الذاكرة وحذف كل الملفات</span>
              </button>
            </div>
          </div>

          {/* 1. Theme / Appearance Modes */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-2 text-sm">
                <Moon className="w-4 h-4 text-[#E2B773]" />
                <span>مظهر التطبيق</span>
              </span>
              <span className="text-xs text-[#E2B773] font-semibold">{themeMode === 'light' ? 'وضع النهار' : 'الكحلي الليلي'}</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button onClick={() => onChangeThemeMode?.('default')} className={`day-theme-option p-3 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${themeMode === 'default' ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773] font-bold shadow-md' : 'border-slate-800 bg-[#131B2E] text-slate-400 hover:text-slate-200'}`}>
                <Moon className="w-5 h-5 text-[#E2B773]" />
                <span className="text-xs">الكحلي الليلي</span>
              </button>
              <button onClick={() => onChangeThemeMode?.('light')} className={`day-theme-option p-3 rounded-xl border flex flex-col items-center text-center gap-1.5 transition-all ${themeMode === 'light' ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773] font-bold shadow-md' : 'border-slate-800 bg-[#131B2E] text-slate-400 hover:text-slate-200'}`}>
                <Sun className="w-5 h-5 text-amber-500" />
                <span className="text-xs">وضع النهار</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed pt-1">
              {themeMode === 'light' ? 'وضع النهار يوفر خلفية فاتحة ومريحة للقراءة.' : 'الكحلي الليلي هو المظهر الأساسي الهادئ والمريح للعين.'}
            </p>
          </div>

          {/* 2. Daily Reading Reminder (تذكير القراءة اليومي) */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Bell className={`w-4 h-4 ${isReminderEnabled ? 'text-[#E2B773]' : 'text-slate-400'}`} />
                <span>تذكير القراءة اليومي</span>
              </span>
              <button
                onClick={() => onToggleReminder(!isReminderEnabled)}
                className={`settings-toggle relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                  isReminderEnabled ? 'bg-[#E2B773] is-on' : 'bg-slate-800'
                }`}
                title="تفعيل أو تعطيل التذكير اليومي"
              >
                <span
                  className={`settings-toggle-knob inline-block h-4 w-4 transform rounded-full transition-transform ${
                    isReminderEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              تنبيه بسيط يومي يذكرك بقراءة حديث اليوم وتدبر سبب وروده النبوي الشريف في وقت تختاره.
            </p>

            {isReminderEnabled && (
              <div className="pt-2 border-t border-slate-800/80 space-y-2.5 animate-fadeIn">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#E2B773]" />
                    <span>حدد وقت التنبيه:</span>
                  </span>
                  <input
                    type="time"
                    value={reminderTime}
                    onChange={(e) => onChangeReminderTime(e.target.value)}
                    className="bg-[#141C2E] border border-slate-700 text-[#E2B773] font-mono font-bold text-xs px-2.5 py-1 rounded-xl focus:outline-none focus:border-[#E2B773]"
                  />
                </div>

                {/* Quick Presets */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {REMINDER_PRESETS.map((p) => (
                    <button
                      key={p.time}
                      onClick={() => onChangeReminderTime(p.time)}
                      className={`settings-preset py-1 px-1 rounded-lg text-center transition-all text-[10px] ${
                        reminderTime === p.time
                          ? 'bg-[#E2B773] text-[#0D131F] font-bold shadow-sm is-selected'
                          : 'bg-[#141C2E] text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                {/* Test Notification Button */}
                <div className="pt-1 flex items-center justify-between gap-2">
                  <button
                    onClick={handleTriggerTestReminder}
                    className="settings-test-button w-full py-1.5 px-3 rounded-xl active:scale-98 text-[11px] font-semibold flex items-center justify-center gap-2 transition-all"
                  >
                    <Bell className="w-3.5 h-3.5 text-[#E2B773]" />
                    <span>{testNotificationSent ? 'تم إرسال إشعار تجريبي بنجاح!' : 'تجربة الإشعار الآن'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 3. Salawat reminder */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Bell className={`w-4 h-4 ${isSalawatReminderEnabled ? 'text-[#E2B773]' : 'text-slate-400'}`} />
                <span>تذكير: صلِّ على محمد ﷺ</span>
              </span>
              <button
                onClick={() => onToggleSalawatReminder?.(!isSalawatReminderEnabled)}
                className={`settings-toggle relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${
                  isSalawatReminderEnabled ? 'bg-[#E2B773] is-on' : 'bg-slate-800'
                }`}
                title="تفعيل أو تعطيل تذكير الصلاة على النبي ﷺ"
              >
                <span className={`settings-toggle-knob inline-block h-4 w-4 transform rounded-full transition-transform ${
                  isSalawatReminderEnabled ? 'translate-x-6' : 'translate-x-1'
                }`} />
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              تذكير صوتي هادئ يقول «صلِّ على محمد ﷺ» خارج التطبيق.
            </p>
            {isSalawatReminderEnabled && (
              <>
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => onChangeSalawatInterval?.(30)}
                  className={`py-2 rounded-xl border text-xs font-bold ${
                    salawatInterval === 30
                      ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773]'
                      : 'border-slate-800 bg-[#141C2E] text-slate-400'
                  }`}
                >
                  كل 30 دقيقة
                </button>
                <button
                  onClick={() => onChangeSalawatInterval?.(60)}
                  className={`py-2 rounded-xl border text-xs font-bold ${
                    salawatInterval === 60
                      ? 'border-[#E2B773] bg-[#E2B773]/15 text-[#E2B773]'
                      : 'border-slate-800 bg-[#141C2E] text-slate-400'
                  }`}
                >
                  كل ساعة
                </button>
              </div>
              <button
                onClick={() => onTestSalawat?.()}
                className="settings-salawat-test w-full mt-2 py-2 rounded-xl text-xs font-bold transition-all"
              >
                تجربة «صلِّ على محمد ﷺ» الآن (بعد 5 ثوانٍ)
              </button>
              </>
            )}
          </div>

          {/* 3. Dignified Voice Settings (نبرة صوت واحدة: وقور عميق) */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Mic className="w-4 h-4 text-[#E2B773]" />
                <span>نبرة الصوت: وقور عميق</span>
              </span>
              <span className="px-2 py-0.5 rounded-full bg-[#E2B773]/15 text-[#E2B773] text-[10px] font-bold border border-[#E2B773]/30">
                صوت واحد فقط
              </span>
            </div>
            
            <p className="text-[11px] text-slate-400 leading-relaxed">
              تم اعتماد صوت واحد فقط بنبرة وقورة وعميقة ذات هيبة وسكينة تامة، وتمت إزالة كافة الأصوات الأخرى لتوفير أفضل تجربة استماع مركزة للحديث النبوي وقصته.
            </p>

            {/* Test Voice Sample Button */}
            <div className="pt-1">
              <button
                onClick={handleTestVoice}
                className={`settings-voice-test w-full py-2 px-3 rounded-xl border flex items-center justify-center gap-2 font-bold transition-all text-xs ${
                  isTestingVoice
                    ? 'bg-rose-500/20 border-rose-500/40 text-rose-300 animate-pulse'
                    : 'bg-[#141C2E] border-slate-700/80 hover:border-[#E2B773]/50 text-slate-200'
                }`}
              >
                {isTestingVoice ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>إيقاف تجربة الصوت</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current text-[#E2B773]" />
                    <span>تجربة نبرة الصوت الوقور العميق الآن</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* 4. Font Size Setting */}
          <div className="p-3.5 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2">
            <span className="font-bold text-slate-200 block">حجم الخط لقراءة القصة</span>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'sm', altId: 'normal', label: 'طبيعي' },
                { id: 'md', altId: 'large', label: 'كبير' },
                { id: 'lg', altId: 'xlarge', label: 'كبير جداً' }
              ].map((item) => {
                const isSelected = fontSize === item.id || fontSize === item.altId;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      if (onChangeFontSize) {
                        onChangeFontSize(item.id as any);
                      }
                      setInternalFontSize(item.altId as any);
                    }}
                    className={`day-font-option p-2 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] font-bold'
                        : 'border-slate-800 text-slate-300 hover:bg-slate-800/60'
                    }`}
                  >
                    <Type className="w-3.5 h-3.5 mx-auto mb-1 opacity-70" />
                    <span className="text-xs">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5. About */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 flex items-start gap-3">
            <Info className="w-5 h-5 text-[#E2B773] shrink-0 mt-0.5" />
            <div className="text-xs text-slate-400 space-y-2 leading-relaxed">
              <span className="font-bold text-white block text-sm">عن تطبيق «ليه قالها؟»</span>
              <p>
                «ليه قالها؟» مساحة هادئة للتأمل في الحديث النبوي؛ لا نكتفي بنقل الحديث، بل نقترب من قصته وسياقه وسبب وروده، حتى نقرأه بفهمٍ أعمق ونعي أثره في حياتنا.
              </p>
              <p>
                صُمّم هذا التطبيق ابتغاءً لوجه الله تعالى، رغبةً في نشر العلم النافع وإحياء قصص السنة بأسلوب يسير وجميل. نسأل الله أن يتقبّل هذا العمل، وأن ينفع به كل من قرأ أو تعلّم أو شارك.
              </p>
              <p className="text-[#E2B773] font-semibold pt-1">
                لا تنسوا مطوّر التطبيق من صالح دعائكم؛
                <br />
                <strong className="text-white text-xs">أحمد بدوي أحمد رضوان</strong>
                <br />
                لعل دعوةً صادقة تكون أجمل ما يُهدى لصاحب هذا العمل.
              </p>
              <a
                href="mailto:lyhqalha@gmail.com"
                className="inline-flex items-center text-[#E2B773] font-semibold pt-1 hover:underline"
              >
                للتواصل مع مطوّر التطبيق: lyhqalha@gmail.com
              </a>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="settings-modal-footer p-4 border-t border-slate-800 bg-[#0D131F] flex justify-end">
          <button
            onClick={() => {
              if (isTestingVoice) audioEngine.stopSpeaking();
              onClose();
            }}
            className="settings-save-button px-5 py-2 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5"
          >
            <Check className="w-3.5 h-3.5" />
            <span>حفظ وإغلاق</span>
          </button>
        </div>
      </div>
    </div>
  );
};
