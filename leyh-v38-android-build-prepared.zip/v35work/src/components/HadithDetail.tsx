import React, { useState } from 'react';
import { HadithItem } from '../types/hadith';
import { mosqueMinaretImage } from '../data/hadiths';
import { audioEngine } from '../utils/audioService';
import { HadithReciterPlayer } from './HadithReciterPlayer';
import {
  ArrowRight,
  Bookmark,
  Share2,
  Volume2,
  Play,
  Pause,
  Sparkles,
  CheckCircle2,
  BookOpen,
  History
} from 'lucide-react';

interface HadithDetailProps {
  hadith: HadithItem;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onBack: () => void;
  onOpenStory: () => void;
  onOpenShareCard: () => void;
  onOpenAudioPlayer: () => void;
}

export const HadithDetail: React.FC<HadithDetailProps> = ({
  hadith,
  isBookmarked,
  onToggleBookmark,
  onBack,
  onOpenStory,
  onOpenShareCard,
  onOpenAudioPlayer,
}) => {

  return (
    <div className="relative w-full min-h-screen bg-[#0D131F] text-slate-100 flex flex-col pb-24">
      {/* Top Media Header */}
      <div className="relative w-full h-56 sm:h-64 overflow-hidden">
        <img
          src={mosqueMinaretImage}
          alt="المسجد النبوي"
          className="w-full h-full object-cover filter brightness-[0.7]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D131F] via-[#0D131F]/30 to-black/40" />

        {/* Header Icons */}
        <div className="absolute top-4 inset-x-4 flex items-center justify-between z-10">
          <button
            onClick={onBack}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-center text-white hover:bg-black/60 transition-colors"
            title="رجوع"
          >
            <ArrowRight className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleBookmark(hadith.id)}
              className={`w-10 h-10 rounded-full backdrop-blur-md border flex items-center justify-center transition-all ${
                isBookmarked
                  ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F]'
                  : 'bg-black/40 border-white/10 text-white hover:bg-black/60'
              }`}
              title={isBookmarked ? 'إزالة من المحفوظات' : 'حفظ الحديث'}
            >
              <Bookmark className={`w-5 h-5 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={onOpenShareCard}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md border border-white/10 flex items-center justify-center text-white hover:bg-black/60 transition-colors"
              title="مشاركة الحديث"
            >
              <Share2 className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Topic Tag on Header */}
        <div className="absolute bottom-4 right-4 z-10 flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-[#E2B773] text-[#0D131F] text-xs font-bold shadow">
            {hadith.topic}
          </span>
          <span className="text-xs text-slate-300 font-mono">
            رقم: {hadith.hadith_number}
          </span>
        </div>
      </div>

      {/* Main Container */}
      <div className="px-4 -mt-4 relative z-20 max-w-xl mx-auto w-full space-y-4">
        
        {/* Main Hadith Parchment Card */}
        <div className="rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-700/60 bg-[#131B2E]">
          
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-[#E2B773] flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              <span>الحديث الشريف</span>
            </h3>
            <button
              onClick={onOpenStory}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#E2B773]/15 hover:bg-[#E2B773]/25 text-xs text-[#E2B773] border border-[#E2B773]/30 font-bold transition-all"
            >
              <History className="w-3.5 h-3.5" />
              <span>الاستماع للقصة</span>
            </button>
          </div>

          {/* مكان الاستماع إلى الحديث: شريط صوتي وفوقه الحديث مكتوب */}
          <div className="my-5">
            <HadithReciterPlayer
              hadithText={hadith.hadith_text}
              narrator={hadith.narrator}
              source={hadith.source}
              variant="card"
              showText={true}
            />
          </div>

          {/* Takhrij & Metadata */}
          <div className="bg-[#0D131F] rounded-2xl p-4 border border-slate-800/80 grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block mb-0.5">الراوي:</span>
              <span className="text-slate-200 font-medium">{hadith.narrator}</span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">المصدر:</span>
              <span className="text-slate-200 font-medium">{hadith.source}</span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">الكتاب:</span>
              <span className="text-slate-200 font-medium">{hadith.book}</span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">درجة الحديث:</span>
              <span className="text-emerald-400 font-bold inline-flex items-center gap-1">
                <span>{hadith.authenticity_grade}</span>
                <CheckCircle2 className="w-3.5 h-3.5" />
              </span>
            </div>
          </div>
        </div>

        {/* Explanation Card */}
        <div className="rounded-3xl p-6 bg-[#131B2E] border border-slate-800/80 shadow-lg">
          <h4 className="text-sm font-bold text-slate-200 flex items-center gap-2 mb-3">
            <BookOpen className="w-4 h-4 text-[#E2B773]" />
            <span>شرح الحديث</span>
          </h4>
          <p className="text-sm text-slate-300 leading-relaxed">
            {hadith.explanation}
          </p>
        </div>

        {/* Practical Lessons Card */}
        <div className="rounded-3xl p-6 bg-[#131B2E] border border-slate-800/80 shadow-lg">
          <h4 className="text-sm font-bold text-slate-200 flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>الدروس المستفادة</span>
          </h4>
          <ul className="space-y-2.5 text-xs sm:text-sm text-slate-300">
            {hadith.practical_lesson.map((lesson, idx) => (
              <li key={idx} className="flex items-start gap-2.5">
                <span className="w-1.5 h-1.5 rounded-full bg-[#E2B773] mt-2 shrink-0" />
                <span className="leading-relaxed">{lesson}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Story Context summary card */}
        <div className="rounded-3xl p-6 bg-gradient-to-r from-amber-950/20 to-[#131B2E] border border-amber-900/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-[#E2B773]">سبب الورود والقصة التاريخية</span>
            <span className="text-[11px] text-slate-400">{hadith.context_source}</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed mb-4">
            {hadith.context}
          </p>
          <button
            onClick={onOpenStory}
            className="w-full py-2.5 px-4 rounded-xl bg-[#E2B773]/20 hover:bg-[#E2B773]/30 border border-[#E2B773]/40 text-[#E2B773] text-xs font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <Sparkles className="w-4 h-4" />
            <span>الاستماع للقصة (5 مشاهد)</span>
          </button>
        </div>
      </div>

      {/* Sticky Bottom Actions Bar (matches mockup: حفظ / استماع الحديث / مشاركة) */}
      <div className="day-action-bar fixed bottom-0 inset-x-0 z-30 p-3 bg-[#0D131F]/95 backdrop-blur-md border-t border-slate-800 flex items-center justify-center">
        <div className="flex items-center gap-2 max-w-md w-full">
          <button
            onClick={() => onToggleBookmark(hadith.id)}
            className={`day-action-button flex-1 py-3 px-3 rounded-2xl font-bold text-xs flex items-center justify-center gap-1.5 border transition-all ${
              isBookmarked
                ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F]'
                : 'bg-slate-800 border-slate-700 text-slate-200 hover:text-white'
            }`}
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
            <span>{isBookmarked ? 'محفوظ' : 'حفظ'}</span>
          </button>

          <button
            onClick={onOpenAudioPlayer}
            className="flex-1 py-3 px-3 rounded-2xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 hover:text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all"
            title="استماع الحديث"
          >
            <Volume2 className="w-4 h-4 text-[#E2B773]" />
            <span>استماع الحديث</span>
          </button>

          <button
            onClick={onOpenShareCard}
            className="flex-1 py-3 px-3 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-bold text-xs flex items-center justify-center gap-1.5 shadow transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>مشاركة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
