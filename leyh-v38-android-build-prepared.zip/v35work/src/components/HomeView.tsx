import React, { useMemo, useState } from 'react';
import { HadithItem, ActiveTab } from '../types/hadith';
import { desertHeroImage } from '../data/hadiths';
import { getDailyHadith, formatShortArabicDate } from '../utils/dailyHadith';
import {
  Search,
  Settings,
  Play,
  Heart,
  Sparkles,
  Volume2,
  Share2,
  ChevronLeft,
  BookOpen,
  Calendar,
  Flame,
  X,
  Award,
  TrendingUp
} from 'lucide-react';

interface HomeViewProps {
  hadiths: HadithItem[];
  onOpenStory: (hadith: HadithItem) => void;
  onSelectHadith: (hadith: HadithItem) => void;
  onChangeTab: (tab: ActiveTab) => void;
  onOpenSettings: () => void;
  language?: 'ar' | 'en';
}

export const HomeView: React.FC<HomeViewProps> = ({
  hadiths,
  onOpenStory,
  onSelectHadith,
  onChangeTab,
  onOpenSettings,
  language = 'ar',
}) => {

  // Automatically rotates every single day across all 2000 hadiths
  const featuredHadith = useMemo(() => getDailyHadith(hadiths, new Date()), [hadiths]);
  const todayArabicDate = useMemo(() => formatShortArabicDate(new Date(), language), [language]);
  const [showReadingStreak, setShowReadingStreak] = useState(false);
  const [showCharityInfo, setShowCharityInfo] = useState(false);
  const [readingDays, setReadingDays] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('leh_qalha_reading_days');
      return saved ? JSON.parse(saved) : [];
    } catch { return []; }
  });
  const todayKey = new Date().toISOString().slice(0, 10);
  const hasReadToday = readingDays.includes(todayKey);
  const streakCount = useMemo(() => {
    const days = new Set(readingDays);
    let count = 0;
    const cursor = new Date();
    if (!days.has(todayKey)) cursor.setDate(cursor.getDate() - 1);
    while (days.has(cursor.toISOString().slice(0, 10))) {
      count++;
      cursor.setDate(cursor.getDate() - 1);
    }
    return count;
  }, [readingDays, todayKey]);
  const markReadToday = () => {
    const next = Array.from(new Set([...readingDays, todayKey]));
    setReadingDays(next);
    try { localStorage.setItem('leh_qalha_reading_days', JSON.stringify(next)); } catch {}
  };

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto space-y-5">
      {/* Top Header */}
      <header className="flex items-center justify-between pt-2">
        <button
          onClick={() => onChangeTab('search')}
          className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
          title="البحث"
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Center Logo Branding matching mockup */}
        <div className="text-center flex flex-col items-center">
          {/* Mosque Dome and Crescent symbol */}
          <div className="flex items-center justify-center text-[#E2B773] mb-0.5">
            <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
              <path d="M12 2C10.5 4 9 6.5 9 9C9 10.66 10.34 12 12 12C13.66 12 15 10.66 15 9C15 6.5 13.5 4 12 2ZM4 19V11C4 10.45 4.45 10 5 10H6V19H4ZM18 10H19C19.55 10 20 10.45 20 11V19H18V10ZM8 19V11.5C8 9.5 9.8 8 12 8C14.2 8 16 9.5 16 11.5V19H8ZM3 21H21V22H3V21Z" />
            </svg>
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight leading-none">
            ليه قالها؟
          </h1>
          <p className="text-[11px] text-[#94A3B8] font-medium mt-1">
            كل حديث قصة قبل أن يكون كلمة
          </p>
        </div>

        {/* Header Actions: Settings only */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSettings}
            className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
            title="الإعدادات"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Featured Hero Card: حديث اليوم (matches mockup exactly) */}
      <div className="hero-card relative w-full rounded-3xl overflow-hidden border border-slate-800/80 shadow-2xl bg-[#131B2E]">
        {/* Desert artwork background */}
        <div className="relative w-full h-72 sm:h-80 overflow-hidden">
          <img
            src={desertHeroImage}
            alt="المشهد النبوي"
            className="w-full h-full object-cover filter brightness-[0.7]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#131B2E] via-[#131B2E]/40 to-black/30" />

          {/* Badge */}
          <div className="absolute top-4 inset-x-0 flex justify-center z-10">
            <span className="px-4 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-[#E2B773]/40 text-xs text-[#E2B773] font-bold flex items-center gap-1.5 shadow-lg">
              <Calendar className="w-3.5 h-3.5 text-[#E2B773]" />
              <span>حديث اليوم · {todayArabicDate}</span>
            </span>
          </div>

          {/* Center Callout */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10 pt-10">
            {/* Topic pill */}
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#131B2E]/80 backdrop-blur-md border border-slate-700/80 text-[11px] font-semibold text-[#E2B773] mb-2">
              <Sparkles className="w-3 h-3" />
              <span>{featuredHadith.topic} · {featuredHadith.narrator}</span>
            </span>

            <h3 className="text-xl sm:text-2xl font-extrabold text-white mb-1.5 max-w-sm drop-shadow">
              قبل أن تقرأ الحديث...
            </h3>
            <p className="text-xs sm:text-sm text-slate-200 mb-5 font-medium drop-shadow max-w-md line-clamp-2 px-2 text-slate-300">
              {featuredHadith.context.slice(0, 95)}...
            </p>

            {/* Start Story CTA button */}
            <button
              onClick={() => onOpenStory(featuredHadith)}
              className="py-3 px-8 rounded-full bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-sm flex items-center gap-2 shadow-xl shadow-black/40 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
              <span>ابدأ قصة اليوم</span>
            </button>
          </div>
        </div>
      </div>

      {/* Reading streak card: tap to open reading statistics and badges */}
      <button
        type="button"
        onClick={() => setShowReadingStreak(true)}
        className="w-full text-right rounded-3xl border border-[#E2B773]/50 bg-gradient-to-l from-[#1E293B] to-[#131B2E] p-4 flex items-center gap-4 active:scale-[0.99] transition-transform"
        aria-label="سلسلة القراءة اليومية والإحصائيات"
      >
        <span className="w-16 h-16 rounded-2xl bg-amber-500/15 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0"><Flame className="w-8 h-8 fill-current" /></span>
        <span className="flex-1 min-w-0">
          <span className="block font-black text-white text-lg">سلسلة القراءة: {streakCount} يوم</span>
          <span className="block text-sm text-slate-400 mt-1">قرأت {readingDays.length} يومًا · اضغط لعرض الإحصائيات والأوسمة</span>
        </span>
        <ChevronLeft className="w-5 h-5 text-amber-400 shrink-0" />
      </button>

      {showReadingStreak && (
        <div className="fixed inset-0 z-[70] bg-black/80 backdrop-blur-sm flex items-center justify-center p-3" role="dialog" aria-modal="true" aria-label="رحلتك مع سنة النبي">
          <div className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-[28px] border border-slate-700 bg-[#131B2E] text-slate-100 shadow-2xl">
            <div className="sticky top-0 z-10 flex items-center justify-between p-4 border-b border-slate-800 bg-[#0D131F] rounded-t-[28px]">
              <div className="flex items-center gap-3">
                <span className="w-10 h-10 rounded-full bg-amber-500/15 text-amber-400 flex items-center justify-center"><Flame className="w-6 h-6 fill-current" /></span>
                <div><h2 className="font-black">رحلتك مع سنة النبي ﷺ</h2><p className="text-xs text-slate-400">لوحة الإحصائيات وسلسلة الالتزام</p></div>
              </div>
              <button type="button" onClick={() => setShowReadingStreak(false)} aria-label="إغلاق" className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-slate-300"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-4 space-y-4">
              <div className="rounded-3xl border border-amber-500/40 p-4 bg-[#0D131F]">
                <div className="flex items-center justify-between gap-3">
                  <div><p className="text-sm text-slate-400">سلسلة الأيام المتتالية</p><p className="text-3xl font-black mt-1">{streakCount} <span className="text-base text-amber-300">يوم متتالٍ</span></p></div>
                  <span className="w-14 h-14 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center"><Flame className="w-8 h-8 fill-current" /></span>
                </div>
                <p className="mt-4 rounded-2xl bg-slate-800/70 p-3 text-sm text-slate-300">{hasReadToday ? 'أحسنت! تم تسجيل قراءتك اليوم، واصل المحافظة على السلسلة.' : 'بداية مباركة! اقرأ حديث اليوم وسجّل إنجازك للمحافظة على سلسلة القراءة.'}</p>
                <div className="flex justify-between items-center mt-4 text-xs text-slate-400"><span>نشاطك خلال آخر 7 أيام</span><span>{readingDays.length} يومًا مسجلًا</span></div>
                <div className="grid grid-cols-7 gap-1.5 mt-3">
                  {Array.from({length: 7}, (_, i) => {
                    const d = new Date(); d.setDate(d.getDate() - (6 - i));
                    const key = d.toISOString().slice(0, 10);
                    const done = readingDays.includes(key);
                    const labels = ['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];
                    return <div key={key} className={`rounded-xl border p-2 text-center ${done ? 'border-amber-400 bg-amber-500/15 text-amber-300' : 'border-slate-800 bg-[#131B2E] text-slate-500'}`}><div className="text-[10px]">{labels[d.getDay()]}</div><div className="text-xs mt-1">{done ? '✓' : '•'}</div></div>;
                  })}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-3 text-center"><TrendingUp className="w-5 h-5 mx-auto text-sky-400"/><p className="text-xl font-black mt-1">{readingDays.length}</p><p className="text-[10px] text-slate-400">أيام القراءة</p></div>
                <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-3 text-center"><Volume2 className="w-5 h-5 mx-auto text-emerald-400"/><p className="text-xl font-black mt-1">{readingDays.length}</p><p className="text-[10px] text-slate-400">قصص مقروءة*</p></div>
                <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-3 text-center"><BookOpen className="w-5 h-5 mx-auto text-amber-300"/><p className="text-xl font-black mt-1">{readingDays.length}</p><p className="text-[10px] text-slate-400">أيام الالتزام</p></div>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-4">
                <div className="flex items-center gap-2 font-bold"><Sparkles className="w-5 h-5 text-amber-300"/> أوسمة الإنجاز والمهمة</div>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <div className={`rounded-2xl border p-3 ${readingDays.length >= 1 ? 'border-amber-400/60 bg-amber-500/10' : 'border-slate-800 opacity-60'}`}><Award className="w-5 h-5 text-amber-300"/><p className="font-bold text-sm mt-2">البداية المباركة</p><p className="text-xs text-slate-400 mt-1">تسجيل أول يوم قراءة</p></div>
                  <div className={`rounded-2xl border p-3 ${streakCount >= 3 ? 'border-amber-400/60 bg-amber-500/10' : 'border-slate-800 opacity-60'}`}><Flame className="w-5 h-5 text-amber-300"/><p className="font-bold text-sm mt-2">همة متواصلة</p><p className="text-xs text-slate-400 mt-1">القراءة 3 أيام متتالية</p></div>
                  <div className={`rounded-2xl border p-3 ${readingDays.length >= 7 ? 'border-amber-400/60 bg-amber-500/10' : 'border-slate-800 opacity-60'}`}><Award className="w-5 h-5 text-amber-300"/><p className="font-bold text-sm mt-2">أسبوع النور</p><p className="text-xs text-slate-400 mt-1">تسجيل 7 أيام قراءة</p></div>
                  <div className={`rounded-2xl border p-3 ${readingDays.length >= 10 ? 'border-amber-400/60 bg-amber-500/10' : 'border-slate-800 opacity-60'}`}><BookOpen className="w-5 h-5 text-amber-300"/><p className="font-bold text-sm mt-2">زاد السالكين</p><p className="text-xs text-slate-400 mt-1">تسجيل 10 أيام قراءة</p></div>
                </div>
              </div>
              <button type="button" disabled={hasReadToday} onClick={markReadToday} className="w-full rounded-2xl bg-[#E2B773] text-[#0D131F] font-black py-4 disabled:opacity-60">{hasReadToday ? 'تم تسجيل قراءة اليوم ✓' : 'سجّل قراءة اليوم واحتسب الأجر'}</button>
              <p className="text-[10px] leading-5 text-slate-500">* إحصاءات القصص تُحسب هنا كأيام قراءة مسجلة، وليست عدد القصص الفعلية.</p>
            </div>
          </div>
        </div>
      )}

      {/* Charity-purpose card replaces the home quick-access buttons as requested */}
      <button
        type="button"
        onClick={() => setShowCharityInfo(true)}
        className="w-full text-right rounded-[28px] border border-rose-400/20 bg-gradient-to-l from-[#241923] via-[#131B2E] to-[#1D1720] p-5 flex items-center gap-4 active:scale-[0.99] transition-transform"
        aria-label="عمل خيري خالص لوجه الله تعالى - عن التطبيق وأهدافه"
      >
        <span className="w-16 h-16 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0"><Heart className="w-8 h-8 fill-current" /></span>
        <span className="flex-1 min-w-0">
          <span className="block font-black text-white text-lg">عمل خيري خالص لوجه الله تعالى</span>
          <span className="block text-sm text-slate-400 mt-1">عن التطبيق، أهدافه، ودعوة صالحة بظهر الغيب ❤️</span>
        </span>
        <ChevronLeft className="w-5 h-5 text-slate-400 shrink-0" />
      </button>

      {showCharityInfo && (
        <div className="fixed inset-0 z-[100] bg-[#0D131F] overflow-y-auto" role="dialog" aria-modal="true" aria-label="عن تطبيق ليه قالها">
          <div className="w-full max-w-xl min-h-screen mx-auto border-x border-slate-800 bg-[#131B2E] text-slate-100 shadow-2xl">
            <div className="sticky top-0 z-10 flex items-center justify-between gap-3 p-4 border-b border-slate-800 bg-[#0D131F]">
              <div className="text-right"><h2 className="font-black text-[#E2B773] text-lg">ليه قالها؟ — كل يوم قصة وحديث للنبي ﷺ</h2><p className="text-xs text-slate-400 mt-1">اجعل لك كل يوم دقائق مع سنة النبي ﷺ ❤️</p></div>
              <button type="button" onClick={() => setShowCharityInfo(false)} aria-label="إغلاق" className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 shrink-0"><X className="w-5 h-5" /></button>
            </div>
            <div className="p-4 pb-8 space-y-4 text-right leading-7">
              <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-4 text-slate-300">
                تطبيق «ليه قالها؟» هو تطبيق مجاني يهدف إلى نشر وتعليم أحاديث النبي محمد ﷺ وقصص من سيرته بطريقة بسيطة وسهلة، لتكون سنة النبي ﷺ أقرب إلى حياتنا اليومية.
                <p className="mt-3">يضم التطبيق أكثر من <strong className="text-[#E2B773]">2000 حديث صحيح</strong>، بالإضافة إلى قصة وفائدة ومعلومة تساعدك على التعلم والتدبر والاستفادة والعمل بالأثر.</p>
              </div>
              <div className="rounded-2xl border border-slate-800 p-4 space-y-3">
                <p>📖 أكثر من 2000 حديث صحيح من كتب السنة المعتمدة</p>
                <p>📚 قصة وفائدة وسياق تاريخي لكل حديث</p>
                <p>💡 محتوى بسيط وسهل ومناسب للجميع والأسرة</p>
                <p>❤️ رحلة يومية تفاعلية وسلسلة التزام مع سنة النبي ﷺ</p>
                <p>🆓 التطبيق مجاني بالكامل وبلا إعلانات تجارية</p>
              </div>
              <div className="rounded-2xl border border-[#E2B773]/30 bg-gradient-to-l from-[#28231E] to-[#131B2E] p-4 text-slate-300">
                <h3 className="font-black text-[#E2B773] mb-2">✨ عمل خيري خالص لوجه الله</h3>
                هذا التطبيق عمل خيري، وهدفنا أن يصل كلام النبي ﷺ إلى أكبر عدد ممكن من الناس، دون مقابل.
                <p className="border-t border-slate-700 mt-3 pt-3 font-bold text-white">وفي النهاية لا نطلب منك شيئًا واحدًا: إذا وجدت في التطبيق خيرًا، فلا تنسَ من قام عليه وأهله من دعوة صادقة بظهر الغيب.</p>
              </div>
              <div className="rounded-2xl border border-slate-800 bg-[#0D131F] p-4 text-center">
                <p className="text-slate-300">«اللهم اجعل هذا العمل خالصًا لوجهك الكريم، وانفع به كل من استخدمه أو نشره أو علّم به غيره»</p>
                <p className="text-[#E2B773] font-bold mt-3">ليه قالها؟ عشان نعرف سنة النبي ﷺ ونفهمها ونعيش بها.</p>
                <p className="text-rose-300 font-bold mt-3">❤️ دعوة لكم بظهر الغيب ❤️</p>
                <p className="text-[#E2B773] font-bold mt-4 border-t border-slate-800 pt-3">ربي تقبّل مني هذا العمل، وانفع به الناس. أخوكم في الله أحمد بدوي أحمد رضوان.</p>
                <a href="mailto:lyhqalha@gmail.com" className="inline-block mt-2 text-sky-300 underline text-sm" dir="ltr">lyhqalha@gmail.com</a>
              </div>
              <button type="button" onClick={async () => {
                const shareText = 'تطبيق ليه قالها؟ — كل يوم قصة وحديث للنبي ﷺ. تطبيق إيماني مجاني لنشر الأحاديث النبوية وقصصها. ساهم في نشر الخير.';
                try {
                  if (navigator.share) await navigator.share({ title: 'ليه قالها؟', text: shareText });
                  else if (navigator.clipboard) { await navigator.clipboard.writeText(shareText); alert('تم نسخ رسالة المشاركة، شاركها مع من تحب.'); }
                  else alert(shareText);
                } catch (e) { /* user cancelled share */ }
              }} className="w-full rounded-full bg-[#E2B773] text-[#0D131F] font-black py-3 flex items-center justify-center gap-2"><Share2 className="w-5 h-5" /> مشاركة التطبيق ولك أجر الدال على الخير</button>
              <button type="button" onClick={() => setShowCharityInfo(false)} className="w-full rounded-full border border-slate-700 bg-[#0D131F] text-slate-200 font-bold py-3">رجوع إلى الرئيسية</button>
            </div>
          </div>
        </div>
      )}

      {/* Value Proposition Highlights Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#1E293B] to-[#131B2E] border border-slate-800 flex items-center justify-around text-center text-xs text-slate-300">
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">2000+</span>
          <span className="text-[10px] text-slate-400">حديث صحيح</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">5 مشاهد</span>
          <span className="text-[10px] text-slate-400">قصة تفاعلية</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">صوتيات</span>
          <span className="text-[10px] text-slate-400">راوية هادئة</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">مشاركة</span>
          <span className="text-[10px] text-slate-400">بطاقات مصممة</span>
        </div>
      </div>

      {/* Home page ends here: the full hadith library is available from Search and Categories. */}
      <div className="flex items-center justify-between px-1 pt-1 pb-2">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-[#E2B773]" />
          <span>قصص الأحاديث النبوية ({hadiths.length} قصة متوفرة)</span>
        </h3>
        <button
          onClick={() => onChangeTab('categories')}
          className="text-xs text-[#E2B773] font-semibold hover:underline flex items-center gap-0.5"
        >
          <span>عرض التصنيفات</span>
          <ChevronLeft className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
