import React, { useRef, useState } from 'react';
import { HadithItem } from '../types/hadith';
import { X, Download, Copy, Share2, Check } from 'lucide-react';

interface ShareCardModalProps {
  hadith: HadithItem;
  onClose: () => void;
}

export const ShareCardModal: React.FC<ShareCardModalProps> = ({ hadith, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleCopyText = async () => {
    const textToCopy = `قال رسول الله ﷺ:
${hadith.hadith_text}

• الراوي: ${hadith.narrator}
• المصدر: ${hadith.source} - ${hadith.book} (رقم: ${hadith.hadith_number})
• درجة الحديث: ${hadith.authenticity_grade}

تطبيق «ليه قالها؟» - كل حديث قصة قبل أن يكون كلمة`;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `حديث شريف: ${hadith.topic}`,
          text: `${hadith.hadith_text}\n\nتطبيق ليه قالها؟`,
          url: window.location.href,
        });
      } catch {
        // User cancelled or unsupported
      }
    } else {
      handleCopyText();
    }
  };

  // High-fidelity Canvas image generator for "حفظ الصورة"
  const handleDownloadImage = () => {
    setDownloading(true);
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Card dimensions (high resolution: 1080x1350 for mobile share standard 4:5)
      canvas.width = 1080;
      canvas.height = 1350;

      // 1. Parchment background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, 1350);
      bgGrad.addColorStop(0, '#FDFBF7');
      bgGrad.addColorStop(0.5, '#F9F5EC');
      bgGrad.addColorStop(1, '#F3ECE0');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, 1080, 1350);

      // 2. Ornate Border
      ctx.strokeStyle = '#D4AF37';
      ctx.lineWidth = 4;
      ctx.strokeRect(40, 40, 1000, 1270);

      ctx.strokeStyle = 'rgba(212, 175, 55, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(52, 52, 976, 1246);

      // Corner flourishes
      const cornerSize = 40;
      const drawCorner = (x: number, y: number, signX: number, signY: number) => {
        ctx.save();
        ctx.strokeStyle = '#B38B29';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x + signX * cornerSize, y);
        ctx.lineTo(x, y);
        ctx.lineTo(x, y + signY * cornerSize);
        ctx.stroke();
        ctx.restore();
      };
      drawCorner(60, 60, 1, 1);
      drawCorner(1020, 60, -1, 1);
      drawCorner(60, 1290, 1, -1);
      drawCorner(1020, 1290, -1, -1);

      // 3. Header Mosque Silhouette & Calligraphy Header
      ctx.fillStyle = '#9C7A28';
      ctx.font = 'bold 36px "Amiri", serif';
      ctx.textAlign = 'center';
      ctx.fillText('﷽', 540, 120);

      ctx.font = '600 28px "Cairo", sans-serif';
      ctx.fillStyle = '#64748B';
      ctx.fillText('قال رسول الله ﷺ', 540, 190);

      // 4. Hadith text wrapping in Amiri font
      ctx.fillStyle = '#1A2333';
      ctx.font = 'bold 44px "Amiri", serif';
      ctx.textAlign = 'center';

      // Clean quotation for display
      const mainQuote = hadith.hadith_text.replace(/^عن.*?قال:\s*/, '');
      const words = mainQuote.split(' ');
      const lines: string[] = [];
      let currentLine = '';
      const maxWidth = 840;

      for (let i = 0; i < words.length; i++) {
        const testLine = currentLine ? `${currentLine} ${words[i]}` : words[i];
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && currentLine) {
          lines.push(currentLine);
          currentLine = words[i];
        } else {
          currentLine = testLine;
        }
      }
      if (currentLine) lines.push(currentLine);

      // Draw hadith lines
      let startY = 320;
      const lineHeight = 72;
      lines.slice(0, 7).forEach((line) => {
        ctx.fillText(line, 540, startY);
        startY += lineHeight;
      });

      // Divider line
      startY = Math.max(startY + 40, 720);
      ctx.strokeStyle = 'rgba(212, 175, 55, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(240, startY);
      ctx.lineTo(840, startY);
      ctx.stroke();

      // Diamond ornament in divider center
      ctx.fillStyle = '#D4AF37';
      ctx.beginPath();
      ctx.arc(540, startY, 6, 0, Math.PI * 2);
      ctx.fill();

      // 5. Metadata details
      ctx.textAlign = 'right';
      ctx.font = '500 28px "Cairo", sans-serif';
      ctx.fillStyle = '#475569';

      const metaY = startY + 70;
      const rightX = 740;
      ctx.fillText(`الراوي:  ${hadith.narrator}`, rightX, metaY);
      ctx.fillText(`المصدر:  ${hadith.source} (${hadith.book})`, rightX, metaY + 54);
      ctx.fillText(`رقم الحديث:  ${hadith.hadith_number}  ·  الدرجة: ${hadith.authenticity_grade}`, rightX, metaY + 108);

      // 6. Footer branding watermark
      const footerY = 1140;
      ctx.textAlign = 'center';
      
      // Crescent icon symbol
      ctx.fillStyle = '#D4AF37';
      ctx.font = 'bold 36px "Cairo", sans-serif';
      ctx.fillText(' ليه قالها؟', 540, footerY);

      ctx.fillStyle = '#94A3B8';
      ctx.font = '400 22px "Cairo", sans-serif';
      ctx.fillText('كل حديث قصة قبل أن يكون كلمة', 540, footerY + 45);

      // Trigger download
      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.download = `hadith-${hadith.hadith_number}-leh-qalha.png`;
      link.href = dataUrl;
      link.click();
    } catch {
      // Fallback
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-[#0D131F]">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <span>مشاركة الحديث الشريف</span>
          </h3>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            title="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Card Preview */}
        <div className="p-4 overflow-y-auto flex-1 flex flex-col items-center">
          {/* Authentic Islamic Card Visual */}
          <div
            ref={cardRef}
            className="w-full rounded-2xl p-6 relative shadow-xl overflow-hidden border-2 border-[#D4AF37]/50"
            style={{
              background: 'linear-gradient(180deg, #FDFBF7 0%, #F8F3E8 60%, #EFE5D3 100%)',
              color: '#1E293B'
            }}
          >
            {/* Subtle Inner Border */}
            <div className="absolute inset-2 border border-[#D4AF37]/30 rounded-xl pointer-events-none" />

            {/* Corner Arabesque Accents */}
            <div className="absolute top-3 right-3 text-[#B38B29] text-xs font-serif opacity-70">✤</div>
            <div className="absolute top-3 left-3 text-[#B38B29] text-xs font-serif opacity-70">✤</div>
            <div className="absolute bottom-3 right-3 text-[#B38B29] text-xs font-serif opacity-70">✤</div>
            <div className="absolute bottom-3 left-3 text-[#B38B29] text-xs font-serif opacity-70">✤</div>

            {/* Prophet Invocation */}
            <div className="text-center mb-3">
              <span className="text-[#9C7A28] text-xs font-serif block mb-0.5">﷽</span>
              <span className="text-xs font-bold text-amber-800/80 tracking-wide">قال رسول الله ﷺ:</span>
            </div>

            {/* Hadith Core Text */}
            <div className="text-center px-2 my-4">
              <p className="font-hadith text-lg leading-relaxed font-bold text-slate-900 select-all">
                {hadith.hadith_text.replace(/^عن.*?قال:\s*/, '')}
              </p>
            </div>

            {/* Divider */}
            <div className="flex items-center justify-center my-3 gap-2 opacity-50">
              <div className="h-px w-16 bg-[#D4AF37]" />
              <span className="text-[#D4AF37] text-xs">◆</span>
              <div className="h-px w-16 bg-[#D4AF37]" />
            </div>

            {/* Takhrij / Narrator Info */}
            <div className="text-xs text-slate-600 space-y-1 text-center font-medium">
              <p>الراوي: <span className="text-slate-900">{hadith.narrator}</span></p>
              <p>المصدر: <span className="text-slate-900">{hadith.source}</span> ({hadith.book})</p>
              <p className="text-[11px] text-slate-500">
                رقم: {hadith.hadith_number} · الدرجة: <span className="text-emerald-700 font-semibold">{hadith.authenticity_grade}</span>
              </p>
            </div>

            {/* Footer Logo Watermark */}
            <div className="mt-5 pt-3 border-t border-[#D4AF37]/20 flex flex-col items-center justify-center">
              <div className="flex items-center gap-1.5 text-amber-800 font-bold text-sm">
                <span>ليه قالها؟</span>
              </div>
              <span className="text-[10px] text-slate-500">كل حديث قصة قبل أن يكون كلمة</span>
            </div>
          </div>

          <p className="text-xs text-slate-400 text-center mt-3">
            يمكنك حفظ البطاقة بتنسيق صورة عالية الدقة أو نسخ النص لنشره ومشاركته مع من تحب.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-[#0D131F] border-t border-slate-800 grid grid-cols-3 gap-2">
          <button
            onClick={handleDownloadImage}
            disabled={downloading}
            className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-[#E2B773] text-[#0D131F] font-bold text-xs hover:bg-[#d4a861] active:scale-95 transition-all shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>{downloading ? 'جارٍ الحفظ...' : 'حفظ الصورة'}</span>
          </button>

          <button
            onClick={handleCopyText}
            className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs active:scale-95 transition-all"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
          </button>

          <button
            onClick={handleNativeShare}
            className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs active:scale-95 transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>مشاركة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
