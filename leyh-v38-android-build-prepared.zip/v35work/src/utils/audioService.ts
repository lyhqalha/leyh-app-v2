/**
 * Audio Service for "ليه قالها؟"
 * Android uses the bundled offline Kareem neural Arabic voice; browser uses Web Speech as fallback.
 * 
 * Features:
 * - Single Solemn Voice: "وقور عميق" (صوت واحد فقط وإزالة باقي الأصوات تماماً).
 * - Fixed deep pitch (0.80) and calm deliberate pacing (0.90) for reverence and peace.
 * - Prioritizes highest quality natural Arabic male dignified voices (e.g. Maged, Naif, Tarik, Bilal, ar-SA).
 * - Reads only direct hadith and story content, discarding labels and scene titles.
 * - Works 100% locally, instantly, without subscriptions, API keys, or errors.
 */

import { Capacitor } from '@capacitor/core';
import { TextToSpeech } from '@capacitor-community/text-to-speech';

declare global {
  interface Window {
    LeyhOfflineTts?: {
      speak: (text: string, speed: number) => void;
      stop: () => void;
      pause: () => void;
      resume: () => void;
      isPlaying: () => boolean;
    };
    __leyhOfflineTtsDone?: () => void;
    __leyhOfflineTtsError?: (message: string) => void;
  }
}

export interface VoiceProfile {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  pitch: number;
  rate: number;
}

export const SOLEMN_VOICE: VoiceProfile = {
  id: 'deep_dignified',
  name: 'وقور عميق',
  subtitle: 'صوت واحد موحد',
  description: 'نبرة صوت واحدة رصينة تتسم بالعمق والوقار والسكينة ومخارج الحروف الفصيحة',
  pitch: 0.80,
  rate: 0.90
};

// Kept for backward compatibility but restricted to the single solemn voice
export const PITCH_PRESETS = [
  { id: 'deep', name: 'وقور عميق', value: 0.80, description: 'نبرة صوت واحدة تتسم بالوقار والعمق والسكينة' }
];

export const SPEED_PRESETS = [
  { id: 'calm', label: '0.90x هدوء ووقار', value: 0.90 },
  { id: 'normal', label: '1.00x معتدل', value: 1.00 }
];

export const VOICE_STYLES: Record<string, any> = {
  deep_dignified: SOLEMN_VOICE,
  dignified: SOLEMN_VOICE,
  unified: SOLEMN_VOICE,
  reverent: SOLEMN_VOICE,
  resonant: SOLEMN_VOICE,
  calm: SOLEMN_VOICE,
  eloquent: SOLEMN_VOICE
};

export const OPENAI_VOICES_CONFIG = VOICE_STYLES;

/**
 * Strips titles, badges (e.g. "المشهد الأول"), and introductory labels
 * so that ONLY the direct story content is spoken clearly.
 */
export function cleanStoryContentForSpeech(text: string): string {
  if (!text) return '';
  let cleaned = text.trim();

  // Strip scene labels like "المشهد الأول: ماذا حدث؟"
  cleaned = cleaned.replace(/^المشهد\s+[\u0600-\u06FF\w\d]+\s*([:：\-–—\.]\s*[^؟\.\n!]+[؟\.\n!:]*)?\s*/i, '');

  // Strip standalone question/topic introductory headings at the beginning
  cleaned = cleaned.replace(/^(ماذا حدث|ماذا جرى|فكر لحظة|ماذا قال النبي|ماذا قال الرسول|سر الكلمة|أثر الحديث|كيف نعيشه اليوم|العبرة والدرس)\s*(\([^\)]+\))?\s*([:：\-–—\.]|[؟\?!])\s*/i, '');

  // Strip any remaining scene badges embedded inside text
  cleaned = cleaned.replace(/المشهد\s+(الأول|الثاني|الثالث|الرابع|الخامس|السادس|[\d]+)\s*[:：\-–—\.]?\s*/gi, '');

  return cleaned.trim();
}

export interface AudioPlayOptions {
  language?: 'ar' | 'en';
  speed?: number;
  pitch?: number;
  voice?: string;
  style?: string;
  onProgress?: (progressPercent: number, currentTimeSec: number, durationSec: number) => void;
  onWord?: (wordIndex: number, word: string) => void;
  onEnd?: () => void;
  onError?: (errorMessage: string) => void;
}

class WebSpeechAudioEngine {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  // Locked to deep solemn voice: pitch 0.80, rate 0.90
  private currentSpeed = SOLEMN_VOICE.rate;
  private currentPitch = SOLEMN_VOICE.pitch;
  private isCurrentlyPlaying = false;
  private preferredArabicVoice: SpeechSynthesisVoice | null = null;
  private preferredEnglishVoice: SpeechSynthesisVoice | null = null;
  private availableVoices: SpeechSynthesisVoice[] = [];
  private tickerInterval: any = null;
  private estimatedDuration = 45;
  private elapsedSeconds = 0;
  private nativeRunId = 0;
  private nativeChunks: string[] = [];
  private nativeChunkIndex = 0;
  private nativeOptions: AudioPlayOptions | null = null;
  private nativeRangeListener: { remove: () => Promise<void> } | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      // Native Sherpa/Kareem completion callbacks. These are required because
      // the Android bridge finishes asynchronously after generating each WAV.
      window.__leyhOfflineTtsDone = () => this.handleNativeDone();
      window.__leyhOfflineTtsError = (message: string) => this.handleNativeError(message);

      try {
        const savedPitch = localStorage.getItem('leh_qalha_speech_pitch');
        if (savedPitch) {
          const val = parseFloat(savedPitch);
          if (!isNaN(val) && val >= 0.7 && val <= 1.2) {
            this.currentPitch = val;
          }
        }
        const savedSpeed = localStorage.getItem('leh_qalha_speech_speed');
        if (savedSpeed) {
          const val = parseFloat(savedSpeed);
          if (!isNaN(val) && val >= 0.7 && val <= 1.4) {
            this.currentSpeed = val;
          }
        }
      } catch {
        // Ignored
      }

      if ('speechSynthesis' in window) {
        this.loadArabicVoices();
        this.loadEnglishVoices();
        window.speechSynthesis.onvoiceschanged = () => {
          this.loadArabicVoices();
          this.loadEnglishVoices();
        };
      }
    }
  }

  /**
   * Selects the single best deep, solemn Arabic voice available on the device
   */
  private loadArabicVoices() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    this.availableVoices = window.speechSynthesis.getVoices();

    // Priority given to revered, clear Arabic male voices with solemn timber
    const highQualityPriorities = [
      'maged', 'tarik', 'naif', 'bilal', 'khalid', 'hamed', 'shakir', 'omar', 'salman', 'male'
    ];

    // 1. Look for recognized solemn Arabic male voice
    let found = this.availableVoices.find(v => {
      const isArabic = v.lang.toLowerCase().startsWith('ar');
      const name = v.name.toLowerCase();
      return isArabic && highQualityPriorities.some(k => name.includes(k));
    });

    // 2. Look for Saudi Arabic (ar-SA) which usually carries standard liturgical pronunciation
    if (!found) {
      found = this.availableVoices.find(v => {
        const lang = v.lang.toLowerCase();
        return lang === 'ar-sa' || lang === 'ar_sa';
      });
    }

    // 3. Look for any standard Arabic voice
    if (!found) {
      found = this.availableVoices.find(v => v.lang.toLowerCase().startsWith('ar'));
    }

    if (found) {
      this.preferredArabicVoice = found;
    }
  }


  private loadEnglishVoices() {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const voices = window.speechSynthesis.getVoices();
    this.preferredEnglishVoice = voices.find(v => v.lang.toLowerCase() === 'en-us')
      || voices.find(v => v.lang.toLowerCase().startsWith('en'))
      || null;
  }
  public getPitch(): number {
    return this.currentPitch;
  }

  public setPitch(pitch: number) {
    this.currentPitch = Math.max(0.7, Math.min(1.2, pitch));
    try {
      localStorage.setItem('leh_qalha_speech_pitch', this.currentPitch.toString());
    } catch {
      // Ignored
    }
    if (this.currentUtterance && this.isCurrentlyPlaying) {
      this.currentUtterance.pitch = this.currentPitch;
    }
  }

  public getRate(): number {
    return this.currentSpeed;
  }

  public setRate(rate: number) {
    this.currentSpeed = Math.max(0.7, Math.min(1.4, rate));
    try {
      localStorage.setItem('leh_qalha_speech_speed', this.currentSpeed.toString());
    } catch {
      // Ignored
    }
    if (this.currentUtterance && this.isCurrentlyPlaying) {
      this.currentUtterance.rate = this.currentSpeed;
    }
  }

  // Returns the single solemn voice
  public getVoiceStyle(): string {
    return 'deep_dignified';
  }

  public setVoice(_style?: any) {
    // Single voice locked
  }

  public isSpeaking(): boolean {
    if (typeof window !== 'undefined' && window.LeyhOfflineTts) { try { return window.LeyhOfflineTts.isPlaying(); } catch {} }
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false;
    return window.speechSynthesis.speaking && !window.speechSynthesis.paused;
  }

  public pauseSpeaking() {
    if (typeof window !== 'undefined' && window.LeyhOfflineTts) { try { window.LeyhOfflineTts.pause(); } catch {} this.isCurrentlyPlaying = false; this.stopTicker(); return; }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.pause();
      this.isCurrentlyPlaying = false;
      this.stopTicker();
    }
  }

  public resumeSpeaking() {
    if (typeof window !== 'undefined' && window.LeyhOfflineTts) { try { window.LeyhOfflineTts.resume(); } catch {} this.isCurrentlyPlaying = true; this.startTicker(); return; }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.resume();
      this.isCurrentlyPlaying = true;
      this.startTicker();
    }
  }

  public stopSpeaking() {
    this.nativeRunId += 1;
    this.nativeOptions = null;
    this.nativeChunks = [];
    this.nativeChunkIndex = 0;
    if (Capacitor.isNativePlatform()) {
      try { window.LeyhOfflineTts?.stop(); } catch {}
      void TextToSpeech.stop().catch(() => undefined);
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      this.currentUtterance = null;
    }
    this.isCurrentlyPlaying = false;
    this.stopTicker();
    this.elapsedSeconds = 0;
  }

  public seek(seconds: number) {
    this.elapsedSeconds = Math.max(0, Math.min(this.estimatedDuration, seconds));
  }

  public seekPercent(percent: number) {
    this.elapsedSeconds = Math.max(0, Math.min(this.estimatedDuration, (percent / 100) * this.estimatedDuration));
  }

  private startTicker(onProgress?: (progress: number, current: number, total: number) => void) {
    this.stopTicker();
    this.tickerInterval = setInterval(() => {
      if (this.isCurrentlyPlaying) {
        this.elapsedSeconds += 1;
        if (this.elapsedSeconds > this.estimatedDuration) {
          this.estimatedDuration = this.elapsedSeconds + 5;
        }
        const pct = Math.min(99, Math.round((this.elapsedSeconds / this.estimatedDuration) * 100));
        if (onProgress) {
          onProgress(pct, this.elapsedSeconds, this.estimatedDuration);
        }
      }
    }, 1000);
  }

  private stopTicker() {
    if (this.tickerInterval) {
      clearInterval(this.tickerInterval);
      this.tickerInterval = null;
    }
  }

  /**
   * Recite a hadith or story using the single deep and dignified voice (وقور عميق).
   */
  private splitNativeText(text: string, maxChars = 360): string[] {
    const normalized = text.replace(/\s+/g, ' ').trim();
    if (!normalized) return [];
    const sentences = normalized.match(/[^.!؟؛:]+[.!؟؛:]?|[^.!؟؛:]+$/g) || [normalized];
    const chunks: string[] = [];
    let current = '';
    for (const sentenceRaw of sentences) {
      const sentence = sentenceRaw.trim();
      if (!sentence) continue;
      if ((current + ' ' + sentence).trim().length <= maxChars) {
        current = (current + ' ' + sentence).trim();
        continue;
      }
      if (current) chunks.push(current);
      if (sentence.length <= maxChars) {
        current = sentence;
      } else {
        const words = sentence.split(/\s+/);
        let part = '';
        for (const word of words) {
          if ((part + ' ' + word).trim().length <= maxChars) {
            part = (part + ' ' + word).trim();
          } else {
            if (part) chunks.push(part);
            part = word;
          }
        }
        current = part;
      }
    }
    if (current) chunks.push(current);
    return chunks;
  }

  private handleNativeDone() {
    const options = this.nativeOptions;
    if (!options) return;
    this.nativeChunkIndex += 1;
    if (this.nativeChunkIndex < this.nativeChunks.length) {
      try {
        window.LeyhOfflineTts?.speak(this.nativeChunks[this.nativeChunkIndex], options.speed ?? this.currentSpeed);
        return;
      } catch (e: any) {
        this.handleNativeError(e?.message || 'تعذر تشغيل الصوت');
        return;
      }
    }
    this.isCurrentlyPlaying = false;
    this.stopTicker();
    options.onProgress?.(100, this.estimatedDuration, this.estimatedDuration);
    options.onEnd?.();
    this.nativeOptions = null;
    this.nativeChunks = [];
    this.nativeChunkIndex = 0;
  }

  private handleNativeError(message: string) {
    const options = this.nativeOptions;
    if (!options) return;
    this.isCurrentlyPlaying = false;
    this.stopTicker();
    this.nativeOptions = null;
    this.nativeChunks = [];
    this.nativeChunkIndex = 0;
    options.onError?.(message || 'تعذر تشغيل الصوت');
  }

  private async reciteNative(text: string, options: AudioPlayOptions) {
    const runId = ++this.nativeRunId;
    const effectiveSpeed = options.speed ?? this.currentSpeed;
    const chunks = this.splitNativeText(text);
    if (!chunks.length) { options.onEnd?.(); return; }

    const wordsCount = text.split(/\s+/).filter(Boolean).length;
    this.estimatedDuration = Math.max(5, Math.round(wordsCount / (2.1 * effectiveSpeed)));
    this.elapsedSeconds = 0;
    this.isCurrentlyPlaying = true;
    this.nativeOptions = options;
    this.nativeChunks = chunks;
    this.nativeChunkIndex = 0;

    if (options.onProgress) options.onProgress(0, 0, this.estimatedDuration);
    this.startTicker(options.onProgress);

    if (Capacitor.isNativePlatform()) {
      if (!window.LeyhOfflineTts) {
        this.handleNativeError('محرك Miro High أوفلاين غير متاح داخل التطبيق.');
        return;
      }
      try {
        window.LeyhOfflineTts.speak(chunks[0], effectiveSpeed);
      } catch (error: any) {
        if (runId !== this.nativeRunId) return;
        this.handleNativeError(error?.message || 'تعذر تشغيل صوت كريم.');
      }
      return;
    }

    this.handleNativeError('تشغيل كريم أوفلاين متاح داخل تطبيق Android فقط.');
  }

  public reciteHadith(text: string, options: AudioPlayOptions = {}) {
    // Cancel any previous speech
    this.stopSpeaking();

    // Prepare text: strip badges/titles directly
    const cleanText = cleanStoryContentForSpeech(text);
    if (!cleanText) {
      if (options.onEnd) options.onEnd();
      return;
    }

    // Android APK always uses the bundled offline Kareem/Sherpa engine.
    if (Capacitor.isNativePlatform()) {
      void this.reciteNative(cleanText, options);
      return;
    }

    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (options.onError) options.onError('خاصية النطق غير مدعومة في متصفحك.');
      return;
    }

    const effectivePitch = options.pitch ?? this.currentPitch;
    const effectiveSpeed = options.speed ?? this.currentSpeed;

    // Estimate total duration
    const wordsCount = cleanText.split(/\s+/).filter(Boolean).length;
    this.estimatedDuration = Math.max(5, Math.round((wordsCount / (2.1 * effectiveSpeed))));
    this.elapsedSeconds = 0;

    const language = options.language ?? (localStorage.getItem('leyh_app_language') === 'en' ? 'en' : 'ar');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = language === 'en' ? 'en-US' : 'ar-SA';
    utterance.rate = effectiveSpeed;
    utterance.pitch = effectivePitch;

    // Use preferred deep dignified Arabic voice
    if (language === 'en') {
      if (!this.preferredEnglishVoice) this.loadEnglishVoices();
      if (this.preferredEnglishVoice) utterance.voice = this.preferredEnglishVoice;
    } else {
      if (!this.preferredArabicVoice) this.loadArabicVoices();
      if (this.preferredArabicVoice) utterance.voice = this.preferredArabicVoice;
    }

    utterance.onstart = () => {
      this.isCurrentlyPlaying = true;
      this.startTicker(options.onProgress);
      if (options.onProgress) {
        options.onProgress(0, 0, this.estimatedDuration);
      }
    };

    utterance.onend = () => {
      this.isCurrentlyPlaying = false;
      this.stopTicker();
      this.elapsedSeconds = 0;
      if (options.onProgress) {
        options.onProgress(100, this.estimatedDuration, this.estimatedDuration);
      }
      if (options.onEnd) {
        options.onEnd();
      }
    };

    utterance.onerror = (e) => {
      this.isCurrentlyPlaying = false;
      this.stopTicker();
      if (e.error !== 'interrupted' && e.error !== 'canceled') {
        if (options.onError) {
          options.onError(e.error || 'حدث خطأ أثناء تشغيل الصوت');
        }
      }
    };

    utterance.onboundary = (event) => {
      if (event.name === 'word' && options.onWord) {
        options.onWord(event.charIndex, '');
      }
    };

    this.currentUtterance = utterance;
    this.isCurrentlyPlaying = true;
    window.speechSynthesis.speak(utterance);
  }

  /**
   * Quick voice sample test with the single deep dignified voice
   */
  public testSample(pitch?: number, speed?: number, onFinish?: () => void) {
    const sampleText = 'بسم الله الرحمن الرحيم، قال رسول الله صلى الله عليه وسلم: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.';
    this.reciteHadith(sampleText, {
      pitch: pitch ?? this.currentPitch,
      speed: speed ?? this.currentSpeed,
      onEnd: onFinish,
      onError: onFinish
    });
  }
}

export const audioEngine = new WebSpeechAudioEngine();
