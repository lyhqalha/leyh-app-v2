/**
 * Audio service for story narration.
 * Story audio is pre-generated and bundled with the app; no TTS engine/model is
 * shipped in the APK and no API key/network is required for playback.
 */

export interface AudioPlayOptions {
  onProgress?: (progressPercent: number, currentTimeSec: number, durationSec: number) => void;
  onWord?: (wordIndex: number, word: string) => void;
  onEnd?: () => void;
  onError?: (errorMessage: string) => void;
}

export interface VoiceProfile {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  pitch: number;
  rate: number;
}

export const SOLEMN_VOICE: VoiceProfile = {
  id: 'audar_storyteller',
  name: 'راوي القصة',
  subtitle: 'صوت قصصي تعبيري',
  description: 'ملفات صوتية جاهزة بصوت راوي تعبيري، بدون محرك نطق داخل التطبيق',
  pitch: 1,
  rate: 1
};

export const PITCH_PRESETS = [{ id: 'story', name: 'راوي القصة', value: 1, description: 'الصوت القصصي المعتمد' }];
export const SPEED_PRESETS = [{ id: 'normal', label: 'السرعة الأصلية', value: 1 }];
export const VOICE_STYLES: Record<string, VoiceProfile> = { audar_storyteller: SOLEMN_VOICE, deep_dignified: SOLEMN_VOICE };
export const OPENAI_VOICES_CONFIG = VOICE_STYLES;

export function cleanStoryContentForSpeech(text: string): string {
  return (text || '').trim();
}

function audioUrl(hadithId: string, sceneNumber: number): string {
  return `/story-audio/${encodeURIComponent(hadithId)}/scene-${sceneNumber}.mp3`;
}

class StoryAudioEngine {
  private audio: HTMLAudioElement | null = null;
  private onEnd: (() => void) | null = null;
  private onError: ((message: string) => void) | null = null;
  private onProgress: AudioPlayOptions['onProgress'] = undefined;
  private onTimeUpdate = () => {
    if (!this.audio) return;
    const duration = Number.isFinite(this.audio.duration) ? this.audio.duration : 0;
    const current = this.audio.currentTime || 0;
    this.onProgress?.(duration ? (current / duration) * 100 : 0, current, duration);
  };
  private onEnded = () => {
    this.cleanup(false);
    this.onEnd?.();
  };
  private onAudioError = () => {
    const message = 'الملف الصوتي لهذه القصة غير متوفر بعد.';
    this.cleanup(true);
    this.onError?.(message);
  };

  private ensureAudio() {
    if (typeof window === 'undefined') return null;
    if (!this.audio) {
      this.audio = new Audio();
      this.audio.preload = 'auto';
      this.audio.addEventListener('timeupdate', this.onTimeUpdate);
      this.audio.addEventListener('ended', this.onEnded);
      this.audio.addEventListener('error', this.onAudioError);
    }
    return this.audio;
  }

  public playStoryScene(hadithId: string, sceneNumber: number, options: AudioPlayOptions = {}) {
    this.stopSpeaking();
    const audio = this.ensureAudio();
    if (!audio) {
      options.onError?.('تشغيل الصوت غير متاح.');
      return;
    }
    this.onEnd = options.onEnd || null;
    this.onError = options.onError || null;
    this.onProgress = options.onProgress;
    audio.src = audioUrl(hadithId, sceneNumber);
    audio.currentTime = 0;
    audio.play().catch(() => {
      this.onAudioError();
    });
  }

  public reciteHadith(_text: string, options: AudioPlayOptions = {}) {
    options.onError?.('الصوت النصي أُلغي. قصص التطبيق تستخدم تسجيلات الراوي الجاهزة.');
  }

  public isSpeaking(): boolean {
    return !!this.audio && !this.audio.paused && !this.audio.ended;
  }

  public stopSpeaking() {
    if (!this.audio) return;
    this.audio.pause();
    this.audio.currentTime = 0;
    this.cleanup(false);
  }

  public pauseSpeaking() {
    this.audio?.pause();
  }

  public resumeSpeaking() {
    this.audio?.play().catch(() => {});
  }

  public getPitch() { return 1; }
  public setPitch(_pitch: number) {}
  public getRate() { return 1; }
  public setRate(_rate: number) {}
  public getVoiceStyle() { return SOLEMN_VOICE.id; }
  public setVoice(_style?: any) {}

  public testSample(_pitch?: number, _speed?: number, onFinish?: () => void) {
    onFinish?.();
  }

  private cleanup(clearHandlers: boolean) {
    if (!this.audio) return;
    if (clearHandlers) {
      // Keep the reusable element/listeners, just clear playback state.
    }
    this.onEnd = null;
    this.onError = null;
    this.onProgress = undefined;
  }
}

export const audioEngine = new StoryAudioEngine();
