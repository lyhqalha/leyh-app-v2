/**
 * Audio service for story narration.
 * Story audio is pre-generated and bundled with the app; no TTS engine/model is
 * shipped in the APK and no API key/network is required for playback.
 */

export interface AudioPlayOptions {
  pitch?: number;
  speed?: number;
  language?: string;
  onProgress?: (progressPercent: number, currentTimeSec: number, durationSec: number) => void;
  onWord?: (wordIndex: number, word: string) => void;
  onEnd?: () => void;
  onError?: (errorMessage: string) => void;
  fallbackText?: string;
}

export interface VoiceProfile {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  pitch: number;
  rate: number;
}

export const SOLEMN_VOICE: VoiceProfile = {
  id: 'audar_storyteller',
  name: 'راوي القصة',
  subtitle: 'صوت قصصي تعبيري',
  description: 'ملفات صوتية جاهزة بصوت راوي تعبيري، بدون محرك نطق داخل التطبيق',
  pitch: 1,
  rate: 1
};

export const PITCH_PRESETS = [{ id: 'story', name: 'راوي القصة', value: 1, description: 'الصوت القصصي المعتمد' }];
export const SPEED_PRESETS = [{ id: 'normal', label: 'السرعة الأصلية', value: 1 }];
export const VOICE_STYLES: Record<string, VoiceProfile> = { audar_storyteller: SOLEMN_VOICE, deep_dignified: SOLEMN_VOICE };
export const OPENAI_VOICES_CONFIG = VOICE_STYLES;

export function cleanStoryContentForSpeech(text: string): string {
  return (text || '').trim();
}

function audioUrl(hadithId: string, sceneNumber: number): string {
  return `/story-audio/${encodeURIComponent(hadithId)}/scene-${sceneNumber}.mp3`;
}

class StoryAudioEngine {
  private audio: HTMLAudioElement | null = null;
  private speechUtterance: SpeechSynthesisUtterance | null = null;
  private fallbackText = '';
  private onEnd: (() => void) | null = null;
  private onError: ((message: string) => void) | null = null;
  private onProgress: AudioPlayOptions['onProgress'] = undefined;
  private onTimeUpdate = () => {
    if (!this.audio) return;
    const duration = Number.isFinite(this.audio.duration) ? this.audio.duration : 0;
    const current = this.audio.currentTime || 0;
    this.onProgress?.(duration ? (current / duration) * 100 : 0, current, duration);
  };
  private onEnded = () => {
    const callback = this.onEnd;
    this.cleanup(false);
    callback?.();
  };
  private onAudioError = () => {
    const fallbackText = this.fallbackText;
    const onEnd = this.onEnd;
    const onError = this.onError;
    this.cleanup(true);
    if (fallbackText && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      // If a bundled scene recording is missing, fall back to the device's
      // Arabic speech voice instead of leaving the play button unresponsive.
      const utterance = new SpeechSynthesisUtterance(fallbackText);
      utterance.lang = 'ar';
      utterance.rate = 0.92;
      utterance.onend = () => {
        this.speechUtterance = null;
        onEnd?.();
        this.cleanup(false);
      };
      utterance.onerror = () => {
        this.speechUtterance = null;
        onError?.('تعذر تشغيل الصوت على هذا الجهاز.');
        this.cleanup(false);
      };
      this.speechUtterance = utterance;
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(utterance);
      return;
    }
    onError?.('الملف الصوتي لهذه القصة غير متوفر، ولا يتوفر صوت بديل على الجهاز.');
  };

  private ensureAudio() {
    if (typeof window === 'undefined') return null;
    if (!this.audio) {
      this.audio = new Audio();
      this.audio.preload = 'auto';
      this.audio.addEventListener('timeupdate', this.onTimeUpdate);
      this.audio.addEventListener('ended', this.onEnded);
      this.audio.addEventListener('error', this.onAudioError);
    }
    return this.audio;
  }

  public playStoryScene(hadithId: string, sceneNumber: number, options: AudioPlayOptions = {}) {
    this.stopSpeaking();
    const audio = this.ensureAudio();
    if (!audio) {
      options.onError?.('تشغيل الصوت غير متاح.');
      return;
    }
    this.fallbackText = options.fallbackText || '';
    this.onEnd = options.onEnd || null;
    this.onError = options.onError || null;
    this.onProgress = options.onProgress;
    audio.src = audioUrl(hadithId, sceneNumber);
    audio.currentTime = 0;
    audio.play().catch(() => {
      this.onAudioError();
    });
  }

  public reciteHadith(text: string, options: AudioPlayOptions = {}) {
    this.stopSpeaking();
    const content = (text || '').trim();
    if (!content) {
      options.onError?.('لا يوجد نص متاح للقراءة.');
      return;
    }
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      options.onError?.('ميزة القراءة الصوتية غير مدعومة على هذا الجهاز.');
      return;
    }
    this.onEnd = options.onEnd || null;
    this.onError = options.onError || null;
    this.onProgress = options.onProgress;
    const utterance = new SpeechSynthesisUtterance(content);
    utterance.lang = options.language || 'ar';
    utterance.pitch = options.pitch ?? 1;
    utterance.rate = options.speed ?? 1;
    utterance.onend = () => {
      this.speechUtterance = null;
      this.onProgress?.(100, 0, 0);
      this.onEnd?.();
      this.cleanup(false);
    };
    utterance.onerror = () => {
      this.speechUtterance = null;
      this.onError?.('تعذر تشغيل القراءة الصوتية. تأكد من وجود صوت عربي في إعدادات الجهاز.');
      this.cleanup(false);
    };
    this.speechUtterance = utterance;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(utterance);
  }

  public isSpeaking(): boolean {
    return (!!this.audio && !this.audio.paused && !this.audio.ended) ||
      (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.speaking);
  }

  public stopSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.speechUtterance = null;
    if (this.audio) {
      this.audio.pause();
      this.audio.currentTime = 0;
    }
    this.cleanup(false);
  }

  public pauseSpeaking() {
    this.audio?.pause();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.pause();
  }

  public resumeSpeaking() {
    this.audio?.play().catch(() => {});
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.resume();
  }

  public getPitch() { return 1; }
  public setPitch(_pitch: number) {}
  public getRate() { return 1; }
  public setRate(_rate: number) {}
  public getVoiceStyle() { return SOLEMN_VOICE.id; }
  public setVoice(_style?: any) {}

  public testSample(_pitch?: number, _speed?: number, onFinish?: () => void) {
    onFinish?.();
  }

  private cleanup(clearHandlers: boolean) {
    if (!this.audio) return;
    if (clearHandlers) {
      // Keep the reusable element/listeners, just clear playback state.
    }
    this.onEnd = null;
    this.onError = null;
    this.onProgress = undefined;
    this.fallbackText = '';
  }
}

export const audioEngine = new StoryAudioEngine();
