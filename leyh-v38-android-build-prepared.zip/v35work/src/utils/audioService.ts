/**
 * Audio service for story narration.
 * Story audio is pre-generated and bundled with the app; no TTS engine/model is
 * shipped in the APK and no API key/network is required for playback.
 */

export interface AudioPlayOptions {
  onProgress?: (progressPercent: number, currentTimeSec: number, durationSec: number) => void;
  onWord?: (wordIndex: number, word: string) => void;
  onEnd?: () => void;
  onError?: (errorMessage: string) => void;
}

export interface VoiceProfile {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  pitch: number;
  rate: number;
}

export const SOLEMN_VOICE: VoiceProfile = {
  id: 'audar_storyteller',
  name: 'راوي القصة',
  subtitle: 'صوت قصصي تعبيري',
  description: 'ملفات صوتية جاهزة بصوت راوي تعبيري، بدون محرك نطق داخل التطبيق',
  pitch: 1,
  rate: 1
};

export const PITCH_PRESETS = [{ id: 'story', name: 'راوي القصة', value: 1, description: 'الصوت القصصي المعتمد' }];
export const SPEED_PRESETS = [{ id: 'normal', label: 'السرعة الأصلية', value: 1 }];
export const VOICE_STYLES: Record<string, VoiceProfile> = { audar_storyteller: SOLEMN_VOICE, deep_dignified: SOLEMN_VOICE };
export const OPENAI_VOICES_CONFIG = VOICE_STYLES;

export function cleanStoryContentForSpeech(text: string): string {
  return (text || '').trim();
}

function audioUrl(hadithId: string, sceneNumber: number): string {
  return `/story-audio/${encodeURIComponent(hadithId)}/scene-${sceneNumber}.mp3`;
}

class StoryAudioEngine {
  private audio: HTMLAudioElement | null = null;
  private speechUtterance: SpeechSynthesisUtterance | null = null;
  private onEnd: (() => void) | null = null;
  private onError: ((message: string) => void) | null = null;
  private onProgress: AudioPlayOptions['onProgress'] = undefined;
  private onTimeUpdate = () => {
    if (!this.audio) return;
    const duration = Number.isFinite(this.audio.duration) ? this.audio.duration : 0;
    const current = this.audio.currentTime || 0;
    this.onProgress?.(duration ? (current / duration) * 100 : 0, current, duration);
  };
  private onEnded = () => {
    this.cleanup(false);
    this.onEnd?.();
  };
  private onAudioError = () => {
    const message = 'الملف الصوتي لهذه القصة غير متوفر بعد.';
    this.cleanup(true);
    this.onError?.(message);
  };

  private ensureAudio() {
    if (typeof window === 'undefined') return null;
    if (!this.audio) {
      this.audio = new Audio();
      this.audio.preload = 'auto';
      this.audio.addEventListener('timeupdate', this.onTimeUpdate);
      this.audio.addEventListener('ended', this.onEnded);
      this.audio.addEventListener('error', this.onAudioError);
    }
    return this.audio;
  }

  public playStoryScene(hadithId: string, sceneNumber: number, options: AudioPlayOptions = {}) {
    this.stopSpeaking();
    const audio = this.ensureAudio();
    if (!audio) {
      options.onError?.('تشغيل الصوت غير متاح.');
      return;
    }
    this.onEnd = options.onEnd || null;
    this.onError = options.onError || null;
    this.onProgress = options.onProgress;
    audio.src = audioUrl(hadithId, sceneNumber);
    audio.currentTime = 0;
    audio.play().catch(() => {
      this.onAudioError();
    });
  }

  public reciteHadith(text: string, options: AudioPlayOptions = {}) {
    this.stopSpeaking();
    const cleanText = cleanStoryContentForSpeech(text);
    if (!cleanText) {
      options.onEnd?.();
      return;
    }

    // Use the device's speech engine for hadith text. Offline playback depends
    // on an Arabic TTS voice being installed on the Android device.
    if (typeof window === 'undefined' || !('speechSynthesis' in window) ||
        typeof SpeechSynthesisUtterance === 'undefined') {
      options.onError?.('النطق غير متاح على هذا الجهاز. تأكد من تثبيت محرك تحويل النص إلى كلام وصوت عربي من إعدادات Android.');
      return;
    }

    const synth = window.speechSynthesis;
    synth.cancel();
    const utterance = new SpeechSynthesisUtterance(cleanText);
    this.speechUtterance = utterance;
    utterance.lang = 'ar-SA';
    utterance.rate = 1;
    utterance.pitch = 1;

    const chooseVoice = () => {
      const voices = synth.getVoices();
      const arabicVoice = voices.find(v => /^ar([-_]|$)/i.test(v.lang)) ||
                          voices.find(v => /arabic|العربية|عربي/i.test(v.name));
      if (arabicVoice) utterance.voice = arabicVoice;
    };
    chooseVoice();
    if (!utterance.voice && synth.onvoiceschanged !== undefined) {
      synth.onvoiceschanged = chooseVoice;
    }

    utterance.onstart = () => options.onProgress?.(0, 0, 0);
    utterance.onboundary = (event: SpeechSynthesisEvent) => {
      if (event.name === 'word') options.onWord?.(event.charIndex, '');
    };
    utterance.onend = () => {
      if (this.speechUtterance === utterance) this.speechUtterance = null;
      options.onProgress?.(100, 0, 0);
      options.onEnd?.();
    };
    utterance.onerror = (event: SpeechSynthesisErrorEvent) => {
      if (this.speechUtterance === utterance) this.speechUtterance = null;
      if (event.error !== 'interrupted' && event.error !== 'canceled') {
        options.onError?.('تعذر نطق الحديث. تأكد من تفعيل محرك النطق وتثبيت صوت عربي على الجهاز.');
      }
    };
    synth.speak(utterance);
  }

  public isSpeaking(): boolean {
    const browserSpeaking = typeof window !== 'undefined' && 'speechSynthesis' in window &&
      (window.speechSynthesis.speaking || window.speechSynthesis.pending);
    return (!!this.audio && !this.audio.paused && !this.audio.ended) || !!browserSpeaking;
  }

  public stopSpeaking() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.speechUtterance = null;
    if (!this.audio) return;
    this.audio.pause();
    this.audio.currentTime = 0;
    this.cleanup(false);
  }

  public pauseSpeaking() {
    this.audio?.pause();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.pause();
  }

  public resumeSpeaking() {
    this.audio?.play().catch(() => {});
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.resume();
  }

  public getPitch() { return 1; }
  public setPitch(_pitch: number) {}
  public getRate() { return 1; }
  public setRate(_rate: number) {}
  public getVoiceStyle() { return SOLEMN_VOICE.id; }
  public setVoice(_style?: any) {}

  public testSample(_pitch?: number, _speed?: number, onFinish?: () => void) {
    this.reciteHadith(
      'بسم الله الرحمن الرحيم، قال رسول الله صلى الله عليه وسلم: إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.',
      { onEnd: onFinish, onError: onFinish }
    );
  }

  private cleanup(clearHandlers: boolean) {
    if (!this.audio) return;
    if (clearHandlers) {
      // Keep the reusable element/listeners, just clear playback state.
    }
    this.onEnd = null;
    this.onError = null;
    this.onProgress = undefined;
  }
}

export const audioEngine = new StoryAudioEngine();
