# ليه قالها v38 — Android build

This source revision is prepared to generate a Capacitor Android project in CI and build a debug APK. It does not commit generated Gradle files or the large Kareem TTS model; `scripts/prepare_android.sh` downloads the Sherpa-ONNX AAR and Kareem model during the build and bundles them into the APK.

## Build in GitHub Actions
1. Put the complete source tree on the `restore-v38` branch.
2. Open **Actions → Build Leyh Qalha v38 APK → Run workflow**.
3. When the run succeeds, download `leyh-qalha-v38-debug-apk` from the run's Artifacts section.

The APK is a debug build. The workflow intentionally fails rather than publishing an artifact if compilation fails.
