# ليه قالها — v38

This revision fixes the Kareem Medium Android TTS integration:
- Sherpa-ONNX Java builder API is used correctly.
- Kareem model files bundled in APK assets are copied to private filesystem paths before Sherpa loads them.
- TTS runs in the isolated `:leyh_tts` Android process.
- Android APK path uses the bundled Kareem engine instead of Android TextToSpeech.
