# Combined icon and offline audio update — Miro High

- Keeps the existing launcher icon and image fixes.
- Replaces the Kareem Medium Arabic model with the official Sherpa-ONNX Arabic `ar_JO-SA_miro-high` model.
- The build script downloads the model from the official Sherpa-ONNX `tts-models` release and bundles it into the APK assets for offline use.
- Updates native service asset/model paths to match the Miro High archive filenames.
- Keeps the Sherpa-ONNX 1.13.8 filesystem constructor fix and single manifest service registration.

The ZIP was structurally checked, but the Android workflow and playback on a physical phone have not yet been run. Confirm the GitHub Actions build succeeds and test playback on-device before treating the audio as fixed.
