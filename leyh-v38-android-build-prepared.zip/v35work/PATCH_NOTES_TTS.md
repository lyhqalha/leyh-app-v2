# TTS build patch

Updated `scripts/OfflineTtsService.java` to construct the public nested builder classes directly (`new ...Builder()`) rather than calling static `builder()` factory methods. This targets the reported javac errors for missing `builder()` symbols while retaining the same configuration setters and build calls.

The archive has not been compiled in this environment because the Android/Sherpa dependencies cannot be downloaded here. Run the GitHub Actions workflow to confirm whether the Java compile proceeds; do not treat this patch as a verified APK build until the workflow succeeds.
