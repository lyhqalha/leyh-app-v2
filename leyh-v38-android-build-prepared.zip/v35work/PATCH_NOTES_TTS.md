# Offline TTS fix

The Sherpa model, tokens, and espeak-ng-data are copied from APK assets to the app-private filesystem. `OfflineTts` must therefore be constructed with `null` as the AssetManager so the v1.13.8 Java API uses `newFromFile(config)`. Passing `getAssets()` incorrectly selects `newFromAsset()` and causes it to look for absolute filesystem paths inside APK assets.

The source fix is in `scripts/OfflineTtsService.java`; `prepare_android.sh` copies that file into the generated Android project before Gradle builds.
