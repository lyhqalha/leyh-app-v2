# Combined icon and offline audio fix

- `prepare_android.sh` explicitly sets AndroidManifest application icon and roundIcon to the supplied Leyh Qalha launcher PNGs, and removes generated adaptive-icon XML that could override those PNGs with the Capacitor placeholder.
- `prepare_android.sh` registers `com.leyhqalha.leyh.OfflineTtsService` as a non-exported `:tts` process. Without a manifest service declaration, Android cannot start the native offline TTS service and playback callbacks may never arrive.
- `OfflineTtsService.java` keeps the prior Sherpa-ONNX filesystem constructor fix (`new OfflineTts(null, config)`).

This ZIP has not yet been built or tested on a physical phone. Confirm the new APK build succeeds, then test launcher icon and Arabic playback.
