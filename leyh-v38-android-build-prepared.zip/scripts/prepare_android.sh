#!/usr/bin/env bash
set -euo pipefail

# Prepare optional Android resources without inventing or downloading audio assets.
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [ ! -f "capacitor.config.ts" ] && [ ! -f "capacitor.config.json" ] && [ ! -f "capacitor.config.js" ]; then
  echo "ERROR: Capacitor config is missing from project root." >&2
  exit 1
fi

if [ ! -d "dist" ]; then
  echo "ERROR: dist/ is missing. Run npm run build before preparing Android resources." >&2
  exit 1
fi

# Create Android raw-resource folder only when the Android platform exists.
# Keep existing resources intact. Audio files are optional in this project.
if [ -d "android/app/src/main" ]; then
  mkdir -p "android/app/src/main/res/raw"
  for candidate in "resources/salawat.wav" "resources/notification.wav" "public/salawat.wav" "public/notification.wav"; do
    if [ -f "$candidate" ]; then
      name="$(basename "$candidate" | tr '[:upper:]' '[:lower:]' | tr '-' '_')"
      cp -n "$candidate" "android/app/src/main/res/raw/$name"
    fi
  done
fi

echo "Android preparation complete. No bundled speech model or generated narration was added."
